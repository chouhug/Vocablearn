// 測 core.js（作答規則、出題、合併、備份碼）：node n5src/core-test.js n5work
// 日文頁和語言頁都用這些規則，改 core.js 後跑一次
'use strict';
const fs = require('fs'), path = require('path'), vm = require('vm');
const root = path.resolve(process.argv[2] || path.join(__dirname, '../n5work'));
const store = {};
const ctx = { console, Math, Date, JSON, Object, Array, String, Number, Set, Map, Promise, Response, Blob, btoa, atob, Uint8Array,
  CompressionStream: global.CompressionStream, DecompressionStream: global.DecompressionStream,
  localStorage: { getItem: k => (k in store ? store[k] : null), setItem: (k, v) => { store[k] = String(v); } }, document: { querySelector: () => null, readyState: 'complete' } };
ctx.window = ctx;
vm.createContext(ctx);
for (const f of ['sync.js', 'core.js']) vm.runInContext(fs.readFileSync(path.join(root, f), 'utf8'), ctx, { filename: f });
const C = vm.runInContext('({ addDays, applyAnswer, blankRec, pickRound, mergeState, packState, unpackState, zipCode, unzipCode, SRS, shortKey, streakOf })', ctx);

let fail = 0, n = 0;
const ok = (c, m) => { n++; if (!c) { fail++; console.log('失敗：' + m); } };
const T = '2026-11-07', NOW = Date.UTC(2026, 10, 7, 4);

// ---- 連勝 ----
{
  const D = (...xs) => Object.fromEntries(xs.map(([d, n]) => [d, n]));
  const S1 = C.streakOf(D(['2026-11-05', 5], ['2026-11-06', 8], ['2026-11-07', 6]), T);
  ok(S1.cur === 3 && S1.best === 3 && S1.today, '連續三天各 5 題以上：連勝 3');
  const S2 = C.streakOf(D(['2026-11-05', 5], ['2026-11-06', 4], ['2026-11-07', 6]), T);
  ok(S2.cur === 2 && S2.rest.length === 1 && S2.rest[0] === '2026-11-06', '中間一天只做 4 題：用掉休息日，連勝不斷（不加天數）');
  const S3 = C.streakOf(D(['2026-11-04', 5], ['2026-11-07', 6]), T);
  ok(S3.cur === 1 && S3.best === 1, '連兩天沒練：歸零重新算');
  const S4 = C.streakOf(D(['2026-11-05', 5], ['2026-11-06', 9], ['2026-11-07', 2]), T);
  ok(S4.cur === 2 && !S4.today, '今天還沒練到 5 題：連勝保留（今天還有機會）');
  const S5 = C.streakOf(D(['2026-11-05', 5]), T);
  ok(S5.cur === 1 && S5.rest[0] === '2026-11-06', '昨天沒練、今天還沒練：昨天算休息日，連勝還在');
  // 一週內第二次休息就斷
  const S6 = C.streakOf(D(['2026-11-01', 5], ['2026-11-03', 5], ['2026-11-04', 5], ['2026-11-06', 5], ['2026-11-07', 5]), T);
  ok(S6.cur === 2 && S6.best === 3, '7 天內第二個休息日：連勝斷掉（最長紀錄留著）');
  const S7 = C.streakOf(D(['2026-10-25', 5], ['2026-10-27', 5], ['2026-10-28', 5], ['2026-10-29', 5], ['2026-10-30', 5], ['2026-10-31', 5], ['2026-11-01', 5], ['2026-11-03', 5]), '2026-11-03');
  ok(S7.cur === 8 && S7.rest.length === 2, '隔 7 天再休息一次可以');
  ok(C.streakOf({}, T).cur === 0 && C.streakOf(null, T).best === 0, '沒有紀錄：0');
  let long = {}; for (let i = 0; i < 400; i++) long[C.addDays(T, -i)] = 6;
  ok(C.streakOf(long, T).cur === 400, '很長的連勝（400 天）也算得出來');
}

// ---- 日期 ----
ok(C.addDays('2026-12-31', 1) === '2027-01-01', 'addDays 跨年');
ok(C.addDays('2026-03-01', -1) === '2026-02-28', 'addDays 往前');

// ---- 作答規則 ----
let r = C.applyAnswer({ s: 'queued', n: 0, w: {}, lv: 0, due: '', st: 0, t: 0 }, 'mc', false, 'learn', T, NOW);
ok(r.w.mc === 1 && r.n === 1 && r.t === NOW && r.s === 'queued', '單選答錯 → 錯題，不算學會');
r = C.applyAnswer(r, 'mc', true, 'wrong', T, NOW + 1);
ok(r.w.mc === 2, '錯題答對一次 → 以前錯過（2）');
r = C.applyAnswer(r, 'mc', false, 'review', T, NOW + 2);
ok(r.w.mc === 1 && r.rv.mc === NOW + 2, '錯題複習答錯 → 回到錯題，記下輪流時間');
r = C.applyAnswer(r, 'fill', true, 'learn', T, NOW + 3);
ok(r.s === 'learned' && r.lv === 0 && r.due === C.addDays(T, 1), '填空答對 → 學會，1 天後複習');
const due = { s: 'learned', n: 5, w: {}, lv: 2, due: T, st: 0, t: 1 };
r = C.applyAnswer(due, 'fill', true, 'due', T, NOW);
ok(r.lv === 3 && r.due > C.addDays(T, 10) && r.due < C.addDays(T, 18) && r.dd === T, '到期複習答對 → 升一級（14 天 ±15%）、記下今天做過');
r = C.applyAnswer({ ...due, lv: 4 }, 'fill', false, 'due', T, NOW);
ok(r.lv === 2 && r.due === C.addDays(T, C.SRS[2]), '學會的字答錯 → 降兩級');
r = C.applyAnswer({ ...due, due: C.addDays(T, 5) }, 'fill', true, 'learned', T, NOW);
ok(r.lv === 2 && r.due === C.addDays(T, 5), '還沒到期答對 → 不延長');
r = C.applyAnswer({ s: 'excluded', n: 0, w: {}, lv: 0, due: '', st: 0, t: 0 }, 'fill', true, 'all', T, NOW);
ok(r.s === 'excluded', '已排除的字答對 → 還是排除');
r = C.applyAnswer(C.blankRec(), 'kana', true, 'learn', T, NOW);
ok(r.s === 'new' && r.st === 1, '假名答對一次 → 連對 1，還沒學會');
r = C.applyAnswer(r, 'kana', true, 'learn', T, NOW);
ok(r.s === 'learned', '假名連對兩次 → 學會');
r = C.applyAnswer(r, 'kana', false, 'learn', T, NOW);
ok(r.st === 0, '假名答錯 → 連對歸零');
const orig = { s: 'queued', n: 0, w: {}, lv: 0, due: '', st: 0, t: 0 };
C.applyAnswer(orig, 'mc', false, 'learn', T, NOW);
ok(orig.n === 0 && !orig.w.mc, 'applyAnswer 不改到原本的紀錄');

// ---- 出題 ----
const items = Array.from({ length: 30 }, (_, i) => ({ id: 'w' + i }));
const recs = { w5: { w: { mc: 1 }, n: 9 }, w7: { w: { mc: 2 }, n: 9 } };
for (let k = 0; k < 20; k++) {
  const q = C.pickRound(items, id => recs[id], 'mc', 5);
  ok(q.length === 5 && q.some(x => x.id === 'w5') && q.some(x => x.id === 'w7'), '錯題先出');
}
const rv = { a: { rv: { mc: 3 } }, b: { rv: { mc: 1 } }, c: { rv: { mc: 2 } } };
const q2 = C.pickRound([{ id: 'a' }, { id: 'b' }, { id: 'c' }], id => rv[id], 'mc', 2, true).map(x => x.id).sort().join();
ok(q2 === 'b,c', '錯題複習：最久沒出現的先抽');

// ---- 合併 ----
const m = C.mergeState({ items: { x: { t: 5, s: 'learned' }, y: { t: 1 } }, days: { [T]: 3 } }, { items: { x: { t: 4, s: 'new' }, z: { t: 2 } }, days: { [T]: 7 } });
ok(m.items.x.s === 'learned' && m.items.y && m.items.z && m.days[T] === 7, '合併：留比較新的那筆，題數取大');

// ---- 備份碼 ----
const st = { items: {
  'あ': { s: 'learned', n: 12, w: { mc: 2, fill: 1, kana: 2 }, lv: 3, due: '2026-11-20', st: 4, t: Date.UTC(2026, 10, 7, 3, 21), q: Date.UTC(2026, 10, 1, 9, 0) },
  'it:casa': { s: 'queued', n: 2, w: { mc: 1 }, lv: 0, due: '', st: 0, t: Date.UTC(2026, 10, 6, 1, 2) },
  'ru:дом': { s: 'excluded', n: 0, w: {}, lv: 0, due: '', st: 0, t: Date.UTC(2026, 10, 5) }
}, days: { [T]: 15, '2026-11-06': 4, '2026-10-01': 9 } };
const code = C.packState(st, T);
ok(/^N5\./.test(code), '備份碼以 N5. 開頭');
const back = C.unpackState(code, Object.keys(st.items).concat(['其他']));
for (const id in st.items) ok(JSON.stringify(back.items[id]) === JSON.stringify(st.items[id]), '備份碼來回一樣：' + id + ' ' + JSON.stringify(back.items[id]));
ok(back.days[T] === 15 && back.days['2026-11-06'] === 4 && !back.days['2026-10-01'], '備份碼只帶最近 7 天題數');
const onlyIt = C.unpackState(code, ['it:casa']);
ok(Object.keys(onlyIt.items).join() === 'it:casa' && onlyIt.unknown === 2, '只取自己的字，其他算 unknown');
ok(C.unpackState('亂打', []) === null, '格式不對 → null');

// 自己新增的單字：定義在紀錄的 c 欄位，作答、合併都不能弄丟
{
  const mine = { s: 'queued', n: 0, w: {}, lv: 0, due: '', st: 0, t: NOW, c: { w: 'whisker', zh: '鬍鬚', p: 'n' } };
  const a = C.applyAnswer(mine, 'fill', true, 'learn', T, NOW + 1);
  ok(a.s === 'learned' && a.c && a.c.zh === '鬍鬚', '自己新增的單字答題後定義（c）還在');
  const gone = { ...C.blankRec(), t: NOW + 5 };
  const m1 = C.mergeState({ items: { 'en:my:whisker': a }, days: {} }, { items: { 'en:my:whisker': gone }, days: {} });
  ok(!m1.items['en:my:whisker'].c, '刪除（比較新的空白紀錄）合併後定義不會跑回來');
  const m2 = C.mergeState({ items: { 'en:my:whisker': gone }, days: {} }, { items: { 'en:my:whisker': { ...a, t: NOW + 9 } }, days: {} });
  ok(m2.items['en:my:whisker'].c.w === 'whisker', '之後又新增一次（更新的紀錄）會留下來');
}

// 以前「我的造句」存的句子在紀錄的 u 欄位（功能已拿掉）：作答、合併都不能把舊資料弄丟
{
  const rec = { s: 'queued', n: 0, w: {}, lv: 0, due: '', st: 0, t: NOW, u: [{ s: 'The cat has long whiskers.', t: NOW }] };
  const a = C.applyAnswer(rec, 'fill', false, 'learn', T, NOW + 1);
  ok(a.u && a.u.length === 1 && a.u[0].s === 'The cat has long whiskers.', '答題後自己寫的句子（u）還在');
  const m = C.mergeState({ items: { 'en:cat|n': rec }, days: {} }, { items: { 'en:cat|n': { ...a, u: a.u.concat({ s: 'Cats sleep a lot.', t: NOW + 2 }), t: NOW + 3 } }, days: {} });
  ok(m.items['en:cat|n'].u.length === 2, '合併留下比較新的那筆（兩個句子）');
}

(async () => {
  const big = { items: {}, days: {} };
  for (let i = 0; i < 400; i++) big.items['it:w' + i] = { s: 'learned', n: i % 7, w: {}, lv: i % 6, due: '2026-12-0' + (1 + i % 9), st: 0, t: NOW - i * 6e4 };
  const plain = C.packState(big, T), z = await C.zipCode(plain);
  ok(z.startsWith('N5Z.') && z.length < plain.length, '長的備份碼會壓縮（' + plain.length + ' → ' + z.length + ' 字）');
  ok(await C.unzipCode(z) === plain, '壓縮碼解得回來');
  console.log(fail ? `${n} 項檢查，${fail} 項失敗` : `${n} 項檢查，0 項失敗`);
  process.exit(fail ? 1 : 0);
})();
