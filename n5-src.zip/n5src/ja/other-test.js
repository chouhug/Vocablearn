// 日文填空「填的是另一個字」（engine.js 的 otherWordsOf）：node n5src/ja/other-test.js
const fs = require('fs'), vm = require('vm'), path = require('path');
const D = __dirname;
const build = fs.readFileSync(path.join(D, '..', 'build.js'), 'utf8');
const files = JSON.parse(build.match(/const JA_DATA = (\[[^\]]*\])/)[1]).filter(f => !/i18n/.test(f));
const ctx = { console }; vm.createContext(ctx);
vm.runInContext(files.map(f => fs.readFileSync(path.join(D, f), 'utf8')).join('\n') + '\n;this.W = prepWords(VOCAB); this.other = otherWordsOf; this.check = checkFill;', ctx);
let bad = 0, n = 0; const ok = (c, m) => { n++; if (!c) { console.log('✗ ' + m); bad++; } };
const W = ctx.W, Q = W.filter(w => w.ans);
const q = word => Q.find(x => x.word === word);
const words = (word, inp) => ctx.other(inp, q(word), W).map(x => x.w.word);
const tags = (word, inp) => ctx.other(inp, q(word), W).map(x => x.tag);
ok(words('猫', 'inu').includes('犬'), '猫 填 inu → 標出「犬」');
ok(words('猫', '犬').includes('犬'), '猫 填 犬（漢字）→ 標出「犬」');
ok(words('猫', 'いぬ').includes('犬'), '猫 填 いぬ（假名）→ 標出「犬」');
ok(words('食べる', 'nomimasu').includes('飲む') && tags('食べる', 'nomimasu').includes('ます形・禮貌'), '食べる 填 nomimasu → 飲む 的ます形');
ok(words('寒い', 'atsukatta').includes('暑い') && tags('寒い', 'atsukatta')[0] === '過去式', '寒い 填 atsukatta → 暑い 的過去式');
ok(words('食べる', 'tabeta').length === 0, '填了這題的字自己的其他形：不算另一個字');
ok(words('猫', 'xyz').length === 0, '亂打：沒有結果');
ok(words('猫', '').length === 0, '空白：沒有結果');
ok(ctx.other('atsukatta', q('寒い'), W).length <= 3, '最多列 3 個');
// 所有填空題：答案本身不會被當成另一個字；標出來的字一定不是這題的字
let hits = 0;
for (const w of Q) {
  ok(ctx.other(w.ans, w, W).length === 0 && ctx.other(w.ansR, w, W).length === 0, `${w.word}：填正確答案不該標出別的字`);
  const o = Q[(Q.indexOf(w) * 7 + 3) % Q.length];
  if (o.word === w.word) continue;
  const r = ctx.other(o.word, w, W);
  ok(r.every(x => x.w.id !== w.id), `${w.word} 填 ${o.word}：不該標出這題的字`);
  if (r.length && !ctx.check(w, o.word)) hits++;
}
ok(hits > Q.length / 2, `大部分填了別的單字的情況都要認得出來（${hits}／${Q.length}）`);
console.log(bad ? `✗ ${bad} 項失敗` : `日文填空填了別的字：${n} 項全部通過`);
process.exit(bad ? 1 : 0);
