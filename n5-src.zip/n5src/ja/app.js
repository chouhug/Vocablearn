(function () {
'use strict';
// ================= 基本工具 =================
const $ = (s, r = document) => r.querySelector(s);
const $$ = (s, r = document) => [...r.querySelectorAll(s)];
const GOAL = 20;

// ================= 資料 =================
const KANA = (() => {
  const { H, K } = buildKana();
  const mk = (arr, script) => arr.map(([kana, romaji, cat, row, ex, exZh]) => ({
    id: (script === 'h' ? 'h:' : 'k:') + kana, kana, romaji, cat0: cat, cat: cat === '半濁音' ? '濁音' : cat, row, ex, exZh, script, kind: 'k'
  }));
  return mk(H, 'h').concat(mk(K, 'k'));
})();
const KMAP = Object.fromEntries(KANA.map(k => [k.id, k]));
const WORDS = prepWords(VOCAB.concat(GRAMMAR));
WORDS.forEach((w, i) => { w.en = (typeof EN_LIST !== 'undefined' && EN_LIST[i]) || ''; });
const WMAP = Object.fromEntries(WORDS.map(w => [w.id, w]));
const GLOSS = buildGlossary(WORDS);
const TOKS = {};
const toksOf = w => TOKS[w.id] || (TOKS[w.id] = tokenizeWord(w, GLOSS));
const CMAP = confuseMap();
const ALL_IDS = KANA.map(k => k.id).concat(WORDS.map(w => w.id));
// ---- 我的單字（自己新增的字）----
// 定義放在這個字的進度紀錄裡：S.items['v:my:' + 單字].c = { w 單字, r 讀音, zh 意思, s 例句, sr 例句的讀法, sz 例句中文, a 例句裡的寫法 }
// 合併和 Google 同步都和一般紀錄一樣；刪除＝換成沒有 c 的空白紀錄。表單在 shared/mine.js，語言頁的做法見 lang-app.js。
const MY = 'v:my:';
const KANA_ONLY = /^[ぁ-ゖァ-ヺー・]+$/;
// 沒有讀法的文字切成段：漢字段 r 是空字串，假名和標點 r 是 null
const rawSegs = t => tokenize(t).map(x => ({ t: x.t, r: x.k ? '' : null }));
// 變化形的讀音：食べる（たべる）→ 食べました → たべました。推不出來回傳 ''
function inflectedReading(word, reading, form) {
  const stem = word.replace(/[ぁ-ゖ]+$/, ''), okuri = word.slice(stem.length);
  if (!form.startsWith(stem) || !reading.endsWith(okuri)) return '';
  const tail = form.slice(stem.length);
  if (!/^[ぁ-ゖァ-ヺー]*$/.test(tail)) return '';
  return reading.slice(0, reading.length - okuri.length) + tail;
}
// 例句裡的變化形：語幹（去掉後面的平假名）加上後面接著的平假名，停在です／でした之前
function guessJaForm(sent, word) {
  const stem = word.replace(/[ぁ-ゖ]+$/, '') || word.slice(0, -1);
  if (!stem) return '';
  const at = sent.indexOf(stem);
  if (at < 0) return '';
  const m = sent.slice(at + stem.length).match(/^[ぁ-ゖ]*/)[0].replace(/(です|でし|だっ|だ|の|を|が|は|に|と|で|も|ね|よ|か)+$/, '');
  return stem + m;
}
// 把定義變成和內建單字一樣的資料；內容有問題時回傳 { err: 說明 }
function myWord(id, c) {
  const word = c.w, reading = c.r || c.w;
  if (!KANA_ONLY.test(reading)) return { err: c.r ? '讀音請全部用假名（平假名或片假名）。' : `「${word}」有漢字，請在「讀音」填它的假名。` };
  const wsegs = align(word, reading);
  if (!wsegs) return { err: `讀音「${reading}」和「${word}」對不起來，請檢查假名的部分是不是一樣。` };
  const sent = c.s || word, ans = c.s && c.a ? c.a : word;
  const at = sent.indexOf(ans);
  if (at < 0) return { err: `例句裡找不到「${ans}」。如果這個字在例句裡有變化（例如 食べる → 食べます），請在「例句裡的寫法」填上例句裡的樣子。` };
  // 沒寫讀法的漢字：r 是空字串（不標振り仮名、拼音裡略過）；假名和標點 r 是 null
  const raw = rawSegs;
  let segs;
  if (!c.s) segs = wsegs.map(x => Object.assign({}, x));
  else if (c.sr) {
    segs = align(sent, c.sr);
    if (!segs) return { err: '「例句的讀法」和例句對不起來。請把整句用平假名寫一次（片假名和標點照原樣），或先留空。' };
  } else {
    // 例句裡是變化形（剃る → 剃ります）：用單字的讀音推出它怎麼唸（語幹的讀音＋後面的假名）
    let asegs = ans === word ? wsegs.map(x => Object.assign({}, x)) : null;
    if (!asegs) { const ar = inflectedReading(word, reading, ans); asegs = ar ? align(ans, ar) : null; }
    segs = raw(sent.slice(0, at)).concat(asegs || raw(ans), raw(sent.slice(at + ans.length)));
  }
  let a0 = -1, a1 = -1, pos0 = 0;
  for (let i = 0; i < segs.length; i++) { const st = pos0, en = pos0 + segs[i].t.length; if (st === at) a0 = i; if (en === at + ans.length) a1 = i + 1; pos0 = en; }
  if (a0 < 0 || a1 <= a0) return { err: `「${ans}」在例句裡要是完整的一段（不能切在一個漢字詞的中間）。` };
  if (segs.slice(a0, a1).some(x => x.r === '')) return { err: `「${ans}」有漢字，填空要知道它怎麼唸：請填「例句的讀法」。` };
  const ansR = segs.slice(a0, a1).map(x => x.r === null ? x.t : x.r).join('');
  return { id, word, reading, romaji: kanaToRoma(reading), pos: '我的單字', pg: '我的單字', zh: c.zh, en: '', sent, sentR: segs.map(x => x.r || x.t).join(''), sentZh: c.s ? (c.sz || '') : c.zh,
    ans, segs, wsegs, a0, a1, ansR, kind: 'w', custom: true, noR: segs.some(x => x.r === '') };
}
// 讓 WORDS 跟 S 裡的「我的單字」一致（啟動、存檔、從雲端合併進來之後都要跑）；有變動回傳 true
function syncMine() {
  const want = {};
  for (const id in S.items) if (id.startsWith(MY)) { const c = S.items[id] && S.items[id].c; if (c && c.w && c.zh) { const w = myWord(id, c); if (!w.err) want[id] = w; } }
  let changed = false;
  const drop = (arr, id) => { const i = arr.findIndex(x => (x.id || x) === id); if (i >= 0) arr.splice(i, 1); };
  for (const w of WORDS.filter(w => w.custom && !want[w.id])) { drop(WORDS, w.id); drop(ALL_IDS, w.id); delete WMAP[w.id]; delete TOKS[w.id]; changed = true; }
  for (const id in want) {
    const nw = want[id], old = WMAP[id], key = w => JSON.stringify([w.word, w.reading, w.zh, w.sent, w.sentR, w.sentZh, w.ans]);
    if (!old) { WORDS.push(nw); ALL_IDS.push(id); WMAP[id] = nw; changed = true; }
    else if (key(old) !== key(nw)) { Object.assign(old, nw); delete TOKS[id]; changed = true; }
  }
  if (changed) { PITEMS = null; }
  return changed;
}

// ================= 進度與設定 =================
let S = store.get('n5:progress', null);
if (!S || typeof S !== 'object' || !S.items) S = { items: {}, days: {} };
S.days = S.days || {};
const SET = Object.assign({ vib: 'on', sfx: 'on', round: 20, recent: 'd1', mean: 'zh', lang: 'zh', furi: true, knownLv: '', romaji: false, theme: 'system', voice: '', rate: 0.9 }, store.get('n5:settings', {}));
const UI = Object.assign({ fillMode: 'fill', dictSrc: 'learn', gramOpen: false, kanaSec: 'seion', tab: 'kana', script: 'h', kanaView: 'table', kanaMode: 'k2r', kanaRange: 'all', mcMode: 'jp2zh', conjSet: 'all', mcSrc: 'learn', fillSrc: 'learn', cardSrc: 'new', pos: 'all' }, store.get('n5:ui', {}));
const saveSet = () => store.set('n5:settings', SET);
const saveUI = () => store.set('n5:ui', UI);
const saveLocal = () => store.set('n5:progress', S);
// 別的分頁（語言頁）改了進度時，先合併再寫，不會互相覆蓋
function reloadShared() { const cur = store.get('n5:progress', null); if (cur && cur.items) S = mergeState(S, cur); }
const getRec = id => S.items[id] || blankRec();

// @include shared/i18n.js（介面語言；這一段由 build.js 從 n5src/shared/i18n.js 複製過來）
// @end shared/i18n.js
UIKit.bind({ SET, t: L });   // ui.js 的音效、震動、下拉選單用這頁的設定和翻譯
function putRec(id, rec) { S.items[id] = rec; saveLocal(); Cloud.schedule(); }
function touch(id, patch) {
  const old = getRec(id), now = Date.now();
  const r = Object.assign(JSON.parse(JSON.stringify(old)), patch, { t: now });
  // q：開始學這個字的時間（列入考題時），「最近學過」用它判斷，作答不會再更新
  if (patch.s === 'queued' && old.s !== 'queued' && old.s !== 'learned') r.q = now;
  else if (!r.q && (old.s === 'queued' || old.s === 'learned') && old.t) r.q = old.t;
  putRec(id, r);
}

function bumpDay() {
  const d = today();
  SyncDays.bump(S, d);   // 加一題（只留最近 90 天）
  saveLocal(); Cloud.schedule();   // 只有題數變了（五十音、詞性變化、文法練習）也要同步
  renderGoal();
  if (S.days[d] === GOAL) toast(`今天的 ${GOAL} 題完成了！`, true);
}
function record(item, mode, correct, source) {
  const old = getRec(item.id), now = Date.now();
  const rec = applyAnswer(old, mode, correct, source, today(), now);
  // 舊紀錄沒有 q：用作答前的時間補上，之後作答不再讓它變成「最近學過」
  if (!rec.q && WMAP[item.id] && (rec.s === 'queued' || rec.s === 'learned')) rec.q = (old.s === 'queued' || old.s === 'learned') && old.t ? old.t : now;
  S.items[item.id] = rec;
  bumpDay();
  Cloud.schedule();
}

// ================= 語音 =================
// @include shared/voice.js（這一段由 build.js 從 n5src/shared/voice.js 複製過來，要改請改那個檔再跑 build.js）
// @end shared/voice.js
document.addEventListener('click', e => {
  const b = e.target.closest('[data-say]');
  if (b) { e.preventDefault(); Voice.speak(b.dataset.say); }
});


// ================= 顯示工具 =================
// 按鈕被底部分頁列擋住時，把頁面捲到剛好看得到（不會整頁跳走）
function revealAboveTabbar(el) {
  requestAnimationFrame(() => {
    const bar = $('.tabbar'), r = el.getBoundingClientRect();
    const lim = innerHeight - (bar ? bar.getBoundingClientRect().height : 0) - 12;
    if (r.bottom > lim) window.scrollBy({ top: r.bottom - lim, behavior: matchMedia('(prefers-reduced-motion: reduce)').matches ? 'auto' : 'smooth' });
  });
}
function rubyHTML(segs, opt = {}) {
  let h = '';
  const starts = {}, ends = {};
  if (opt.toks) for (const t of opt.toks) {
    if (!t.e || (opt.blank && t.s0 === opt.blank.a0)) continue;
    starts[t.s0] = t; ends[t.s1 - 1] = (ends[t.s1 - 1] || 0) + 1;
  }
  for (let i = 0; i < segs.length; i++) {
    if (opt.blank && i === opt.blank.a0) { h += opt.blank.html; i = opt.blank.a1 - 1; continue; }
    const t = starts[i];
    if (t) h += `<span class="tk" role="button" tabindex="0" data-e="${esc(t.e)}" data-f="${esc(t.f || '')}" data-s="${esc(segs.slice(t.s0, t.s1).map(x => x.t).join(''))}">`;
    const s = segs[i];
    const on = opt.hl && i >= opt.hl[0] && i < opt.hl[1];
    // 螢光黃只塗在字本身，振り仮名留在外面，不會被蓋住
    const base = on ? `<mark class="${i === opt.hl[0] ? 'ms' : ''}${i === opt.hl[1] - 1 ? ' me' : ''}">${esc(s.t)}</mark>` : esc(s.t);
    if (s.sub) {
      // 逐字標：每個漢字上面是自己的讀音
      const cs = [...s.t];
      h += '<ruby>' + cs.map((c, j) => (on ? `<mark class="${i === opt.hl[0] && j === 0 ? 'ms' : ''}${i === opt.hl[1] - 1 && j === cs.length - 1 ? ' me' : ''}">${esc(c)}</mark>` : esc(c)) + `<rt>${esc(s.sub[j])}</rt>`).join('') + '</ruby>';
    } else h += s.r ? `<ruby>${base}<rt>${esc(s.r)}</rt></ruby>` : base;
    if (ends[i]) h += '</span>'.repeat(ends[i]);
  }
  return h;
}
const wordHTML = w => rubyHTML(w.wsegs);
// 依設定顯示中文、英文或兩者
function meanText(zh, en) {
  if (SET.mean === 'en' && en) return `<span lang="en">${esc(en)}</span>`;
  if (SET.mean === 'both' && en) return `${esc(zh)} <span class="en" lang="en">${esc(en)}</span>`;
  return esc(zh);
}
const meanW = w => meanText(w.zh, w.en);
const meanPlain = w => SET.mean === 'en' && w.en ? w.en : SET.mean === 'both' && w.en ? `${w.zh} / ${w.en}` : w.zh;
// 五十音例字的意思：English 介面用 i18n.js 的對照
const exMean = (ja, zh) => (I18 && I18.kanaEx[ja]) || zh;
const sentHTML = (w, hl = true) => rubyHTML(w.segs, Object.assign({ toks: toksOf(w) }, hl && w.a0 >= 0 ? { hl: [w.a0, w.a1] } : {}));
const romajiLine = txt => `<div class="romaji">${esc(txt)}</div>`;
function exampleBlock(w) {
  return `<div class="example">
    <div class="ex-row"><div class="sent" lang="ja">${sentHTML(w)}</div>${iconPlay(w.sent, '播放例句')}</div>
    ${romajiLine(segsRomaji(w.segs))}
    <div class="zhline">${esc(w.sentZh)}</div>
  </div>`;
}
function applyFuri() {
  document.body.classList.toggle('hide-furi', !SET.furi);
  const b = $('#furiBtn');
  b.setAttribute('aria-pressed', String(!!SET.furi));
  b.title = SET.furi ? '漢字上的假名：開（點一下隱藏）' : '漢字上的假名：關（點一下顯示）';
  b.setAttribute('aria-label', b.title);
}
function applyRomaji() { document.body.classList.toggle('hide-romaji', !SET.romaji); $('#romajiBtn').setAttribute('aria-pressed', String(!!SET.romaji)); }
function applyTheme() {
  // 只有淺色、深色兩種；第一次打開（或舊設定是「跟隨系統」）時，照手機目前的模式決定
  if (SET.theme !== 'light' && SET.theme !== 'dark') { SET.theme = matchMedia('(prefers-color-scheme: dark)').matches ? 'dark' : 'light'; saveSet(); }
  const root = document.documentElement;
  if (SET.theme === 'light' || SET.theme === 'dark') root.setAttribute('data-theme', SET.theme); else root.removeAttribute('data-theme');
  const b = $('#themeBtn');
  const map = { light: [ICON.sun, '外觀：淺色'], dark: [ICON.moon, '外觀：深色'] };
  const [ic, lb] = map[SET.theme];
  b.innerHTML = ic; b.setAttribute('aria-label', lb + '（點一下切換）'); b.title = lb;
}
function renderGoal() {
  const n = S.days[today()] || 0;
  $('#goalText').textContent = `今日 ${n}/${GOAL} 題${n >= GOAL ? ' ✓' : ''}`;
  $('#goalBar').style.width = Math.min(100, n / GOAL * 100) + '%';
}

// ================= 題庫篩選 =================
const POS_FILTERS = [['all', '全部'], ['名詞', '名詞'], ['動詞', '動詞'], ['い形容詞', 'い形容詞'], ['な形容詞', 'な形容詞'], ['副詞', '副詞'], ['指示詞・連接詞', '指示連接'], ['數字與時間', '數字時間'], ['招呼語與常用句', '招呼語'], ['文法', '文法']];
const posOK = w => UI.pos === 'all' || w.pg === UI.pos;
const wrongOf = (id, m) => (getRec(id).w || {})[m] || 0;
// 今天要做的到期複習：到期越久、等級越低的先出；每天最多 SET.dueCap 個（做過的也算在內）
const DUE_CAPS = [10, 20, 30, 50, 'all'];
const dueCap = () => SET.dueCap === 'all' ? Infinity : (Number(SET.dueCap) || 30);
function dueAll() { const t = today(); return WORDS.filter(w => { const r = getRec(w.id); return r.s === 'learned' && r.due && r.due <= t; }); }
function dueToday() {
  const t = today();
  const done = WORDS.filter(w => getRec(w.id).dd === t).length;
  const left = Math.max(0, dueCap() - done);
  const list = dueAll().sort((a, b) => { const x = getRec(a.id), y = getRec(b.id); return x.due < y.due ? -1 : x.due > y.due ? 1 : (x.lv || 0) - (y.lv || 0); });
  return new Set(list.slice(0, left).map(w => w.id));
}
function wordPool(src) {
  const t = today();
  const f = {
    new: w => getRec(w.id).s === 'new',
    learn: w => getRec(w.id).s === 'queued',
    queued: w => getRec(w.id).s === 'queued',
    learned: w => getRec(w.id).s === 'learned',
    recent: (() => { let set; return w => (set || (set = recentIds())).has(w.id); })(),
    due: (() => { let set; return w => (set || (set = dueToday())).has(w.id); })(),
    mcWrong: w => wrongOf(w.id, 'mc') === 1,
    mcReview: w => wrongOf(w.id, 'mc') === 2,
    fillWrong: w => wrongOf(w.id, 'fill') === 1,
    fillReview: w => wrongOf(w.id, 'fill') === 2,
    mine: w => !!w.custom,
    dictWrong: w => wrongOf(w.id, 'dict') === 1,
    excluded: w => getRec(w.id).s === 'excluded'
  }[src];
  return WORDS.filter(w => f(w));
}
const filtered = src => wordPool(src).filter(posOK);
function posChips() {
  return `<span class="pw"><select class="pill${UI.pos !== 'all' ? ' on' : ''}" data-possel aria-label="詞性">${POS_FILTERS.map(([k, l]) => `<option value="${k}"${UI.pos === k ? ' selected' : ''}>${k === 'all' ? '詞性' : l}</option>`).join('')}</select></span>`;
}
function bindPos(root, cb) { const sel = $('[data-possel]', root); if (sel) sel.onchange = () => { UI.pos = sel.value; saveUI(); cb(); }; }

// ================= 點單字看意思 =================
function glossInfo(e) {
  if (e.startsWith('v:')) { const w = WMAP[e]; return w && { w, word: w.word, reading: w.reading, romaji: w.romaji, zh: w.zh, pos: w.pos }; }
  if (e.startsWith('f:')) { const k = e.slice(2), v = FUNC[k]; return v && { word: k, reading: v[0], romaji: kanaToRoma(v[0]), zh: v[1], pos: '助詞・語尾' }; }
  if (e.startsWith('x:')) { const k = e.slice(2), v = EXTRA[k]; return v && { word: k, reading: v[0], romaji: kanaToRoma(v[0]), zh: v[1], pos: v[2] }; }
  return null;
}
let tkOn = null;
function closeGloss() { formsStack = []; const p = $('#gloss'); if (p) { p.hidden = true; p.classList.remove('tall'); } if (tkOn) tkOn.classList.remove('on'); tkOn = null; }
function openGloss(el) {
  const info = glossInfo(el.dataset.e);
  if (!info) return;
  if (tkOn) tkOn.classList.remove('on');
  tkOn = el; el.classList.add('on');
  const p = $('#gloss');
  p.classList.remove('tall');
  const r = info.w ? getRec(info.w.id) : null;
  const surface = el.dataset.s, form = el.dataset.f;
  const head = info.w ? wordHTML(info.w) : esc(info.word);
  const showReading = !info.w || !info.w.wsegs.some(x => x.r);
  p.innerHTML = `<div class="gl-top"><div class="gl-word" lang="ja">${head}</div><button class="gl-x" aria-label="關閉">${ICON.ng}</button></div>
    ${showReading && info.reading !== info.word ? `<div class="meta ja">${esc(info.reading)}</div>` : ''}
    ${romajiLine(info.romaji)}
    <div class="gl-zh"><span class="pos">${esc(info.pos)}</span> ${info.w ? meanW(info.w) : esc(info.zh)}</div>
    ${surface && surface !== info.word && form ? `<div class="meta">句中的「<span class="ja">${esc(surface)}</span>」：${esc(form)}</div>` : ''}
    <div class="row">${playBtn(info.reading, '發音')}${info.w && info.w.pg !== '文法' ? `<button class="btn quiet" data-forms="${esc(info.w.id)}" style="min-height:44px">${info.w.custom ? '編輯' : '變化形・詞性'}</button>` : ''}${r ? `<span class="st ${r.s}">${STATUS_TXT[r.s] || '未學'}</span>` : ''}${r && (r.s === 'new' || r.s === 'excluded') ? `<button class="btn" id="glQ" style="min-height:44px">列入考題</button>` : ''}</div>`;
  p.hidden = false;
  $('.gl-x', p).onclick = closeGloss;
  const q = $('#glQ', p);
  if (q) q.onclick = () => { touch(info.w.id, { s: 'queued' }); toast('已列入考題'); openGloss(el); };
}
document.addEventListener('click', e => {
  const tk = e.target.closest('.tk');
  if (tk) {
    e.preventDefault();
    const sheet = $('#gloss');
    if (sheet && sheet.classList.contains('tall') && sheet.contains(tk)) { showPeek(tk); return; }
    if (tk === tkOn) closeGloss(); else openGloss(tk);
    return;
  }
  if (!e.target.closest('#gloss')) closeGloss();
});
document.addEventListener('keydown', e => {
  if (e.key === 'Escape') closeGloss();
  if ((e.key === 'Enter' || e.key === ' ') && e.target.classList && e.target.classList.contains('tk')) { e.preventDefault(); openGloss(e.target); }
});

// ================= 語法補充 =================
const lvRank = lv => GLOSS_LEVELS.length - GLOSS_LEVELS.indexOf(lv); // N5=1 … N1=5
function grammarFor(w) {
  if (w.custom) return { all: [], shown: [], hidden: 0 };
  const all = grammarOf(w, toksOf(w), GLOSS);
  const cut = SET.knownLv ? lvRank(SET.knownLv) : 0;
  const shown = all.filter(g => lvRank(g.p.lv) > cut);
  return { all, shown, hidden: all.length - shown.length };
}
function grammarButton(w) {
  const g = grammarFor(w);
  return `<button class="gbtn" id="gbtn" aria-expanded="${!!UI.gramOpen}" aria-controls="gpanel">文法${g.shown.length ? ` <b>${g.shown.length}</b>` : ''}</button>`;
}
function grammarPanel(w) {
  const g = grammarFor(w);
  let body;
  if (!g.all.length) body = '<p class="meta">這句是固定的招呼語，整句記起來就好，不用拆文法。</p>';
  else if (!g.shown.length) body = `<p class="meta">這句的文法都在你已經會的等級（${esc(SET.knownLv)} 以下）。可以到「單字庫 → 文法補充」調整。</p>`;
  else body = g.shown.map(x => `<div class="gp-item">
      <div class="gp-h"><b>${esc(x.p.t)}</b><span class="lv">${x.p.lv}</span></div>
      <div class="meta">句中：<span class="ja gp-s">${esc(x.s)}</span></div>
      <div>${esc(x.p.d)}</div><button class="gp-more" data-gram="${x.p.id}">看更多例句 ›</button></div>`).join('') + (g.hidden ? `<p class="meta">另有 ${g.hidden} 個已經會的文法沒有顯示。</p>` : '');
  return `<div class="gpanel" id="gpanel"${UI.gramOpen ? '' : ' hidden'}><div class="gp-title">這句例句用到的文法</div>${body}</div>`;
}
function bindGrammar(host) {
  const b = $('#gbtn', host), p = $('#gpanel', host);
  if (!b || !p) return;
  b.onclick = () => { UI.gramOpen = !UI.gramOpen; saveUI(); p.hidden = !UI.gramOpen; b.setAttribute('aria-expanded', String(UI.gramOpen)); };
}

// ================= 詞形變化 =================
let formsStack = [];
function openForms(id, fromBack) {
  const w = WMAP[id];
  if (!w) return;
  const sheetOpen = $('#gloss').classList.contains('tall') && !$('#gloss').hidden;
  if (!fromBack) { if (!sheetOpen) formsStack = []; if (formsStack[formsStack.length - 1] !== id) formsStack.push(id); }
  if (tkOn) { tkOn.classList.remove('on'); tkOn = null; }
  const ti = typeInfo(w), rows = conjugate(w);
  const p = $('#gloss');
  const canBack = formsStack.length > 1;
  p.innerHTML = `<div class="gl-top">${canBack ? `<button class="gl-back" aria-label="返回上一個字">‹ 返回</button>` : ''}<div class="gl-word" lang="ja">${wordHTML(w)}</div><button class="gl-x" aria-label="關閉">${ICON.ng}</button></div>
    <div class="gl-scroll">
      <div class="fm-type"><span class="pos">${esc(w.pos)}</span> <b>${esc(ti.title)}</b></div>
      ${ti.desc ? `<p class="fm-desc">${esc(ti.desc)}</p>` : ''}
      ${ti.extra ? `<p class="fm-note">${esc(ti.extra)}</p>` : ''}
      ${rows.length ? `<div class="label">主要變化（點一行看例句）</div><div class="fm-list">${rows.map((r, i) => `<div class="fm-item">
          <div class="fm-row">
            <button class="fm-tg" data-fmi="${i}" aria-expanded="false">
              <span class="fm-l">${esc(r.label)}</span>
              <span class="fm-s"><span class="ja">${esc(r.s)}</span>${r.r !== r.s ? `<small class="ja">${esc(r.r)}</small>` : ''}<small class="romaji">${esc(kanaToRoma(r.r))}</small></span>
              <span class="fm-n">${esc(r.note)}</span>
            </button>
            <button class="fm-say" data-say="${esc(r.r)}" aria-label="播放 ${esc(r.s)}">${ICON.play}</button>
          </div>
          <div class="fm-ex" id="fmx${i}" hidden></div></div>`).join('')}</div>` : '<p class="meta">這類詞不會變化，直接記住就好。</p>'}
    </div>`;
  p.hidden = false;
  p.classList.add('tall');
  $('.gl-x', p).onclick = closeGloss;
  const back = $('.gl-back', p);
  if (back) back.onclick = () => { formsStack.pop(); openForms(formsStack[formsStack.length - 1], true); };
  $$('.fm-tg', p).forEach(btn => btn.onclick = () => {
    const i = +btn.dataset.fmi, box = $('#fmx' + i, p);
    const open = box.hidden;
    if (open && !box.dataset.done) { box.innerHTML = formExamplesHTML(w, rows[i]); box.dataset.done = '1'; }
    box.hidden = !open;
    btn.setAttribute('aria-expanded', String(open));
  });
}
const FX_CACHE = {};
function exampleLine(segs, toks, hl, zh, plain) {
  return `<div class="fx">
    <div class="sent fx-s" lang="ja">${rubyHTML(segs, { toks, hl })}</div>
    ${romajiLine(segsRomaji(segs))}
    <div class="fx-zh">${esc(zh)}</div>
    <div>${playBtn(plain, '例句')}</div></div>`;
}
// 在變化表的例句裡點字：就地顯示意思，不離開變化表
function showPeek(tk) {
  const box = tk.closest('.fx') || tk.closest('.gl-scroll');
  if (!box) return;
  const was = $('.tk.on', $('#gloss'));
  $$('.peek', $('#gloss')).forEach(x => x.remove());
  $$('.tk.on', $('#gloss')).forEach(x => x.classList.remove('on'));
  if (was === tk) return; // 再點一次同一個字就收起來
  const info = glossInfo(tk.dataset.e);
  if (!info) return;
  tk.classList.add('on');
  const surface = tk.dataset.s, form = tk.dataset.f;
  const showReading = !info.w || !info.w.wsegs.some(x => x.r);
  const d = document.createElement('div');
  d.className = 'peek';
  d.innerHTML = `<div class="pk-top"><span class="pk-w" lang="ja">${info.w ? wordHTML(info.w) : esc(info.word)}</span>${showReading && info.reading !== info.word ? `<span class="meta ja">${esc(info.reading)}</span>` : ''}<button class="pk-x" aria-label="收起">${ICON.ng}</button></div>
    ${romajiLine(info.romaji)}
    <div><span class="pos">${esc(info.pos)}</span> <b>${info.w ? meanW(info.w) : esc(info.zh)}</b></div>
    ${surface && surface !== info.word && form ? `<div class="meta">句中的「<span class="ja">${esc(surface)}</span>」：${esc(form)}</div>` : ''}
    <div class="row">${playBtn(info.reading, '發音')}${info.w && info.w.pg !== '文法' && info.w.id !== formsStack[formsStack.length - 1] ? `<button class="btn quiet" data-forms="${esc(info.w.id)}" style="min-height:40px">看它的變化形</button>` : ''}</div>`;
  box.appendChild(d);
  $('.pk-x', d).onclick = () => { d.remove(); tk.classList.remove('on'); };
  d.scrollIntoView({ block: 'nearest', behavior: 'smooth' });
}
function formExamplesHTML(w, row) {
  const parts = [];
  const mine = corpusExamples(row, w, WORDS, 2);
  if (mine.length) parts.push(`<div class="fx-h">用到「${esc(row.s)}」的例句</div>` + mine.map(m => exampleLine(m.x.segs, toksOf(m.x), segRange(m.x.segs, m.start, row.s.length), m.x.sentZh, m.x.sent)).join(''));
  const key = w.pg + '|' + row.label;
  const list = FORM_EXAMPLES[key] || [];
  if (list.length) {
    const fx = FX_CACHE[key] || (FX_CACHE[key] = list.map(([t, r, zh, h]) => prepSentence(t, r, zh, h, GLOSS)));
    const other = !fx.some(x => x.plain.includes(row.s));
    parts.push(`<div class="fx-h">句型範例${other ? `：用其他${w.pg === '動詞' ? '動詞' : '詞'}示範「${esc(row.label)}」的用法，換成「${esc(row.s)}」也是一樣的道理` : ''}</div>` + fx.map(x => exampleLine(x.segs, x.toks, x.hl, x.zh, x.plain)).join(''));
  }
  return parts.join('') || '<p class="meta">還沒有這個形的例句。</p>';
}
document.addEventListener('click', e => {
  const am = e.target.closest('[data-addmine]');
  if (am) { e.preventDefault(); closeGloss(); return editMine('', am.dataset.addmine, true); }
  const fm = e.target.closest('[data-forms]');
  if (fm && WMAP[fm.dataset.forms] && WMAP[fm.dataset.forms].custom) { e.preventDefault(); closeGloss(); return editMine(fm.dataset.forms); }   // 自己新增的字沒有變化表：直接開編輯
  const b = e.target.closest('[data-forms]');
  if (b) { e.preventDefault(); e.stopPropagation(); openForms(b.dataset.forms); }
}, true);

// ================= 分頁 =================
const TABS = ['kana', 'mc', 'card', 'fill', 'gram', 'lib'];
function showTab(t) {
  UI.tab = t; saveUI();
  TABS.forEach(x => { $('#tab-' + x).hidden = x !== t; });
  $$('.tabbar button').forEach(b => b.setAttribute('aria-current', b.dataset.tab === t ? 'page' : 'false'));
  document.body.classList.remove('typing');
  Quiz.active = null;
  closeGloss();
  ({ kana: renderKana, mc: renderMC, card: renderCard, fill: renderFill, gram: renderGram, lib: renderLib })[t]();
  window.scrollTo(0, 0);
}
$$('.tabbar button').forEach(b => b.onclick = () => showTab(b.dataset.tab));
$('#furiBtn').onclick = () => { SET.furi = !SET.furi; saveSet(); applyFuri(); toast(SET.furi ? '顯示漢字的假名' : '已隱藏假名，點單字可以看讀音'); };
$('#romajiBtn').onclick = () => { SET.romaji = !SET.romaji; saveSet(); applyRomaji(); };
$('#themeBtn').onclick = () => { SET.theme = SET.theme === 'dark' ? 'light' : 'dark'; saveSet(); applyTheme(); };

// ================= 通用選擇題 =================
// q = { head, promptHTML, options:[{html, cls, correct}], onAnswer(correct, idx), afterHTML(correct) }
const Quiz = { active: null };
function renderChoice(host, q, onNext) {
  const letters = 'ABCD';
  host.innerHTML = `<div class="card qcard">
    ${q.head}
    <div class="prompt">${q.promptHTML}</div>
    <div class="opts">${q.options.map((o, i) => `<button class="opt" data-i="${i}"><span class="k">${letters[i]}</span><span class="t ${o.cls || ''}">${o.html}</span></button>`).join('')}</div>
    <div class="after"></div>
  </div>`;
  const state = { answered: false, next: onNext, host };
  Quiz.active = state;
  const choose = i => {
    if (state.answered) return;
    state.answered = true;
    const ok = !!q.options[i].correct;
    $$('.opt', host).forEach((b, j) => {
      b.disabled = true;
      if (q.options[j].correct) b.classList.add('right');
      else if (j === i) b.classList.add('wrong');
    });
    q.onAnswer(ok, i);
    ok ? Sfx.ok() : Sfx.ng(); buzz(ok);
    const after = $('.after', host);
    if (ok) {
      after.innerHTML = `<div class="afterbox">${verdict(true)}${q.explain || ''}<button class="btn solid block" data-next>下一題（Enter）</button></div>`;
      if (!q.noAuto) state.timer = setTimeout(() => { if (Quiz.active === state) onNext(); }, 900);
    } else {
      after.innerHTML = `<div class="afterbox">${verdict(false)}${q.explain || ''}<button class="btn solid block" data-next>下一題（Enter）</button>${q.afterHTML ? q.afterHTML(false) : ''}</div>`;
    }
    const nb = $('[data-next]', after);
    nb.onclick = () => { clearTimeout(state.timer); onNext(); };
    if (!ok) nb.focus({ preventScroll: true });
    if (!ok) revealAboveTabbar(nb);
  };
  state.choose = choose;
  state.goNext = () => { if (state.answered) { clearTimeout(state.timer); onNext(); } };
  $$('.opt', host).forEach(b => b.onclick = () => choose(+b.dataset.i));
}
document.addEventListener('keydown', e => {
  const tag = (e.target.tagName || '').toLowerCase();
  if (tag === 'input' || tag === 'textarea' || tag === 'select') return;
  if (e.metaKey || e.ctrlKey || e.altKey) return;
  const st = Quiz.active;
  if (!st || !st.host.isConnected || st.host.closest('.tab').hidden) return;
  const k = e.key.toLowerCase();
  const idx = '1234'.indexOf(k) >= 0 ? '1234'.indexOf(k) : 'abcd'.indexOf(k);
  if (idx >= 0 && k.length === 1 && !st.answered) { e.preventDefault(); if ($$('.opt', st.host)[idx]) st.choose(idx); }
  else if (k === 'enter' && st.answered) { e.preventDefault(); st.goNext(); }
});
function progressLine(round, total) {
  const left = round.queue.length - round.idx;
  const done = round.queue.length ? (round.idx / round.queue.length) * 100 : 0;
  return `<span class="qprog" aria-label="本輪還剩 ${left} 題，此分類共 ${total} 題"><i style="width:${done}%"></i></span><span class="meta">剩 ${left} · 共 ${total}</span>`;
}
const REVIEW_ROUND = 10;
const roundSize = () => SET.round === 'all' ? 100000 : (Number(SET.round) || 20);
// 「最近學過」的範圍：d1 = 最近 1 天，c20 = 最近學過的 20 個字
const RECENT_OPTS = [['d1', '最近 1 天'], ['d3', '最近 3 天'], ['d7', '最近 7 天'], ['c10', '最近 10 個字'], ['c20', '最近 20 個字'], ['c30', '最近 30 個字'], ['c50', '最近 50 個字']];
function recentLabel() { return (RECENT_OPTS.find(x => x[0] === SET.recent) || RECENT_OPTS[0])[1]; }
function recentIds() {
  const v = SET.recent || 'd1', n = parseInt(v.slice(1), 10) || 1;
  const cand = WORDS.filter(w => { const r = getRec(w.id); return (r.s === 'queued' || r.s === 'learned') && recentT(w.id) > 0; });
  if (v[0] === 'c') return new Set(cand.sort((a, b) => recentT(b.id) - recentT(a.id)).slice(0, n).map(w => w.id));
  const since = Date.now() - n * 864e5;
  return new Set(cand.filter(w => recentT(w.id) >= since).map(w => w.id));
}
const recentT = id => { const r = getRec(id); return r.q || r.t || 0; };
// 「最近學過」不套用詞性篩選（篩選器在這個來源被範圍選單取代）
const srcPool = src => src === 'recent' ? wordPool('recent') : filtered(src);
// 「最近學過」的範圍本身就是要複習的量，一輪就出完範圍內的全部字
const recentQueue = pool => shuffle(pool.slice());
function recentCtl(onChange) { return { html: pillSelect('recentSel', '最近學過的範圍', RECENT_OPTS, SET.recent), bind: host => { const rs = $('#recentSel', host); if (rs) rs.onchange = e => { SET.recent = e.target.value; saveSet(); mcRound = null; fillRound = null; onChange(); }; } }; }

// ================= 五十音 =================
let kanaSel = null;
let kanaRound = null;
function kanaStatus(id) { const r = getRec(id); return r.s === 'learned' ? 2 : (r.n > 0 ? 1 : 0); }
function renderKana() {
  const host = $('#tab-kana');
  host.innerHTML = `
    <div class="segrow"><div class="seg" role="group" aria-label="假名">
      <button data-script="h" aria-pressed="${UI.script === 'h'}">平假名</button>
      <button data-script="k" aria-pressed="${UI.script === 'k'}">片假名</button>
    </div>
    <div class="seg" role="group" aria-label="檢視">
      <button data-kview="table" aria-pressed="${UI.kanaView === 'table'}">五十音表</button>
      <button data-kview="quiz" aria-pressed="${UI.kanaView === 'quiz'}">練習</button>
    </div></div>
    <div id="kanaBody" style="display:flex;flex-direction:column;gap:16px"></div>`;
  $$('[data-script]', host).forEach(b => b.onclick = () => { UI.script = b.dataset.script; saveUI(); kanaSel = null; kanaRound = null; renderKana(); });
  $$('[data-kview]', host).forEach(b => b.onclick = () => { UI.kanaView = b.dataset.kview; saveUI(); kanaRound = null; renderKana(); });
  if (UI.kanaView === 'table') renderKanaTable(); else renderKanaQuiz();
}
const rowLabel = row => UI.script === 'h' ? row : toKata(row.replace('行', '')) + (row.endsWith('行') ? '行' : '');
function renderKanaTable() {
  const list = KANA.filter(k => k.script === UI.script);
  const rows = {};
  list.forEach(k => { (rows[k.row] = rows[k.row] || []).push(k); });
  const cell = k => k ? `<button class="kc s${kanaStatus(k.id)}${kanaSel === k.id ? ' sel' : ''}" data-k="${k.id}" aria-label="${k.kana} ${k.romaji}"><span class="kk${[...k.kana].length > 1 ? ' kk2' : ''}" lang="ja">${k.kana}</span><span class="rr">${k.romaji}</span></button>` : '<span class="kc kgap" aria-hidden="true"></span>';
  let seion = '', daku = '', you = '';
  for (const [cat, row] of KANA_ROWS) {
    const arr = rows[rowLabel(row)] || [];
    if (cat === '清音') {
      if (row === 'や行') seion += [arr[0], null, arr[1], null, arr[2]].map(cell).join('');
      else if (row === 'わ行') seion += [arr[0], null, null, null, arr[1]].map(cell).join('');
      else if (row === 'ん') seion += [arr[0], null, null, null, null].map(cell).join('');
      else seion += arr.map(cell).join('');
    } else if (cat === '拗音') you += arr.map(cell).join('');
    else daku += arr.map(cell).join('');
  }
  const learned = list.filter(k => kanaStatus(k.id) === 2).length;
  const body = $('#kanaBody');
  body.innerHTML = `
    <div class="row" style="justify-content:space-between">
      <div class="legend"><span><i class="l2"></i>已學會</span><span><i class="l1"></i>練習中</span><span><i></i>還沒學</span></div>
      <span class="meta">已學會 ${learned}/${list.length}</span>
    </div>
    <div id="kdetail"></div>
    <div class="chips" role="group" aria-label="表格分類">${[['seion', '清音 46'], ['daku', '濁音・半濁音 25'], ['you', '拗音 33']].map(([k, l]) => `<button class="chip" data-ksec="${k}" aria-pressed="${UI.kanaSec === k}">${l}</button>`).join('')}</div>
    ${UI.kanaSec === 'you' ? `<div class="ktable c3">${you}</div>` : `<div class="ktable c5">${UI.kanaSec === 'daku' ? daku : seion}</div>`}
    ${kanaNotes()}
    <button class="btn solid block" id="toKQ">開始練習${UI.script === 'h' ? '平假名' : '片假名'}</button>`;
  $$('[data-ksec]', body).forEach(b => b.onclick = () => { UI.kanaSec = b.dataset.ksec; saveUI(); renderKanaTable(); });
  $$('[data-k]', body).forEach(b => b.onclick = () => {
    kanaSel = b.dataset.k; const k = KMAP[kanaSel];
    Voice.speak(k.kana);
    $$('.kc.sel', body).forEach(x => x.classList.remove('sel')); b.classList.add('sel');
    showKanaDetail(k);
  });
  $('#toKQ').onclick = () => { UI.kanaView = 'quiz'; saveUI(); renderKana(); };
  if (kanaSel && KMAP[kanaSel] && KMAP[kanaSel].script === UI.script) showKanaDetail(KMAP[kanaSel]);
}
function showKanaDetail(k) {
  const conf = CMAP[k.kana] ? [...CMAP[k.kana]] : [];
  const r = getRec(k.id);
  const stTxt = ['還沒學', '練習中', '已學會'][kanaStatus(k.id)];
  $('#kdetail').innerHTML = `<div class="card kdetail">
    <div class="sqs${[...k.kana].length > 1 ? ' two' : ''}" lang="ja">${[...k.kana].map(ch => `<div class="sq"><span${/[ゃゅょャュョっッぁぃぅぇぉァィゥェォ]/.test(ch) ? ' class="sm"' : ''}>${ch}</span></div>`).join('')}</div>
    <div class="kinfo">
      <div class="rom">${esc(k.romaji)}</div>
      <div class="meta">${esc(k.cat0)} · ${esc(k.row)} · ${stTxt}${r.n ? ` · 作答 ${r.n} 次` : ''}</div>
      ${k.ex ? `<div><span class="ja" style="font-size:20px">${esc(k.ex)}</span> <span class="meta">${esc(kanaToRoma(k.ex))}</span><br>${esc(exMean(k.ex, k.exZh))}</div>` : `<div class="meta">${esc(k.exZh)}</div>`}
      ${conf.length ? `<div class="meta">容易混淆：<span class="ja" style="font-size:18px;color:var(--fg)">${conf.map(esc).join('・')}</span></div>` : ''}
      <div class="row">${playBtn(k.kana, '發音')}${k.ex ? playBtn(k.ex, '例字') : ''}</div>
    </div></div>`;
}
function kanaNotes() {
  const ex = (ja, zh) => `<div class="exitem"><div><span class="ja">${ja}</span> <span class="meta">${esc(kanaToRoma(ja))}</span><br><span>${esc(exMean(ja, zh))}</span></div>${playBtn(ja, '')}</div>`;
  return `<details class="lst"><summary>促音「っ」與長音的說明</summary><div class="notes">
  <div class="note">
    <h3>促音「っ／ッ」</h3>
    <p>寫成小的「っ」，不發音，但要<strong>停頓一拍</strong>，下一個子音像是重複一次。羅馬拼音寫成重複的子音。</p>
    <div class="exlist">${ex('きって', '郵票')}${ex('がっこう', '學校')}${ex('ざっし', '雜誌')}${ex('カップ', '杯子')}</div>
  </div>
  <div class="note">
    <h3>長音</h3>
    <p>母音拉長一拍。平假名用加上母音的方式寫（あ段＋あ、い段＋い、う段＋う、え段＋い或え、お段＋う或お）；片假名用「ー」。長短不同，意思就不同。</p>
    <div class="exlist">${ex('おかあさん', '媽媽')}${ex('おにいさん', '哥哥')}${ex('くうき', '空氣')}${ex('せんせい', '老師')}${ex('おとうさん', '爸爸')}${ex('コーヒー', '咖啡')}${ex('ケーキ', '蛋糕')}</div>
  </div></div></details>`;
}
const KANA_MODES = [['k2r', '看假名選拼音'], ['r2k', '看拼音選假名'], ['listen', '聽發音選假名']];
const KANA_RANGES = [['all', '全部'], ['清音', '清音'], ['濁音', '濁音'], ['拗音', '拗音'], ['wrong', '錯題'], ['review', '錯題複習'], ['due', '到期複習']];
function kanaPool(range) {
  const t = today();
  const base = KANA.filter(k => k.script === UI.script);
  if (range === 'wrong') return base.filter(k => wrongOf(k.id, 'kana') === 1);
  if (range === 'review') return base.filter(k => wrongOf(k.id, 'kana') === 2);
  if (range === 'due') return base.filter(k => { const r = getRec(k.id); return r.s === 'learned' && r.due && r.due <= t; });
  if (range === 'all') return base;
  return base.filter(k => k.cat === range);
}
function renderKanaQuiz() {
  const body = $('#kanaBody');
  const counts = Object.fromEntries(KANA_RANGES.map(([k]) => [k, kanaPool(k).length]));
  body.innerHTML = `
    <div class="ctl">${pillSelect('kMode', '題型', [['k2r', '假名→拼音'], ['r2k', '拼音→假名'], ['listen', '聽→假名']], UI.kanaMode)}${pillSelect('kRange', '範圍', KANA_RANGES.map(([k, l]) => [k, `${l} ${counts[k]}`]), UI.kanaRange)}</div>
    <div id="kq"></div>`;
  $('#kMode', body).onchange = e => { UI.kanaMode = e.target.value; saveUI(); renderKanaQuiz(); };
  $('#kRange', body).onchange = e => { UI.kanaRange = e.target.value; saveUI(); kanaRound = null; renderKanaQuiz(); };
  if (kanaRound && kanaRound.done) { kanaRound.idx++; kanaRound.done = false; }
  if (!kanaRound || kanaRound.idx >= kanaRound.queue.length) {
    if (kanaRound && kanaRound.idx >= kanaRound.queue.length && kanaRound.queue.length) return roundDone($('#kq'), kanaRound, () => { kanaRound = null; renderKanaQuiz(); });
    const pool = kanaPool(UI.kanaRange);
    if (!pool.length) {
      const msg = { wrong: '目前沒有錯題。', review: '目前沒有錯題複習。', due: '今天沒有到期的假名。' }[UI.kanaRange] || '這個範圍沒有題目。';
      $('#kq').innerHTML = `<div class="card empty"><p>${msg}</p><button class="btn" data-kr2="all">練習全部假名</button></div>`;
      $('[data-kr2]').onclick = () => { UI.kanaRange = 'all'; saveUI(); renderKanaQuiz(); };
      return;
    }
    const isRev = UI.kanaRange === 'review';
    kanaRound = { queue: pickRound(pool, getRec, 'kana', isRev ? REVIEW_ROUND : roundSize(), isRev), idx: 0, total: pool.length, range: UI.kanaRange, right: 0 };
  }
  nextKanaQ();
}
function nextKanaQ() {
  const R = kanaRound, host = $('#kq'); if (!R || !host) return;   // 自動跳下一題前範圍被換掉了（R 已清空）
  if (!host) return;
  if (R.idx >= R.queue.length) return roundDone(host, R, () => { kanaRound = null; renderKanaQuiz(); });
  const k = R.queue[R.idx];
  const mode = UI.kanaMode;
  const all = KANA.filter(x => x.script === UI.script);
  const opts = shuffle([k, ...pickKanaDistractors(k, all, 3, CMAP)]);
  const src = { wrong: 'wrong', review: 'review', due: 'due' }[R.range] || 'learn';
  const prompt = mode === 'k2r' ? `<div class="kana" lang="ja">${k.kana}</div>`
    : mode === 'r2k' ? `<div class="zh" style="font-size:34px">${esc(k.romaji)}</div>`
    : `<button class="btn solid" data-say="${esc(k.kana)}" style="min-width:160px">${ICON.play}播放發音</button><span class="meta">按下按鈕聽發音，再選出假名</span>`;
  renderChoice(host, {
    head: `<div class="qhead">${progressLine(R, R.total)}</div>`,
    promptHTML: prompt,
    options: opts.map(o => ({ html: mode === 'k2r' ? esc(o.romaji) : `<span lang="ja">${o.kana}</span>`, cls: mode === 'k2r' ? '' : 'kanab', correct: o.id === k.id })),
    onAnswer: ok => { if (ok) R.right++; R.done = true; record(k, 'kana', ok, src); },
    afterHTML: () => `<div class="example"><div class="row" style="gap:14px"><div class="sq small" lang="ja"><span>${k.kana}</span></div><div><div style="font-size:20px;font-weight:700">${esc(k.romaji)}</div>${k.ex ? `<span class="ja" style="font-size:18px">${esc(k.ex)}</span>　${esc(exMean(k.ex, k.exZh))}` : `<span class="meta">${esc(k.exZh)}</span>`}</div></div><div class="row">${playBtn(k.kana, '發音')}${k.ex ? playBtn(k.ex, '例字') : ''}</div></div>`
  }, () => { R.idx++; R.done = false; nextKanaQ(); });
}
function roundDone(host, R, again) {
  Quiz.active = null;
  Sfx.done();
  host.innerHTML = `<div class="card empty"><p style="color:var(--fg);font-size:18px;font-weight:700">這一輪完成了</p><p>答對 ${R.right} / ${R.queue.length} 題</p><button class="btn solid" id="again">再來一輪</button></div>`;
  $('#again', host).onclick = again;
}

// ================= 單選 =================
// @include shared/mc-tab.js（這一段由 build.js 從 n5src/shared/mc-tab.js 複製過來，要改請改那個檔再跑 build.js）
// @end shared/mc-tab.js


// ================= 漢字讀音、助詞填空 =================
const MC_MODE_OPTS = [['jp2zh', '日→中'], ['zh2jp', '中→日'], ['listen', '聽→中'], ['read', '漢字讀音'], ['part', '助詞填空'], ['conj', '詞性變化']];
const mcKind = m => m === 'part' ? 'part' : m === 'conj' ? 'conj' : m === 'read' ? 'read' : 'word';
function nextReadQ(R, w) {
  const host = $('#mcq');
  const src = { mcWrong: 'wrong', mcReview: 'review' }[R.src] || (R.src === 'learned' ? 'learned' : 'learn');
  const opts = shuffle([w.reading, ...pickReadingDistractors(w, WORDS)]);
  renderChoice(host, {
    head: `<div class="qhead">${progressLine(R, R.total)}</div>`,
    promptHTML: `<div class="big read-q" lang="ja">${esc(w.word)}</div><span class="meta">選出正確的讀音</span>`,
    options: opts.map(r => ({ html: `<span lang="ja">${esc(r)}</span>`, cls: 'ja', correct: r === w.reading })),
    onAnswer: ok => { if (ok) R.right++; R.done = true; record(w, 'mc', ok, src); },
    afterHTML: () => `<div class="example"><div class="row" style="gap:12px;align-items:center"><span class="ja" style="font-size:24px">${wordHTML(w)}</span><span>${meanW(w)}</span>${iconPlay(w.reading, '播放單字')}</div>${exampleBlock(w)}</div>`
  }, () => { R.idx++; R.done = false; nextMCQ(); });
}
const PART_GP = { 'は': 'wa', 'が': 'ga', 'を': 'o', 'に': 'ni', 'で': 'de', 'へ': 'e', 'と': 'to', 'も': 'mo', 'の': 'no', 'や': 'ya', 'から': 'kara', 'まで': 'made' };
let PITEMS = null;
// 從全部例句找出可以挖空的助詞（招呼語和文法條目本身的例句不出）
function particleItems() {
  if (PITEMS) return PITEMS;
  PITEMS = [];
  for (const w of WORDS) {
    if (w.kind !== 'w' || w.custom || w.pg === '招呼語與常用句') continue;
    for (const t of toksOf(w)) {
      const p = t.e && t.e.startsWith('f:') ? t.e.slice(2) : '';
      if (!PARTICLES.includes(p) || t.s1 - t.s0 !== [...p].length) continue;
      if (w.pg === '文法' && w.word === p) continue;
      PITEMS.push({ w, t, p });
    }
  }
  return PITEMS;
}
function nextPartQ() {
  const R = mcRound, host = $('#mcq'); if (!R || !host) return;   // 自動跳下一題前範圍被換掉了（R 已清空）
  if (!host) return;
  if (R.idx >= R.queue.length) return roundDone(host, R, () => { mcRound = null; renderMC(); });
  const { w, t, p } = R.queue[R.idx];
  const opts = shuffle([p, ...pickParticleDistractors(p)]);
  const blank = { a0: t.s0, a1: t.s1, html: '<span class="pblank">（　）</span>' };
  const gp = GP[PART_GP[p]];
  renderChoice(host, {
    head: `<div class="qhead">${progressLine(R, R.total)}</div>`,
    promptHTML: `<div class="sent psent" lang="ja">${rubyHTML(w.segs, { toks: toksOf(w), blank })}</div><div class="zhline">${esc(w.sentZh)}</div>`,
    options: opts.map(x => ({ html: `<span lang="ja">${esc(x)}</span>`, cls: 'ja kanab', correct: x === p })),
    onAnswer: ok => { if (ok) R.right++; R.done = true; bumpDay(); },
    afterHTML: () => `<div class="example"><div class="ex-row"><div class="sent" lang="ja">${rubyHTML(w.segs, { toks: toksOf(w), hl: [t.s0, t.s1] })}</div>${iconPlay(w.sent, '播放例句')}</div><div class="zhline">${esc(w.sentZh)}</div>
      ${gp ? `<div class="gp-item" style="margin-top:10px"><div class="gp-h"><b>${esc(gp.t)}</b></div><div>${esc(gp.d)}</div><button class="gp-more" data-gram="${gp.id}">看更多例句 ›</button></div>` : ''}</div>`
  }, () => { R.idx++; R.done = false; nextPartQ(); });
}

// ================= 詞性變化 =================
// 看原形和要變的形，選出正確的變化。錯誤選項照常見的錯法做：分錯動詞類別、て形音便用錯、い／な形容詞弄混
const CONJ_SETS = [['all', '動詞＋形容詞'], ['verb', '動詞'], ['v1', '一類動詞'], ['v2', '二類動詞'], ['v3', '三類動詞'], ['tricky', '長得像二類的一類'], ['adj', '形容詞']];
const CONJ_ASK = {
  動詞: ['ます形', '否定', '過去', '過去否定', 'て形', 'ない形', 'た形', '〜たい'],
  い形容詞: ['過去', '否定', '過去否定', 'て形', '副詞'],
  な形容詞: ['過去', '否定', '過去否定']
};
const CONJ_Q = {
  'ます形': 'ます形（禮貌）', '否定': '否定（ません／禮貌）', '過去': '過去（禮貌）', '過去否定': '過去否定（禮貌）',
  'て形': 'て形', 'ない形': 'ない形（普通體否定）', 'た形': 'た形（普通體過去）', '〜たい': '〜たい（想要）', '副詞': '副詞（…地）'
};
const CONJ_CACHE = {};
function conjWords(set) {
  if (CONJ_CACHE[set]) return CONJ_CACHE[set];
  const ok = w => {
    if (w.kind !== 'w' || !CONJ_ASK[w.pg]) return false;
    if (set === 'verb') return w.pg === '動詞';
    if (set === 'v1') return w.pos === '動詞(一類)';
    if (set === 'v2') return w.pos === '動詞(二類)';
    if (set === 'v3') return w.pos === '動詞(三類)';
    if (set === 'tricky') return w.pos === '動詞(一類)' && LOOKS_ICHIDAN(w);
    if (set === 'adj') return w.pg !== '動詞';
    return true;
  };
  // 同一個字寫法只出一次
  const seen = new Set();
  return CONJ_CACHE[set] = WORDS.filter(w => ok(w) && !seen.has(w.word) && seen.add(w.word) && conjRows(w).length);
}
const conjRows = w => conjugate(w).filter(r => (CONJ_ASK[w.pg] || []).includes(r.label));
const isKuru = w => w.word === '来る' || w.reading === 'くる' && w.pos === '動詞(三類)';
function conjItem(w) {
  const rows = conjRows(w);
  if (!rows.length) return null;
  // 動詞多出て形、ない形（最容易錯）
  const weighted = rows.flatMap(r => /^(て形|ない形|た形)$/.test(r.label) ? [r, r] : [r]);
  return { w, row: weighted[Math.floor(Math.random() * weighted.length)] };
}
// 常見的錯誤寫法：回傳 [表層, 讀音]
function conjWrong(w, label) {
  const out = [];
  const add = (s, r) => { if (s && r) out.push([s, r]); };
  const from = alt => { const x = conjugate(alt).find(r => r.label === label); if (x) add(x.s, x.r); };
  const sb = w.word.slice(0, -1), rb = w.reading.slice(0, -1);
  if (w.pg === '動詞') {
    if (isKuru(w)) {
      const K = { 'ます形': ['こます', 'くります'], '否定': ['こません', 'くりません'], '過去': ['こました', 'くりました'], '過去否定': ['こませんでした', 'くりませんでした'],
        'て形': ['こて', 'くって'], 'ない形': ['きない', 'くらない'], 'た形': ['こた', 'くった'], '〜たい': ['こたい', 'くりたい'] };
      (K[label] || []).forEach(k => add(k, k));
    } else if (w.pos === '動詞(三類)') {
      const sb2 = w.word.slice(0, -2), rb2 = w.reading.slice(0, -2);
      const S = { 'ます形': ['すます', 'さます'], '否定': ['すません', 'さません'], '過去': ['すました'], '過去否定': ['すませんでした'],
        'て形': ['すって', 'せて'], 'ない形': ['さない', 'すない'], 'た形': ['すった', 'せた'], '〜たい': ['すたい', 'さたい'] };
      (S[label] || []).forEach(k => add(sb2 + k, rb2 + k));
    } else {
      // 分錯類別：一類當成二類、二類當成一類
      from(Object.assign({}, w, { pos: w.pos === '動詞(一類)' ? '動詞(二類)' : '動詞(一類)' }));
      if (w.pos === '動詞(一類)' && /^(て形|た形)$/.test(label)) {
        // て形音便用錯
        const ta = label === 'た形';
        for (const e of ['って', 'んで', 'いて', 'いで', 'して']) { const x = ta ? e.replace(/て$/, 'た').replace(/で$/, 'だ') : e; add(sb + x, rb + x); }
        if (w.word === '行く' || w.reading === 'いく') add(sb + (ta ? 'いた' : 'いて'), rb + (ta ? 'いた' : 'いて'));
      }
      if (w.pos === '動詞(一類)' && label === 'ない形') {
        if (/う$/.test(w.reading)) add(sb + 'あない', rb + 'あない');
        if (w.word === 'ある') add('あらない', 'あらない');
        add(sb + 'ない', rb + 'ない');
      }
      if (w.pos === '動詞(一類)' && /^(ます形|否定|過去|過去否定|〜たい)$/.test(label)) {
        // 字尾換錯段（換成あ段或え段）
        const A = { う: 'わ', く: 'か', ぐ: 'が', す: 'さ', つ: 'た', ぬ: 'な', ぶ: 'ば', む: 'ま', る: 'ら' }[w.reading.slice(-1)];
        const tail = { 'ます形': 'ます', '否定': 'ません', '過去': 'ました', '過去否定': 'ませんでした', '〜たい': 'たい' }[label];
        if (A) add(sb + A + tail, rb + A + tail);
      }
    }
  } else if (w.pg === 'い形容詞') {
    if (w.word === 'いい') {
      const I = { '過去': ['いかったです', 'いいでした'], '否定': ['いくないです', 'いいじゃありません'], '過去否定': ['いくなかったです', 'よくないでした'], 'て形': ['いくて', 'いいで'], '副詞': ['いく', 'いいに'] };
      (I[label] || []).forEach(k => add(k, k));
    } else {
      // 當成な形容詞，或是過去否定接錯
      const N = { '過去': ['でした'], '否定': ['じゃありません'], '過去否定': ['じゃありませんでした'], 'て形': ['で'], '副詞': ['に'] };
      (N[label] || []).forEach(k => add(w.word + k, w.reading + k));
      if (label === '過去否定') add(sb + 'くないでした', rb + 'くないでした');
      if (label === '否定') add(w.word + 'くないです', w.reading + 'くないです');
      if (label === '過去') add(sb + 'くかったです', rb + 'くかったです');
    }
  } else if (w.pg === 'な形容詞') {
    // 當成い形容詞（きれい → きれくない），或多加「な」
    if (/い$/.test(w.word)) from(Object.assign({}, w, { pg: 'い形容詞' }));
    else { const I = { '過去': 'かったです', '否定': 'くないです', '過去否定': 'くなかったです' }[label]; if (I) add(w.word + I, w.reading + I); }
    const X = { '過去': ['なでした', 'だでした'], '否定': ['なじゃありません', 'じゃないでした'], '過去否定': ['じゃないでした', 'なじゃありませんでした'] };
    (X[label] || []).forEach(k => add(w.word + k, w.reading + k));
  }
  return out;
}
function conjOptions(w, row) {
  const used = new Set([normKana(row.r)]);
  const pick = list => shuffle(list).filter(([s, r]) => { const k = normKana(r); if (used.has(k) || s === row.s) return false; used.add(k); return true; });
  let wrong = pick(conjWrong(w, row.label)).slice(0, 3);
  // 不夠三個：用同一個字的其他變化形補
  if (wrong.length < 3) wrong = wrong.concat(pick(conjugate(w).filter(r => r.label !== row.label && r.label !== '原形').map(r => [r.s, r.r])).slice(0, 3 - wrong.length));
  return shuffle([[row.s, row.r, true], ...wrong]);
}
function conjFormHTML(w, s, r) {
  if (isKuru(w)) return esc(r);
  const segs = align(s, r);
  return segs ? rubyHTML(segs) : esc(s);
}
function nextConjQ() {
  const R = mcRound, host = $('#mcq'); if (!R || !host) return;   // 自動跳下一題前範圍被換掉了（R 已清空）
  if (!host) return;
  if (R.idx >= R.queue.length) return roundDone(host, R, () => { mcRound = null; renderMC(); });
  const it = R.queue[R.idx], { w, row } = it;
  const opts = conjOptions(w, row);
  const ti = typeInfo(w);
  const rule = (typeof RULES !== 'undefined' ? RULES : []).find(x => x.pos === w.pos);
  const hint = rule && rule.r[row.label];
  renderChoice(host, {
    head: `<div class="qhead">${progressLine(R, R.total)}</div>`,
    promptHTML: `<div class="big" lang="ja">${wordHTML(w)}</div>${romajiLine(w.romaji)}<span class="pos">${esc(w.pos)}</span><div class="zh">${meanW(w)}</div>
      <div class="conj-ask"><span class="conj-arrow" aria-hidden="true">→</span><b>${esc(CONJ_Q[row.label] || row.label)}</b></div>`,
    options: opts.map(([s, r, ok]) => ({ html: `<span lang="ja">${conjFormHTML(w, s, r)}</span>`, cls: 'ja', correct: !!ok })),
    onAnswer: ok => {
      if (ok) R.right++; R.done = true; bumpDay();
      // 答錯的同一題，這一輪最後再出一次
      if (!ok && !it.again) R.queue.push(Object.assign({}, it, { again: true }));
    },
    afterHTML: () => `<div class="example">
      <div class="row" style="gap:12px;align-items:center"><span class="ja" style="font-size:24px">${conjFormHTML(w, row.s, row.r)}</span><span class="meta">${esc(row.label)}</span>${iconPlay(row.r, '播放發音')}</div>
      <div class="conj-why"><span class="pos">${esc(w.pos)}</span>${hint ? `<span>${esc(hint)}</span>` : ''}</div>
      ${ti.extra ? `<p class="fm-note">${esc(ti.extra)}</p>` : ''}
      <button class="btn" data-forms="${esc(w.id)}" style="margin-top:10px">看「${esc(w.word)}」的完整變化表</button></div>`
  }, () => { R.idx++; R.done = false; nextConjQ(); });
}

// ================= 字卡 =================
// @include shared/card-tab.js（這一段由 build.js 從 n5src/shared/card-tab.js 複製過來，要改請改那個檔再跑 build.js）
// @end shared/card-tab.js

// ================= 填空 =================
const fillModeSeg = () => `<div class="seg" role="group" aria-label="填空模式">
      <button data-fmode="fill" aria-pressed="${UI.fillMode !== 'dict'}">句子填空</button>
      <button data-fmode="dict" aria-pressed="${UI.fillMode === 'dict'}">聽寫</button>
    </div>`;
function bindFillMode(host) {
  $$('[data-fmode]', host).forEach(b => b.onclick = () => { if (UI.fillMode === b.dataset.fmode) return; UI.fillMode = b.dataset.fmode; saveUI(); document.body.classList.remove('typing'); renderFill(); });
}
// @include shared/fill-tab.js（這一段由 build.js 從 n5src/shared/fill-tab.js 複製過來，要改請改那個檔再跑 build.js）
// @end shared/fill-tab.js

// ================= 聽寫 =================
// 聽單字的發音，打出假名（或拼音、漢字）。不影響「已學會」，答錯的字會進「聽寫錯題」。
let dictRound = null;
const DICT_SRCS = [['learn', '待考'], ['recent', '最近學過'], ['dictWrong', '聽寫錯題'], ['learned', '複習已學會']];
const dictPool = src => srcPool(src).filter(w => w.pg !== '文法' && !w.noR);   // 自己新增、例句沒寫讀法的字不出聽寫
function renderDict() {
  const host = $('#tab-fill');
  const counts = Object.fromEntries(DICT_SRCS.map(([k]) => [k, dictPool(k).length]));
  host.innerHTML = `${fillModeSeg()}
    <div class="ctl">${pillSelect('dictSrc', '題目來源', DICT_SRCS.map(([k, l]) => [k, `${l} ${counts[k]}`]), UI.dictSrc)}${UI.dictSrc === 'recent' ? recentCtl().html : posChips()}</div>
    <div id="fq"></div>`;
  bindFillMode(host);
  $('#dictSrc', host).onchange = e => { UI.dictSrc = e.target.value; saveUI(); dictRound = null; renderFill(); };
  recentCtl(() => { dictRound = null; renderFill(); }).bind(host);
  bindPos(host, () => { dictRound = null; renderFill(); });
  if (dictRound && dictRound.done) { dictRound.idx++; dictRound.done = false; }
  const valid = dictRound && dictRound.src === UI.dictSrc && (UI.dictSrc === 'recent' || dictRound.pos === UI.pos);
  if (!valid || dictRound.idx >= dictRound.queue.length) {
    if (valid && dictRound.queue.length && dictRound.idx >= dictRound.queue.length) return roundDone($('#fq'), dictRound, () => { dictRound = null; renderFill(); });
    const pool = dictPool(UI.dictSrc);
    if (!pool.length) return emptyWords($('#fq'), UI.dictSrc);
    dictRound = { queue: UI.dictSrc === 'recent' ? recentQueue(pool) : pickRound(pool, getRec, 'dict', roundSize(), UI.dictSrc === 'dictWrong'), idx: 0, total: pool.length, src: UI.dictSrc, pos: UI.pos, right: 0 };
  }
  nextDictQ();
}
function nextDictQ(keepFocus) {
  const R = dictRound, host = $('#fq'); if (!R || !host) return;   // 自動跳下一題前範圍被換掉了（R 已清空）
  if (!host) return;
  if (R.idx >= R.queue.length) { document.body.classList.remove('typing'); return roundDone(host, R, () => { dictRound = null; renderFill(); }); }
  const w = R.queue[R.idx];
  const src = R.src === 'dictWrong' ? 'wrong' : 'learn';
  const len = kanaLen(w.reading);
  host.innerHTML = `<div class="card" id="fillCard">
    <div class="qhead">${progressLine(R, R.total)}</div>
    <div class="dict-play">
      <button class="dict-big" id="dictPlay" aria-label="再聽一次">${ICON.play}</button>
      <button class="btn quiet" id="dictSlow" style="min-height:40px">慢速</button>
    </div>
    <div class="hint dict-hint">
      <span class="pos">${esc(w.pos)}</span><span class="meta">共 ${len} 個假名</span>
      <button class="linkbtn" id="dictHint">看意思</button>
    </div>
    <div class="dict-mean" id="dictMean" hidden>${meanW(w)}</div>
    <form class="answerrow" id="fillForm" style="margin-top:12px" autocomplete="off">
      <input id="fillIn" type="text" inputmode="text" autocapitalize="off" autocorrect="off" spellcheck="false" enterkeyhint="go" placeholder="平假名、拼音或漢字" aria-label="寫下聽到的字">
      <button class="btn solid" type="submit" id="fillGo">送出</button>
    </form>
    <div class="preview" id="fillPrev"></div>
    <button class="btn quiet block" id="fillShow" style="margin-top:4px">看答案</button>
    <div id="fillAfter"></div>
  </div>`;
  const inp = $('#fillIn'), prev = $('#fillPrev');
  const say = slow => Voice.speak(w.reading, null, slow ? 0.6 : 0);
  $('#dictPlay').onclick = () => say(false);
  $('#dictSlow').onclick = () => say(true);
  $('#dictHint').onclick = e => { e.currentTarget.hidden = true; $('#dictMean').hidden = false; };
  let answered = false;
  inp.addEventListener('input', () => { const v = inp.value, conv = /[a-z]/i.test(v) ? romaToKana(v, false) : v; prev.textContent = v && conv !== v ? `→ ${conv}` : ''; });
  const target = { ans: w.word, ansR: w.reading, word: w.word, reading: w.reading, romaji: w.romaji };
  const finish = (ok, shown) => {
    answered = true; R.done = true;
    if (ok) R.right++;
    record(w, 'dict', ok, src);
    ok ? Sfx.ok() : Sfx.ng(); buzz(ok);
    inp.readOnly = true;
    $('#fillGo').textContent = '下一題';
    $('#fillShow').hidden = true;
    $('#dictHint').hidden = true; $('#dictMean').hidden = true;
    $('#fillAfter').innerHTML = `<div class="afterbox">
      ${verdict(ok, shown ? '（看了答案）' : '')}
      ${!ok && inp.value && !shown ? `<div class="meta">你的答案：${esc(inp.value)}</div>` : ''}
      <div class="row" style="gap:12px;align-items:center"><span class="ja" style="font-size:26px">${wordHTML(w)}</span><span>${meanW(w)}</span>${iconPlay(w.reading, '播放單字')}</div>
      ${romajiLine(w.romaji)}
      ${exampleBlock(w)}
    </div>`;
  };
  const next = () => { R.idx++; R.done = false; nextDictQ(true); };
  $('#fillForm').addEventListener('submit', e => {
    e.preventDefault();
    if (answered) return next();
    if (!inp.value.trim()) { inp.focus(); return; }
    finish(checkFill(target, inp.value), false);
  });
  $('#fillGo').addEventListener('mousedown', e => e.preventDefault());
  $('#fillShow').onclick = () => { if (!answered) finish(false, true); };
  inp.addEventListener('focus', () => { document.body.classList.add('typing'); setTimeout(scrollFillTop, 280); });
  inp.addEventListener('blur', () => setTimeout(() => { const a = document.activeElement; if (!a || a.id !== 'fillIn') document.body.classList.remove('typing'); }, 250));
  if (keepFocus && window.matchMedia('(pointer:fine)').matches) inp.focus({ preventScroll: true });
  else if (keepFocus && document.body.classList.contains('typing')) { inp.focus({ preventScroll: true }); scrollFillTop(); }
  say(false);
}

// ================= 單字庫 =================
// 這一頁和語言頁不一樣的地方（共用的分頁程式用 PAGE.…）
// @include shared/sheet.js（這一段由 build.js 從 n5src/shared/sheet.js 複製過來，要改請改那個檔再跑 build.js）
// @end shared/sheet.js
const PAGE = {
  mine: {
    prefix: MY, lang: 'ja', name: '日文', dict: 'ja', readings: true, meanEn: LANG === 'en',
    builtin: word => WORDS.find(w => !w.custom && w.kind === 'w' && w.word === word),
    check: c => myWord('', c).err || '',
    needReading: word => !KANA_ONLY.test(word || 'あ'),
    // 從 Wiktionary 找讀音，只收和單字對得上的
    autoReading: async word => { const rs = await dictReading(word); return (rs || []).find(r => align(word, r)) || ''; },
    guessForm: (sent, word) => guessJaForm(sent, word),
    changed: () => { syncMine(); deck = null; refreshPassive(); if (UI.tab === 'lib') renderLib(); if (UI.tab === 'card') renderCard(); }
  },
  voice: {
    GOOD: /natural|neural|premium|enhanced|online|google|siri|高品質|拡張|強化/i,
    BAD: /desktop|ichiro|ayumi|haruka|sayaka|espeak|compact/i,   // 很機械的舊日文語音
    match: v => /^ja([-_]|$)/i.test(v.lang),
    score(v) { const P = PAGE.voice; let s = 0; if (P.GOOD.test(v.name)) s += 10; if (P.BAD.test(v.name) && !P.GOOD.test(v.name)) s -= 5; if (v.localService === false) s += 1; if (/ja[-_]JP/i.test(v.lang)) s += 1; return s; },
    robotic: v => PAGE.voice.BAD.test(v.name) && !PAGE.voice.GOOD.test(v.name),
    saved: () => SET.voice,
    save(uri) { SET.voice = uri; saveSet(); },
    uLang: () => 'ja-JP',
    label: '日文語音（這台裝置）',
    none: '還沒有讀到日文語音，系統會用預設聲音。',
    help: opts => (!opts.length || Voice.allRobotic()) ? `<div class="warn">這台裝置的日文語音聽起來比較機械。<br>iPhone／Mac：到「設定 → 輔助使用 → 朗讀內容 → 聲音 → 日文」下載「增強」或「高品質」的語音。<br>Windows：建議改用 Edge 瀏覽器，會有較自然的線上語音。</div>` : '',
    note: '設定只存在這台裝置。',
    sample: 'こんにちは。わたしはがくせいです。'
  },
  gram: {
    prefix: 'ja:gx:',
    get path() { return JA_GX_PATH; },
    gx: id => JA_GX[id],
    title: id => GP[id] ? GP[id].t : '',
    // 題目和讀音裡的 ___ 是空格，用 |___| 分段才對得起來
    quizQ([pr, prR, ans, wr, zh, why]) {
      const ps = gxSegs(pr.replace('___', '|___|'), prR.replace('___', '|___|'));
      const bi = ps.findIndex(x => x.t === '___');
      const full = pr.replace('___', ans);
      return {
        ans,
        prompt: `<div class="sent" lang="ja">${rubyHTML(ps, bi >= 0 ? { blank: { a0: bi, a1: bi + 1, html: '<span class="blank" id="blank">？</span>' } } : {})}</div><div class="zhline">${esc(zh)}</div>`,
        options: shuffle([ans].concat(wr)).map(o => ({ html: `<span lang="ja">${esc(o)}</span>`, correct: o === ans })),
        explain: `<div class="gx-why"><div class="ex-row"><div class="sent" lang="ja">${rubyHTML(ps.map(x => x.t === '___' ? { t: ans, r: null } : x))}</div>${iconPlay(full, '播放整句')}</div><p><b>為什麼：</b>${esc(why)}</p></div>`
      };
    },
    head: p => [p.t, p.lv],
    body: p => `<p class="gr-desc">${esc(p.d)}</p>`,
    exCard: (p, exs) => `<div class="card">
      <div class="gp-title" style="margin-bottom:8px">例句（${exs.length}）</div>
      ${exs.length ? `<div class="gr-exs">${exs.slice(0, gramShow).map(({ w, s }) => {
        const r = segRange(w.segs, w.sent.indexOf(s), s.length);
        return `<div class="gr-ex"><div class="ex-row"><div class="sent" lang="ja">${rubyHTML(w.segs, { toks: toksOf(w), hl: r })}</div>${iconPlay(w.sent, '播放例句')}</div>
          ${romajiLine(segsRomaji(w.segs))}<div class="zhline">${esc(w.sentZh)}</div><div class="from">出自單字：<span lang="ja">${esc(w.word)}</span>（${esc(meanPlain(w))}）</div></div>`;
      }).join('')}</div>${exs.length > gramShow ? `<button class="btn quiet gr-more" id="grMore">再顯示 ${Math.min(8, exs.length - gramShow)} 句（共 ${exs.length} 句）</button>` : ''}`
      : '<p class="meta">目前的單字例句裡還沒有用到這個文法。</p>'}
    </div>`
  },
  mc: {
    get modes() { return MC_MODE_OPTS; },
    // 詞性變化：題型後面是「範圍」；助詞填空：沒有選單
    ctl: srcCtl => UI.mcMode === 'conj' ? pillSelect('conjSet', '範圍', CONJ_SETS.map(([k, l]) => [k, `${l} ${conjWords(k).length}`]), UI.conjSet) : UI.mcMode === 'part' ? '' : srcCtl(),
    bind: host => { const csEl = $('#conjSet', host); if (csEl) csEl.onchange = e => { UI.conjSet = e.target.value; saveUI(); mcRound = null; renderMC(); }; },
    resetOnMode: false,   // 日→中、中→日、聽→中 是同一輪，換題型接著出
    roundKey: () => { const k = mcKind(UI.mcMode); return k === 'part' ? 'part' : k === 'conj' ? 'conj:' + UI.conjSet : k + ':' + UI.mcSrc + ':' + (UI.mcSrc === 'recent' ? '' : UI.pos); },
    special(key) {
      const kind = mcKind(UI.mcMode);
      if (kind === 'part') {
        const items = particleItems();
        mcRound = { key, kind, queue: shuffle(items).slice(0, roundSize()), idx: 0, total: items.length, right: 0 };
        nextPartQ(); return true;
      }
      if (kind === 'conj') {
        const ws = conjWords(UI.conjSet);
        mcRound = { key, kind, set: UI.conjSet, queue: shuffle(ws).slice(0, roundSize()).map(conjItem).filter(Boolean), idx: 0, total: ws.length, right: 0 };
        nextConjQ(); return true;
      }
      return false;
    },
    pool: src => { const pool = srcPool(src); return mcKind(UI.mcMode) === 'read' ? pool.filter(w => hasKanji(w.word)) : pool; },
    emptyPool() {
      if (mcKind(UI.mcMode) !== 'read') return false;
      $('#mcq').innerHTML = '<div class="card empty"><p>這個來源裡沒有漢字詞。可以換一個題目來源，或先到字卡把有漢字的字列入考題。</p></div>';
      return true;
    },
    recentQueue: pool => recentQueue(pool),
    start: () => mcRound.kind === 'part' ? nextPartQ() : mcRound.kind === 'conj' ? nextConjQ() : nextMCQ(),
    question(R, item) { if (UI.mcMode !== 'read') return false; nextReadQ(R, item); return true; },
    word: {
      distractors: (w, mode) => pickWordDistractors(w, WORDS, mode),
      prompt: (w, mode) => mode === 'jp2zh' ? `<div class="big" lang="ja">${wordHTML(w)}</div>${romajiLine(w.romaji)}<span class="pos">${esc(w.pos)}</span>`
        : mode === 'zh2jp' ? `<div class="zh">${meanW(w)}</div><span class="pos">${esc(w.pos)}</span>`
        : `<button class="btn solid" data-say="${esc(w.reading)}" style="min-width:160px">${ICON.play}播放發音</button><span class="meta">按下按鈕聽發音，再選出意思</span>`,
      option: (o, mode) => mode === 'zh2jp' ? { html: `<span lang="ja">${wordHTML(o)}</span>${romajiLine(o.romaji)}`, cls: 'ja' } : { html: meanW(o) },
      after: w => `<div class="example"><div class="row" style="gap:12px;align-items:center"><span class="ja" style="font-size:24px">${wordHTML(w)}</span><span>${meanW(w)}</span>${iconPlay(w.reading, '播放單字')}</div>${romajiLine(w.romaji)}</div>${exampleBlock(w)}`
    }
  },
  fill: {
    top: () => fillModeSeg(),
    bindTop: host => bindFillMode(host),
    alt: () => { if (UI.fillMode !== 'dict') return false; renderDict(); return true; },
    recentQueue: pool => recentQueue(pool),
    make(w, R) {
      const len = kanaLen(w.ansR);
      const blankEmpty = '＿'.repeat(Math.max(2, Math.min(len, 8)));
      const preRom = segsRomaji(w.segs, 0, w.a0), postRom = segsRomaji(w.segs, w.a1);
      return {
        blankEmpty,
        html: `<div class="qhead">${progressLine(R, R.total)}</div>
    <div class="sent" lang="ja" id="fillSent" style="margin-top:8px">${rubyHTML(w.segs, { toks: toksOf(w), blank: { a0: w.a0, a1: w.a1, html: `<span class="blank" id="blank">${blankEmpty}</span>` } })}</div>
    ${romajiLine((preRom + ' ____ ' + postRom).trim())}
    <div class="hint" style="margin-top:8px">
      <span>${esc(w.sentZh)}</span>
      ${len > 1 ? `<span class="meta" id="fillHint"${SET.fillHint === 'show' ? '' : ' hidden'}>提示：第一個假名是 <b style="color:var(--fg)">${esc(w.ansR[0])}</b>，共 ${len} 個假名</span>` : ''}
    </div>
    <form class="answerrow" id="fillForm" style="margin-top:12px" autocomplete="off">
      <input id="fillIn" type="text" inputmode="text" autocapitalize="off" autocorrect="off" spellcheck="false" enterkeyhint="go" placeholder="漢字、平假名或拼音" aria-label="填入答案">
      <button class="btn solid" type="submit" id="fillGo">送出</button>
    </form>
    <div class="preview" id="fillPrev"></div>
    <div${len > 1 ? ' class="btnrow"' : ''} style="margin-top:4px">${len > 1 ? `<button class="btn quiet" id="fillHintBtn" aria-pressed="${SET.fillHint === 'show'}">${SET.fillHint === 'show' ? '收起提示' : '提示'}</button>` : ''}<button class="btn quiet${len > 1 ? '' : ' block'}" id="fillShow">看答案</button></div>
    <div id="fillAfter"></div>`,
        // 打拼音時即時換成假名，空格裡和下面都看得到
        live(inp, blank) {
          const v = inp.value;
          const conv = /[a-z]/i.test(v) ? romaToKana(v, false) : v;
          blank.textContent = v ? conv : blankEmpty;
          $('#fillPrev').textContent = v && conv !== v ? `→ ${conv}` : '';
        },
        check: v => checkFill(w, v) ? 'ok' : 'wrong',
        reveal: blank => { blank.innerHTML = rubyHTML(w.segs.slice(w.a0, w.a1)); },
        hideButtons: () => { $('#fillShow').parentNode.hidden = true; },
        verdict: (res, shown) => verdict(res !== 'wrong', shown ? '（看了答案）' : ''),
        correct: (v, shown) => `<div>正確答案：<span class="ja" style="font-size:22px;font-weight:700">${esc(w.ans)}</span>（${esc(w.ansR)}）${v && !shown ? `<br><span class="meta">你的答案：${esc(v)}</span>` : ''}</div>`,
        wordRow: () => `<div class="row" style="gap:12px;align-items:center"><span class="ja" style="font-size:22px">${wordHTML(w)}</span><span>${meanW(w)}</span>${iconPlay(w.reading, '播放單字')}</div>`
      };
    }
  },
  card: {
    pos: w => `<button class="posbtn" data-forms="${esc(w.id)}" aria-label="看「${esc(w.word)}」的詞性和變化形">${esc(w.pos)}<span aria-hidden="true">›</span></button>`,
    headRight: w => grammarButton(w),
    afterHead: w => grammarPanel(w),
    word: w => `<div class="word-row"><div class="word" lang="ja">${wordHTML(w)}</div>${iconPlay(w.reading, '播放單字')}</div>
    <div class="sub">${romajiLine(w.romaji)}</div>`,
    afterMean: () => '',
    bind: host => bindGrammar(host)
  },
  lib: {
    searchPh: '搜尋：日文、假名、拼音或中文',
    voiceTitle: '發音',
    hintUnit: '假名',
    roundTabs: '五十音、單選、字卡和填空',
    mallet: '五十音',
    meanNote: '例句翻譯跟著介面語言。',
    langHTML: () => `<section><h4>介面語言 Language</h4>
          <label class="label" for="langSel">介面語言</label>
          <select id="langSel" data-noi18n><option value="zh"${LANG === 'zh' ? ' selected' : ''}>中文（繁體）</option><option value="en"${LANG === 'en' ? ' selected' : ''}>English</option></select>
          <div class="meta">切換後會重新載入。日文內容不變；選 English 時，單字意思和例句翻譯也會換成英文。</div>
          <button class="btn quiet" id="tourBtn" style="min-height:40px;margin-top:6px">重看使用導覽</button>
        </section>`,
    extraHTML: () => `<section><h4>文法補充</h4>
          <label class="label" for="knownLv">已經會的文法等級（不再顯示）</label>
          <select id="knownLv"><option value="">全部顯示</option>${GLOSS_LEVELS.slice().reverse().map(l => `<option value="${l}"${SET.knownLv === l ? ' selected' : ''}>${l === 'N5' ? 'N5' : 'N5～' + l} 已經會了</option>`).join('')}</select>
          <div class="meta">選了之後，字卡「文法」裡那些等級的文法就不再顯示。</div>
        </section>`,
    syncNote: '',
    expNote: n => `共 ${n} 字。換裝置時貼到「匯入進度」。`,
    impNote: '逐題取較新的紀錄，不會整份覆蓋。',
    impKeep: id => WMAP[id] || KMAP[id] || id.startsWith('ja:gx:'),
    impToast: n => `已匯入 ${n} 筆紀錄`,
    wordCell: w => `<span class="w" lang="ja">${wordHTML(w)}</span>`,
    resetRounds: () => { kanaRound = null; },
    bind() {
      $('#langSel').onchange = e => setLang(e.target.value);
      $('#tourBtn').onclick = () => Tour.start(0);
      $('#knownLv').onchange = e => { SET.knownLv = e.target.value; saveSet(); toast(SET.knownLv ? `已隱藏 ${SET.knownLv} 以下的文法` : '文法全部顯示'); };
    }
  }
};
// @include shared/lib-tab.js（這一段由 build.js 從 n5src/shared/lib-tab.js 複製過來，要改請改那個檔再跑 build.js）
// @end shared/lib-tab.js
// @include shared/dict.js（線上查字典）
// @end shared/dict.js
// @include shared/mine.js（我的單字的表單）
// @end shared/mine.js
// 切換語言選單裡的進度條（lang.js）
if (window.AppLangs && AppLangs.stats) AppLangs.stats(() => { const c = libCounts(); return { l: c.learned, t: Math.max(1, c.total - c.excluded) }; });
const STATUS_TXT = { new: '未學', queued: '待考', learned: '已學會', excluded: '已排除' };
function doSearch(qs) {
  const box = $('#results');
  const q = qs.trim().toLowerCase();
  if (!q) { box.innerHTML = ''; return; }
  const kq = normKana(romaToKana(q, true));
  const rq = q.replace(/[\s']/g, '');
  const hits = WORDS.filter(w => w.word.includes(qs.trim()) || normKana(w.reading).includes(normKana(qs.trim())) || (kq && normKana(w.reading).includes(kq)) || w.romaji.replace(/[\s']/g, '').includes(rq) || w.zh.includes(qs.trim()) || (q.length > 1 && /^[a-z ]+$/.test(q) && new RegExp('\\b' + q).test(w.en.toLowerCase()))).slice(0, 30);
  if (!hits.length) { box.innerHTML = `<div class="meta">找不到符合的字。</div><button class="btn quiet" data-addmine="${esc(qs.trim())}" style="align-self:flex-start">查字典並把「${esc(qs.trim())}」加到我的單字</button>`; return; }
  box.innerHTML = hits.map(w => {
    const r = getRec(w.id);
    const canQ = r.s === 'new' || r.s === 'excluded';
    return `<div class="res">
      <div class="hd"><span class="w" lang="ja">${wordHTML(w)}</span><span>${meanW(w)}</span><button class="posbtn" data-forms="${esc(w.id)}">${esc(w.pos)}<span aria-hidden="true">›</span></button></div>
      ${romajiLine(w.romaji)}
      <div class="row"><span class="st ${r.s}">${STATUS_TXT[r.s] || '未學'}</span><span class="meta">作答 ${r.n || 0} 次</span></div>
      <div class="sent" lang="ja">${sentHTML(w)}</div>
      <div class="meta" style="color:var(--fg)">${esc(w.sentZh)}</div>
      <div class="row">${playBtn(w.reading, '單字')}${playBtn(w.sent, '例句')}${canQ ? `<button class="btn" data-q="${esc(w.id)}" style="min-height:44px">列入考題</button>` : ''}</div>
    </div>`;
  }).join('');
  $$('[data-q]', box).forEach(b => b.onclick = () => { touch(b.dataset.q, { s: 'queued' }); toast('已列入考題'); doSearch($('#q').value); });
}

// ================= 帳號同步（claude.ai）=================
const Cloud = makeCloud({ getS: () => S, setS: v => { S = v; }, saveLocal, merge: mergeState, refresh: refreshPassive, toast, renderAuth: renderAuthBox });   // 程式在 sync.js（所有語言頁共用）
function renderAuthBox() {
  const top = $('#authTop');
  if (top) {
    if (Cloud.mode === 'google' && !Cloud.user) {
      top.innerHTML = `<div class="authcard"><div><b>用 Google 帳號存進度</b><div class="meta">登入後，換手機、換電腦都能接著練。</div></div><button class="btn solid gbtn-signin" id="gInTop">${GOOGLE_G}登入</button></div>`;
      $('#gInTop', top).onclick = () => Cloud.signIn();
    } else top.innerHTML = '';
  }
  const box = $('#authBox');
  if (!box) return;
  if (Cloud.mode !== 'google') { box.innerHTML = ''; return; }
  if (Cloud.user) {
    box.innerHTML = `<div class="row"><span class="meta">${esc(Cloud.user.email || Cloud.user.displayName || '已登入')}</span><button class="btn quiet" id="gOut" style="min-height:40px">登出</button></div>`;
    $('#gOut', box).onclick = () => Cloud.signOut();
  } else {
    box.innerHTML = `<button class="btn solid block gbtn-signin" id="gIn">${GOOGLE_G}用 Google 登入</button>`;
    $('#gIn', box).onclick = () => Cloud.signIn();
  }
}
const GOOGLE_G = '<svg viewBox="0 0 48 48" width="18" height="18" aria-hidden="true"><path fill="#FFC107" d="M43.6 20.5H42V20H24v8h11.3C33.7 32.7 29.2 36 24 36c-6.6 0-12-5.4-12-12s5.4-12 12-12c3.1 0 5.8 1.2 7.9 3.1l5.7-5.7C34 6.1 29.3 4 24 4 12.9 4 4 12.9 4 24s8.9 20 20 20 20-8.9 20-20c0-1.3-.1-2.4-.4-3.5z"/><path fill="#FF3D00" d="M6.3 14.7l6.6 4.8C14.7 15.1 19 12 24 12c3.1 0 5.8 1.2 7.9 3.1l5.7-5.7C34 6.1 29.3 4 24 4 16.3 4 9.7 8.3 6.3 14.7z"/><path fill="#4CAF50" d="M24 44c5.2 0 9.9-2 13.4-5.2l-6.2-5.2C29.2 35.1 26.7 36 24 36c-5.2 0-9.6-3.3-11.3-7.9l-6.5 5C9.5 39.6 16.2 44 24 44z"/><path fill="#1976D2" d="M43.6 20.5H42V20H24v8h11.3c-.8 2.2-2.2 4.2-4.1 5.6l6.2 5.2C37 39.2 44 34 44 24c0-1.3-.1-2.4-.4-3.5z"/></svg>';
// 從雲端合併後，只更新不會打斷作答的地方
function refreshPassive() {
  if (syncMine()) deck = null;   // 別的裝置新增、改了、刪了自己的單字
  renderGoal();
  if (UI.tab === 'kana' && UI.kanaView === 'table') renderKana();
  if (UI.tab === 'lib' && !$('#q')?.value && !$('#bk')?.innerHTML) renderLib();
}
document.addEventListener('visibilitychange', () => { if (document.visibilityState === 'visible') { renderGoal(); Cloud.schedule(500); } });

// ================= 詞性變化規則 =================
const RULES = [
  { id: 'r-v1', pos: '動詞(一類)', name: '一類動詞', sub: '五段動詞', ex: ['飲む', '書く', '買う'],
    lead: '字尾是う段音（う、く、ぐ、す、つ、ぬ、ぶ、む、る）。變化時，最後一個字在あ、い、う、え、お段之間移動。',
    r: { 'ます形': '字尾換成い段＋ます（む→み）', '否定': '字尾換成い段＋ません', '過去': '字尾換成い段＋ました', '過去否定': '字尾換成い段＋ませんでした',
      'て形': '看字尾決定（見下面的表）', '〜てください': 'て形＋ください', '〜ています': 'て形＋います',
      'ない形': '字尾換成あ段＋ない；「う」結尾的換成「わ」（買う→買わない）', 'た形': '把て形的「て／で」換成「た／だ」', '〜たい': '字尾換成い段＋たい' } },
  { id: 'r-v2', pos: '動詞(二類)', name: '二類動詞', sub: '一段動詞', ex: ['食べる', '見る', '起きる'],
    lead: '字尾是「る」，前面通常是い段或え段的音。變化最簡單：去掉「る」，直接接後面的部分。',
    r: { 'ます形': '去掉る＋ます', '否定': '去掉る＋ません', '過去': '去掉る＋ました', '過去否定': '去掉る＋ませんでした',
      'て形': '去掉る＋て', '〜てください': '去掉る＋てください', '〜ています': '去掉る＋ています',
      'ない形': '去掉る＋ない', 'た形': '去掉る＋た', '〜たい': '去掉る＋たい' } },
  { id: 'r-v3', pos: '動詞(三類)', name: '三類動詞', sub: '不規則動詞', ex: ['する', '来る', '勉強する'],
    lead: '只有「する」（做）和「来る」（來），加上「名詞＋する」（勉強する、散歩する）。沒有規則可套，要直接背。「来る」的漢字讀音會變：きます、きて、こない。',
    r: { 'ます形': 'する→します；来る→来ます（きます）', '否定': 'しません；来ません（きません）', '過去': 'しました；来ました（きました）', '過去否定': 'しませんでした；来ませんでした（きませんでした）',
      'て形': 'して；来て（きて）', '〜てください': 'してください；来てください（きてください）', '〜ています': 'しています；来ています（きています）',
      'ない形': 'しない；来ない（こない）', 'た形': 'した；来た（きた）', '〜たい': 'したい；来たい（きたい）' } },
  { id: 'r-ai', pos: 'い形容詞', name: 'い形容詞', sub: '', ex: ['大きい', '高い', 'いい'],
    lead: '以「い」結尾，可以直接放在名詞前面（大きい犬）。變化都發生在最後的「い」。「いい」變化時要換成「よ」。',
    r: { '〜です': '原形＋です', '過去': 'い→かった＋です', '否定': 'い→くない＋です（也可以說「くありません」）', '過去否定': 'い→くなかった＋です',
      'て形': 'い→くて（又…又…）', '副詞': 'い→く（接動詞，或接「なる」表示變得…）' } },
  { id: 'r-na', pos: 'な形容詞', name: 'な形容詞', sub: '', ex: ['静か', '好き', '元気'],
    lead: '本身不變化，變化都在後面的「です」，跟名詞一樣。放在名詞前面要加「な」，當副詞用要加「に」。',
    r: { '〜です': '＋です', '過去': '＋でした', '否定': '＋じゃありません（正式：ではありません）', '過去否定': '＋じゃありませんでした',
      '＋な＋名詞': '修飾名詞時加「な」：静かな町', '＋に': '當副詞時加「に」：静かに話す' } },
  { id: 'r-n', pos: '名詞', name: '名詞', sub: '', ex: ['学生', '雨', '先生'],
    lead: '名詞本身不變化，變化都在後面的「です」。',
    r: { '〜です': '＋です（是…）', '過去': '＋でした', '否定': '＋じゃありません（正式：ではありません）' } }
];
const RMAP = Object.fromEntries(RULES.map(r => [r.id, r]));
const findWord = (word, pos) => WORDS.find(w => w.kind === 'w' && w.word === word && (!pos || w.pos === pos)) || WORDS.find(w => w.kind === 'w' && w.word === word);
function conjChip(w, label) {
  const row = conjugate(w).find(x => x.label === label);
  if (!row) return '';
  const r = row.r && row.r !== row.s ? `<span class="rc-r">${esc(row.r)}</span>` : '';
  return `<span class="rc-chip"><span lang="ja">${esc(row.s)}</span>${r}</span>`;
}
function rulePage(rule) {
  const exW = rule.ex.map(x => findWord(x, rule.pos)).filter(Boolean);
  const rows = Object.entries(rule.r).map(([label, txt]) => {
    const note = (exW[0] && (conjugate(exW[0]).find(x => x.label === label) || {}).note) || '';
    return `<div class="rc-row"><div class="rc-h"><b>${esc(label)}</b>${note ? `<span class="meta">${esc(note)}</span>` : ''}</div>
      <div class="rc-rule">${esc(txt)}</div>
      <div class="rc-exs">${exW.map(w => conjChip(w, label)).join('')}</div></div>`;
  }).join('');
  let extra = '';
  if (rule.id === 'r-v1') {
    const TE = [['う・つ・る', 'って', ['買う', '待つ', '帰る']], ['む・ぶ・ぬ', 'んで', ['飲む', '遊ぶ', '死ぬ']], ['く', 'いて', ['書く', '聞く']], ['ぐ', 'いで', ['泳ぐ', '脱ぐ']], ['す', 'して', ['話す', '貸す']], ['例外：行く', '行って', ['行く']]];
    extra += `<div class="card"><div class="gp-title">て形・た形：看字尾</div><div class="rc-te">${TE.map(([end, te, ws]) => `<div class="rc-row"><div class="rc-h"><b>${esc(end)} → ${esc(te)}</b><span class="meta">た形：${esc(te.replace(/て$/, 'た').replace(/で$/, 'だ'))}</span></div><div class="rc-exs">${ws.map(x => findWord(x, '動詞(一類)')).filter(Boolean).map(w => `<span class="rc-chip"><span lang="ja">${esc(w.word)} → ${esc(conjugate(w).find(x => x.label === 'て形').s)}</span></span>`).join('')}</div></div>`).join('')}</div></div>`;
    const tricky = WORDS.filter(w => w.pos === '動詞(一類)' && LOOKS_ICHIDAN(w));
    if (tricky.length) extra += `<div class="card"><div class="gp-title">長得像二類的一類動詞</div><p class="meta" style="margin:4px 0 10px">這些字是い段或え段＋る 結尾，看起來像二類，其實是一類，要特別記：</p><div class="rc-words">${tricky.map(w => `<button class="rc-w" data-forms="${esc(w.id)}" lang="ja">${esc(w.word)}</button>`).join('')}</div></div>`;
  }
  if (rule.id === 'r-ai') extra += `<div class="card"><div class="gp-title">特別注意</div><p class="gr-desc" style="margin-top:4px">「いい」（好）變化時要換成「よい」：よかった、よくない、よくて。「きれい」「嫌い」雖然是い結尾，其實是な形容詞（きれいな花、嫌いな食べ物）。</p></div>`;
  const words = WORDS.filter(w => w.kind === 'w' && w.pos === rule.pos);
  return `<button class="gr-back" id="grBack">‹ 文法列表</button>
    <div class="card"><div class="gr-head"><h2>${esc(rule.name)}</h2>${rule.sub ? `<span class="lv">${esc(rule.sub)}</span>` : ''}</div><p class="gr-desc">${esc(rule.lead)}</p></div>
    <div class="card"><div class="gp-title">變化規則（例：${exW.map(w => esc(w.word)).join('、')}）</div><div class="rc-list">${rows}</div></div>
    ${extra}
    <div class="card"><div class="gp-title">App 裡的${esc(rule.name)}（${words.length}）</div><p class="meta" style="margin:4px 0 10px">點一下看完整的變化表。</p><div class="rc-words">${words.map(w => `<button class="rc-w" data-forms="${esc(w.id)}" lang="ja">${esc(w.word)}</button>`).join('')}</div></div>`;
}

// ================= 文法區 =================
const GRAM_GROUPS = [
  ['助詞', ['wa', 'ga', 'o', 'ni', 'de', 'e', 'to', 'mo', 'no', 'kara', 'made', 'ya', 'yori', 'dake', 'zutsu', 'gurai', 'nado']],
  ['句尾與「です」', ['ka', 'ne', 'yo', 'desu', 'janai', 'deshou']],
  ['動詞的變化與句型', ['masu', 'masen', 'mashita', 'masendeshita', 'mashou', 'masenka', 'tai', 'nini', 'te', 'tekudasai', 'naidekudasai', 'teimasu', 'temoii', 'tekara', 'nagara', 'tari', 'nai', 'ta']],
  ['形容詞', ['ikatta', 'ikunai', 'iku', 'naru', 'nana']],
  ['其他句型', ['kono', 'aruiru']]
];
const GP = Object.fromEntries(GRAMMAR_POINTS.map(p => [p.id, p]));
let GIDX = null;
// 每個文法點 → 用到它的例句（第一次打開文法區時才算）
function gramIndex() {
  if (GIDX) return GIDX;
  GIDX = {};
  for (const w of WORDS) {
    if (w.kind !== 'w' || w.custom) continue;
    for (const g of grammarOf(w, toksOf(w), GLOSS)) (GIDX[g.p.id] = GIDX[g.p.id] || []).push({ w, s: g.s });
  }
  // 短句優先，比較好讀；同一句只留一次
  for (const k in GIDX) {
    const seen = new Set();
    GIDX[k] = GIDX[k].filter(x => !seen.has(x.w.sent) && seen.add(x.w.sent)).sort((a, b) => a.w.sent.length - b.w.sent.length);
  }
  return GIDX;
}
