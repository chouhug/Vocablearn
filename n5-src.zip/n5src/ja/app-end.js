const gxSegs = (t, r) => align(t, r) || [{ t, r: null }];
const gxSent = (t, r) => { const g = gxSegs(t, r); return `<div class="sent" lang="ja">${rubyHTML(g, { toks: tokenizeSegs(g, 0, g.length, GLOSS) })}</div>`; };
function gxExamplesHTML(gx) {
  return `<p class="meta gx-tip">上面是整句，中間每個字下面是它的中文，最後一條一條說明為什麼這樣排。點句子裡的字可以查意思。</p>` + gx.ex.map(([s, r, zh, parts, notes, pl], i) => `<div class="gx-ex">
    <div class="gx-n">範例 ${i + 1}</div>
    <div class="ex-row">${gxSent(s, r)}${iconPlay(s, '播放範例')}</div>
    ${romajiLine(segsRomaji(gxSegs(s, r)))}
    <div class="zhline">${esc(zh)}</div>
    <div class="gx-gloss">${parts.map(([w, wr, g]) => g ? `<span class="gx-w"><b lang="ja">${wr ? rubyHTML(gxSegs(w, wr)) : esc(w)}</b><i>${esc(g)}</i></span>` : `<span class="gx-p" lang="ja">${esc(w)}</span>`).join('')}</div>
    <ul class="gx-notes">${notes.map(n => `<li>${esc(n)}</li>`).join('')}</ul>
    <div class="gx-plain"><b>白話</b><span>${esc(pl)}</span></div>
  </div>`).join('') + `<button class="btn solid block gx-go" data-gpane="q">看懂了，來練習（${gx.q.length} 題）</button>`;
}
let gramPane = 'body', gramPaneId = '';
let gramShow = 8;
function renderGram() {
  const host = $('#tab-gram');
  const idx = gramIndex();
  const rule = UI.gramSel && RMAP[UI.gramSel];
  if (rule) {
    host.innerHTML = rulePage(rule);
    $('#grBack', host).onclick = () => { UI.gramSel = ''; saveUI(); renderGram(); window.scrollTo(0, 0); };
    return;
  }
  const p = UI.gramSel && GP[UI.gramSel];
  if (!p) {
    const q = (UI.gramQ || '').trim();
    const hit = x => !q || (x.t + x.d).includes(q);
    const listed = new Set(GRAM_GROUPS.flatMap(g => g[1]));
    const groups = GRAM_GROUPS.map(([h, ids]) => [h, ids.map(id => GP[id]).filter(Boolean)])
      .concat([['其他', GRAMMAR_POINTS.filter(x => !listed.has(x.id))]]);
    const rhit = RULES.filter(r => !q || (r.name + r.sub + r.lead).includes(q));
    const usePath = !q && UI.gramView !== 'cat';
    const viewSeg = !q ? `<div class="seg gr-view" role="group" aria-label="文法排列">${[['path', '關卡（照順序學）'], ['cat', '分類']].map(([k, l]) => `<button data-gview="${k}" aria-pressed="${(UI.gramView || 'path') === k}">${l}</button>`).join('')}</div>` : '';
    host.innerHTML = `<input class="gr-search" id="grQ" type="search" placeholder="搜尋文法：は、て形、想要…" value="${esc(q)}" aria-label="搜尋文法">${viewSeg}
      ${usePath ? gxPathHTML() + (rhit.length ? `<div class="gr-group"><h3>詞性變化規則</h3><div class="rc-grid">${rhit.map(r => `<button class="gr-row rc-tile" data-gram="${r.id}"><b>${esc(r.name)}</b><span class="gd">${esc(r.sub || '變化規則')}</span></button>`).join('')}</div></div>` : '') : `${rhit.length ? `<div class="gr-group"><h3>詞性變化規則</h3><div class="rc-grid">${rhit.map(r => `<button class="gr-row rc-tile" data-gram="${r.id}"><b>${esc(r.name)}</b><span class="gd">${esc(r.sub || '變化規則')}</span></button>`).join('')}</div></div>` : ''}
      ${groups.map(([h, ps]) => { ps = ps.filter(hit); return ps.length ? `<div class="gr-group"><h3>${esc(h)}</h3>${ps.map(x => `<button class="gr-row" data-gram="${x.id}"><b>${esc(x.t)}</b><span class="gn"><span>${(idx[x.id] || []).length}</span>›</span><span class="gd">${esc(x.d)}</span></button>`).join('')}</div>` : ''; }).join('') || (rhit.length ? '' : '<p class="meta">找不到符合的文法。</p>')}`}`;
    $$('[data-gview]', host).forEach(b => b.onclick = () => { UI.gramView = b.dataset.gview; saveUI(); renderGram(); });
    const inp = $('#grQ', host);
    inp.oninput = () => { UI.gramQ = inp.value; renderGramKeepFocus(); };
    return;
  }
  renderGramPoint(host, p, idx[p.id] || []);
}
function renderGramKeepFocus() {
  const pos = $('#grQ').selectionStart; renderGram(); const i = $('#grQ'); i.focus(); try { i.setSelectionRange(pos, pos); } catch (e) {}
}
// @include shared/gram-tab.js（這一段由 build.js 從 n5src/shared/gram-tab.js 複製過來，要改請改那個檔再跑 build.js）
// @end shared/gram-tab.js

// ================= 自訂下拉選單（取代手機內建的選單） =================

// ================= 換介面語言 =================
function setLang(lang, resumeTour) {
  if (lang === LANG) return;
  SET.lang = lang;
  // 單字意思跟著換：中文介面配中文意思，English 介面配英文意思（「兩者都顯示」保留）
  if (lang === 'en' && SET.mean === 'zh') SET.mean = 'en';
  if (lang === 'zh' && SET.mean === 'en') SET.mean = 'zh';
  saveSet();
  if (resumeTour != null) store.set('n5:tourResume', resumeTour);
  location.reload();
}

// ================= 首次使用導覽 =================
const TOUR_ART = `<svg class="tour-art" viewBox="0 0 320 110" aria-hidden="true"><rect width="320" height="110" rx="12" fill="var(--surface2)"/><circle cx="252" cy="34" r="16" fill="var(--c2)"/><path d="M0 110 L70 46 L120 82 L170 30 L240 110Z" fill="var(--c1)"/><path d="M150 50 L170 30 L190 50 L180 46 L170 54 L160 46Z" fill="var(--surface)"/><path d="M120 110 L210 62 L320 104 L320 110Z" fill="var(--c3)"/><path d="M0 98 C60 88 110 104 170 96 S280 86 320 96 L320 110 L0 110Z" fill="var(--pri-soft)"/><rect x="26" y="20" width="44" height="44" rx="10" fill="var(--fill)"/><text x="48" y="51" text-anchor="middle" font-size="28" font-weight="700" fill="var(--fill-ink)" font-family="var(--font-kana)">あ</text></svg>`;
PAGE.tour = {
  key: 'n5:toured',
  art: TOUR_ART,
  steps: () => [
  { t: '歡迎使用日語 N5', d: '從五十音開始，一路學到 N5 的單字和文法。先選介面語言，接下來用 30 秒認識每個分頁。', lang: true },
  { el: '.brand', t: '切換語言', d: '點左上角的語言名稱可以換到別的語言；也可以鎖定只學其中幾個語言，避免一次學太多。' },
  { el: '[data-tab="kana"]', tab: 'kana', t: '五十音', d: '平假名、片假名的表，點一個字可以聽發音、看例字；切到「練習」做認字測驗。' },
  { el: '[data-tab="card"]', tab: 'card', t: '字卡：挑要學的字', d: '新字一張一張看：已經會的按「已經會了」，想練的按「列入考題」，之後單選和填空就會出這些字。' },
  { el: '[data-tab="mc"]', tab: 'mc', t: '單選', d: '日→中、中→日、聽發音、漢字讀音、助詞填空、詞性變化，左上角可以換題型和題目來源。' },
  { el: '[data-tab="fill"]', tab: 'fill', t: '填空・聽寫', d: '看例句打出空格裡的字，答對才算「已學會」，之後照時間排到期複習。切到「聽寫」可以練聽力。' },
  { el: '[data-tab="gram"]', tab: 'gram', t: '文法', d: '每個文法點都有說明和例句，也有動詞、形容詞的變化規則。' },
  { el: '[data-tab="lib"]', tab: 'lib', t: '單字庫・設定', d: '看進度、搜尋單字、進入錯題和到期複習。下面的「設定」可以調音效、用 Google 登入同步進度、換介面語言。' },
  { el: ['#furiBtn', '#romajiBtn', '#themeBtn'], t: '上方的小按鈕', d: '「漢」切換漢字上的假名，「Aa」顯示羅馬拼音，最右邊切換淺色／深色。' },
  { t: '小提示', d: '例句裡的單字都可以點，會跳出意思和讀音。準備好就開始吧！', last: true }
],
  extra: st => st.lang ? `<div class="tour-lang" data-noi18n><button class="btn ${LANG === 'zh' ? 'solid' : 'quiet'}" data-tlang="zh">中文（繁體）</button><button class="btn ${LANG === 'en' ? 'solid' : 'quiet'}" data-tlang="en">English</button></div>` : '',
  bind: (card, T) => $$('[data-tlang]', card).forEach(b => b.onclick = () => { if (b.dataset.tlang === LANG) return T.go(1); setLang(b.dataset.tlang, 1); }),
  fresh: () => !Object.keys(S.items).some(k => !/^(it|es|de|ru|en):/.test(k))   // 只看日文的紀錄（其他語言的 id 有前綴）
};
// @include shared/tour.js
// @end shared/tour.js

// ================= 啟動 =================
applyTheme();
applyRomaji();
applyFuri();
renderGoal();
Voice.init();
showTab(TABS.includes(UI.tab) ? UI.tab : 'kana');
Cloud.init();
{
  const resume = store.get('n5:tourResume', null);
  if (resume != null) { store.set('n5:tourResume', null); Tour.start(resume); }
  else Tour.auto();
}
})();

