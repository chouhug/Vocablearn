// 日文填空「要填哪個形」的標示（engine.js 的 fillFormTag）：node n5src/ja/form-test.js
// 用 build.js 的 JA_DATA（扣掉 i18n）載入資料和 engine.js，檢查所有填空題。
const fs = require('fs'), vm = require('vm'), path = require('path');
const D = __dirname;
const build = fs.readFileSync(path.join(D, '..', 'build.js'), 'utf8');
const files = JSON.parse(build.match(/const JA_DATA = (\[[^\]]*\])/)[1]).filter(f => !/i18n/.test(f));
const ctx = { console }; vm.createContext(ctx);
vm.runInContext(files.map(f => fs.readFileSync(path.join(D, f), 'utf8')).join('\n') + '\n;this.W = prepWords(VOCAB); this.tag = fillFormTag;', ctx);
let bad = 0; const ok = (c, m) => { if (!c) { console.log('✗ ' + m); bad++; } };
const W = ctx.W.filter(w => w.ans), by = {};
for (const w of W) { const t = ctx.tag(w); by[t] = (by[t] || 0) + 1; ok(t !== '變化形', `${w.word} → ${w.ans}：找不到是哪個形`); if (w.ans === w.word) ok(t === '', `${w.word}：原形不該標`); }
const get = (word, ans) => { const w = W.find(x => x.word === word && x.ans === ans); return w ? ctx.tag(w) : null; };
ok(get('寒い', '寒かった') === '過去式', '寒い → 寒かった 要標「過去式」');
ok(get('食べる', '食べます') === 'ます形・禮貌', '食べる → 食べます 要標「ます形・禮貌」');
ok(Object.keys(by).length >= 4, '至少有幾種不同的形');
console.log(bad ? `✗ ${bad} 項失敗` : `日文填空形的標示：${W.length} 題全部通過（${Object.entries(by).map(([k, v]) => `${k || '原形'} ${v}`).join('、')}）`);
process.exit(bad ? 1 : 0);
