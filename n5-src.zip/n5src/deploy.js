/* GitHub Actions 用：把 n5-src.zip 的內容同步到網站（repo 根目錄）
   node n5src/deploy.js <zip 解開的資料夾> <repo 根目錄> <這次推送有沒有改 zip：1／0>
   1. 用 n5src/build.js 在解開的 n5work 裡產生所有頁面
   2. 跟 repo 根目錄的網站檔案比對
      - 一樣：什麼都不做
      - 不一樣、這次有改 zip：把新的檔案複製到根目錄，sw.js 的快取版本號加一（手機上的 App 才會換新版）
      - 不一樣、這次沒改 zip：有人直接改了網站上的檔案 → 失敗，不覆蓋（請把改動放進 zip）
   會在 GITHUB_OUTPUT 寫 changed=true／false（有沒有要 commit）*/
'use strict';
const fs = require('fs');
const path = require('path');
const { execFileSync } = require('child_process');
const [SRC, ROOT, ZIP_CHANGED] = [path.resolve(process.argv[2]), path.resolve(process.argv[3]), process.argv[4] === '1'];
const WORK = path.join(SRC, 'n5work');
const setOut = (k, v) => { if (process.env.GITHUB_OUTPUT) fs.appendFileSync(process.env.GITHUB_OUTPUT, `${k}=${v}\n`); };
const read = p => fs.existsSync(p) ? fs.readFileSync(p) : null;

execFileSync('node', [path.join(SRC, 'n5src', 'build.js'), WORK], { stdio: 'inherit' });

const files = fs.readdirSync(WORK).filter(f => fs.statSync(path.join(WORK, f)).isFile());
const diffs = files.filter(f => { const a = read(path.join(WORK, f)), b = read(path.join(ROOT, f)); return !b || !a.equals(b); });
if (!diffs.length) { console.log('網站上的檔案和 n5-src.zip 一致，不用更新'); setOut('changed', 'false'); process.exit(0); }
if (!ZIP_CHANGED) {
  console.error('網站上的這些檔案和 n5-src.zip 產生的不一樣，但這次沒有改 zip：' + diffs.join('、'));
  console.error('看起來有人直接改了網站上的檔案。為了不蓋掉那些改動，這次不自動更新；請把改動放進 n5-src.zip（n5src 或 n5work）再上傳。');
  setOut('changed', 'false'); process.exit(1);
}
// 快取版本號：取 zip 和網站上比較大的那個再加一
const ver = s => { const m = String(s || '').match(/const CACHE = 'n5-v(\d+)'/); return m ? +m[1] : 0; };
const swZip = path.join(WORK, 'sw.js');
const next = Math.max(ver(read(swZip)), ver(read(path.join(ROOT, 'sw.js')))) + 1;
fs.writeFileSync(swZip, String(read(swZip)).replace(/const CACHE = 'n5-v\d+'/, `const CACHE = 'n5-v${next}'`));
if (!diffs.includes('sw.js')) diffs.push('sw.js');
for (const f of diffs) fs.copyFileSync(path.join(WORK, f), path.join(ROOT, f));
console.log(`已從 n5-src.zip 更新：${diffs.join('、')}（快取版本 n5-v${next}）`);
setOut('changed', 'true');
setOut('summary', `${diffs.join('、')}（快取 n5-v${next}）`);
