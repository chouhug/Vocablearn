// 用真的瀏覽器測「隨機抽的來源不顯示題數」和「填空錯題」：node n5src/review-e2e.js n5work [ja it …]
// 需要 playwright 和 Chrome（不在 test-all.js 裡）。填空錯題的規則本身在 core-test.js。
let chromium; try { ({ chromium } = require('playwright')); } catch (e) { ({ chromium } = require('/opt/npm-tools/node_modules/playwright')); }
const http = require('http'), fs = require('fs'), path = require('path');
const ROOT = path.resolve(process.argv[2] || 'n5work');
const LANGS = process.argv.slice(3).length ? process.argv.slice(3) : ['ja', 'it'];
const srv = http.createServer((q, r) => { const f = path.join(ROOT, decodeURIComponent(q.url.split('?')[0])); fs.readFile(f, (e, d) => { if (e) { r.writeHead(404); return r.end(); } r.writeHead(200, { 'content-type': f.endsWith('.html') ? 'text/html; charset=utf-8' : 'text/javascript' }); r.end(d); }); });
let bad = 0; const ok = (c, m) => { console.log((c ? '✓ ' : '✗ ') + m); if (!c) bad++; };
(async () => {
  await new Promise(r => srv.listen(0, r)); const base = 'http://127.0.0.1:' + srv.address().port + '/';
  const br = await chromium.launch({ executablePath: process.env.CHROME || (fs.existsSync('/usr/bin/google-chrome') ? '/usr/bin/google-chrome' : undefined), args: ['--no-sandbox'] });
  for (const L of LANGS) {
    const file = L === 'ja' ? 'index.html' : L + '.html', pre = L === 'ja' ? 'n5' : L;
    const ctx = await br.newContext({ viewport: { width: 390, height: 844 }, isMobile: true }); await ctx.route(/^https:\/\//, r => r.abort());
    await ctx.addInitScript(([l, pre]) => { if (!localStorage.getItem('langs:last')) { localStorage.setItem('langs:last', JSON.stringify(l)); localStorage.setItem('langs:v1', JSON.stringify({ active: [l], max: 2, lock: true, note: '' })); localStorage.setItem(pre + ':toured', '1'); localStorage.setItem('n5:settings', JSON.stringify({ pop: 'off' })); localStorage.setItem(pre + ':ui', JSON.stringify({ tab: 'card', cardSrc: 'new' })); } }, [L, pre]);
    const pg = await ctx.newPage(); const errs = []; pg.on('pageerror', e => errs.push(e.message));
    await pg.goto(base + file); await pg.waitForSelector('#tab-card [data-a="queue"]');
    for (let i = 0; i < 12; i++) { await pg.click('#tab-card [data-a="queue"]'); await pg.waitForTimeout(100); }
    // 前 8 個改成已學會、以前錯過（錯題複習）；後 4 個留在待考、其中 2 個是填空錯題
    await pg.evaluate(() => { const P = JSON.parse(localStorage.getItem('n5:progress')); const ids = Object.keys(P.items); ids.forEach((id, i) => { const r = P.items[id]; if (i < 8) Object.assign(r, { s: 'learned', w: { mc: 2, fill: 2 }, lv: 2, due: '2099-01-01' }); else if (i < 10) r.w = { fill: 1 }; }); localStorage.setItem('n5:progress', JSON.stringify(P)); });
    await pg.reload(); await pg.waitForTimeout(500);
    const opts = async id => pg.evaluate(id => [...document.querySelectorAll('#' + id + ' option')].map(o => o.textContent.trim()), id);
    await pg.click('[data-tab="mc"]'); await pg.waitForSelector('#mcSrc', { state: 'attached' });
    let o = await opts('mcSrc'); console.log('   單選來源：' + o.join('｜'));
    ok(o.some(x => /^待考 \d+$/.test(x)) && o.includes('錯題複習') && o.includes('複習已學會'), '單選：待考有數字，錯題複習、複習已學會沒有');
    await pg.click('[data-tab="fill"]'); await pg.waitForSelector('#fillSrc', { state: 'attached' });
    o = await opts('fillSrc'); console.log('   填空來源：' + o.join('｜'));
    ok(o.includes('待考 4') && o.includes('填空錯題 2') && o.includes('錯題複習'), '填空：填空錯題的字也還在待考（待考 4、填空錯題 2），錯題複習沒有數字');
    await pg.selectOption('#fillSrc', 'fillReview'); await pg.waitForSelector('#fillIn');
    ok(!/剩 \d+ · 共/.test(await pg.textContent('#tab-fill .qhead')) && !!(await pg.$('#tab-fill .qprog')), '填空錯題複習：題目上方沒有「剩 · 共」，只有進度條');
    await pg.click('[data-tab="card"]'); await pg.waitForSelector('#cardSrc', { state: 'attached' });
    o = await opts('cardSrc'); console.log('   字卡來源：' + o.join('｜'));
    ok(o.includes('複習已學會') && o.includes('錯題複習') && o.some(x => /^新字 \d+$/.test(x)), '字卡：複習類沒有數字，新字有');
    await pg.selectOption('#cardSrc', 'learned'); await pg.waitForTimeout(300);
    ok(!/剩 \d+ · 共/.test(await pg.textContent('#tab-card')), '字卡複習已學會：沒有「剩 · 共」');
    await pg.click('[data-tab="mc"]'); await pg.selectOption('#mcSrc', 'learned'); await pg.waitForSelector('#mcq .opt');
    ok(!/剩 \d+ · 共/.test(await pg.textContent('#tab-mc .qhead')), '單選複習已學會：沒有「剩 · 共」');
    await pg.click('#mcq .opt >> nth=0'); await pg.waitForTimeout(300);
    ok(!/剩 \d+ · 共/.test(await pg.textContent('#tab-mc .qhead')), '答完一題也不會冒出題數');
    await pg.selectOption('#mcSrc', 'learn'); await pg.waitForSelector('#mcq .opt');
    ok(/剩 \d+ · 共 \d+/.test(await pg.textContent('#tab-mc .qhead')), '待考照常顯示「剩 · 共」');
    if (L === 'ja') {
      await pg.click('[data-tab="kana"]'); await pg.waitForTimeout(300);
      if (await pg.$('[data-kview="quiz"]')) { await pg.click('[data-kview="quiz"]'); await pg.waitForTimeout(300); }
      o = await opts('kRange'); console.log('   五十音範圍：' + o.join('｜'));
      ok(o.includes('錯題複習') && o.some(x => /^全部 \d+$/.test(x)), '五十音：錯題複習沒有數字');
    }
    ok(!errs.length, `${L} 沒有錯誤訊息` + (errs.length ? '：' + errs.join(' | ') : ''));
    await ctx.close();
  }
  await br.close(); srv.close(); console.log(bad ? `✗ ${bad} 項失敗` : '全部通過'); process.exit(bad ? 1 : 0);
})();
