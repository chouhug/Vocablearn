// 用真的瀏覽器測「填空填了別的字會標出來」：node n5src/other-e2e.js n5work [ja it es de ru en]
// 需要 playwright 和 Chrome（不在 test-all.js 裡）。日文的比對規則在 ja/other-test.js。
let chromium; try { ({ chromium } = require('playwright')); } catch (e) { ({ chromium } = require('/opt/npm-tools/node_modules/playwright')); }
const http = require('http'), fs = require('fs'), path = require('path');
const ROOT = path.resolve(process.argv[2] || 'n5work');
const LANGS = process.argv.slice(3).length ? process.argv.slice(3) : ['ja', 'it', 'es', 'de', 'ru', 'en'];
// 兩個常見字：第一個剛好是這題的答案時改用第二個
const TRY = { ja: ['inu', 'neko'], it: ['gatto', 'cane'], es: ['gato', 'perro'], de: ['Katze', 'Hund'], ru: ['кошка', 'собака'], en: ['reliable', 'although'] };
const srv = http.createServer((q, r) => { const f = path.join(ROOT, decodeURIComponent(q.url.split('?')[0])); fs.readFile(f, (e, d) => { if (e) { r.writeHead(404); return r.end(); } r.writeHead(200, { 'content-type': f.endsWith('.html') ? 'text/html; charset=utf-8' : 'text/javascript' }); r.end(d); }); });
let bad = 0; const ok = (c, m) => { console.log((c ? '✓ ' : '✗ ') + m); if (!c) bad++; };
(async () => {
  await new Promise(r => srv.listen(0, r)); const base = 'http://127.0.0.1:' + srv.address().port + '/';
  const br = await chromium.launch({ executablePath: process.env.CHROME || (fs.existsSync('/usr/bin/google-chrome') ? '/usr/bin/google-chrome' : undefined), args: ['--no-sandbox'] });
  for (const L of LANGS) for (const en of L === 'ja' ? [false, true] : [false]) {
    console.log('—— ' + L + (en ? '（English 介面）' : ''));
    const file = L === 'ja' ? 'index.html' : L + '.html', pre = L === 'ja' ? 'n5' : L;
    const ctx = await br.newContext({ viewport: { width: 360, height: 740 }, isMobile: true, hasTouch: true, colorScheme: en ? 'dark' : 'light' }); await ctx.route(/^https:\/\//, r => r.abort());
    await ctx.addInitScript(([l, pre, en]) => { if (!localStorage.getItem('langs:last')) { localStorage.setItem('langs:last', JSON.stringify(l)); localStorage.setItem('langs:v1', JSON.stringify({ active: [l], max: 2, lock: true, note: '' })); localStorage.setItem(pre + ':toured', '1'); localStorage.setItem('n5:settings', JSON.stringify(Object.assign({ pop: 'off', vtip: 'off' }, en ? { lang: 'en' } : {}))); localStorage.setItem(pre + ':ui', JSON.stringify({ tab: 'card', cardSrc: 'new' })); } }, [L, pre, en]);
    const pg = await ctx.newPage(); const errs = []; pg.on('pageerror', e => errs.push(e.message));
    await pg.goto(base + file); await pg.waitForSelector('#tab-card [data-a="queue"]');
    for (let i = 0; i < 4; i++) { await pg.click('#tab-card [data-a="queue"]'); await pg.waitForTimeout(80); }
    await pg.click('[data-tab="fill"]'); await pg.waitForSelector('#fillIn');
    let shown = false;
    for (const t of TRY[L]) {
      await pg.fill('#fillIn', t); await pg.click('#fillGo'); await pg.waitForTimeout(300);
      if (await pg.$('#fillAfter .hl-warn:not(.other-word)')) { await pg.click('#fillGo'); await pg.waitForTimeout(300); }   // 同義字的「再想想看」
      const box = await pg.$('#fillAfter .other-word');
      if (box) {
        const txt = (await box.textContent()).replace(/\s+/g, ' ');
        console.log('   ' + txt);
        ok(en ? /You wrote .+ is a different word:/.test(txt) : /你寫的 .+ 是另一個字：/.test(txt), '答錯時標出填的是另一個字和意思');
        ok(await pg.evaluate(() => { const r = document.querySelector('#fillAfter .other-word').getBoundingClientRect(); return r.left >= 0 && r.right <= innerWidth; }), '360px 寬沒有超出螢幕');
        await pg.screenshot({ path: `shot-other-${L}${en ? '-en' : ''}.png` });
        shown = true; break;
      }
      await pg.click('#fillGo'); await pg.waitForSelector('#fillIn:not([readonly])');
    }
    ok(shown, `填了「${TRY[L].join('／')}」有標出來`);
    // 亂打、看答案：不會出現
    await pg.click('#fillGo'); await pg.waitForSelector('#fillIn:not([readonly])');
    await pg.fill('#fillIn', 'qqzzx'); await pg.click('#fillGo'); await pg.waitForTimeout(300);
    ok(!(await pg.$('#fillAfter .other-word')), '亂打的字：不標');
    await pg.click('#fillGo'); await pg.waitForSelector('#fillIn:not([readonly])');
    await pg.fill('#fillIn', TRY[L][0]); await pg.click('#fillShow'); await pg.waitForTimeout(300);
    ok(!(await pg.$('#fillAfter .other-word')), '按「看答案」：不標');
    ok(!errs.length, `${L} 沒有錯誤訊息` + (errs.length ? '：' + errs.join(' | ') : ''));
    await ctx.close();
  }
  await br.close(); srv.close(); console.log(bad ? `✗ ${bad} 項失敗` : '全部通過'); process.exit(bad ? 1 : 0);
})();
