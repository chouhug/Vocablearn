// 用真的瀏覽器（手機寬度 390px）走一遍「我的造句」：node n5src/sents-e2e.js n5work [en it es de ru]
// 需要 playwright 和 Chrome（GitHub Actions 沒有，所以不在 test-all.js 裡）；會在目前的資料夾留下 shot-*.png 截圖
let chromium; try { ({ chromium } = require('playwright')); } catch (e) { ({ chromium } = require('/opt/npm-tools/node_modules/playwright')); }
const http = require('http'), fs = require('fs'), path = require('path');
const ROOT = path.resolve(process.argv[2]);
const LANGS = process.argv.slice(3).length ? process.argv.slice(3) : ['en'];
const srv = http.createServer((q, r) => { const f = path.join(ROOT, decodeURIComponent(q.url.split('?')[0])); fs.readFile(f, (e, d) => { if (e) { r.writeHead(404); return r.end(); } r.writeHead(200, { 'content-type': f.endsWith('.html') ? 'text/html; charset=utf-8' : f.endsWith('.js') ? 'text/javascript' : 'application/octet-stream' }); r.end(d); }); });
let bad = 0; const ok = (c, m) => { console.log((c ? '✓ ' : '✗ ') + m); if (!c) bad++; };
(async () => {
  await new Promise(r => srv.listen(0, r)); const base = 'http://127.0.0.1:' + srv.address().port + '/';
  const br = await chromium.launch({ executablePath: process.env.CHROME || (fs.existsSync('/usr/bin/google-chrome') ? '/usr/bin/google-chrome' : undefined), args: ['--no-sandbox'] });
  for (const L of LANGS) {
    console.log('—— ' + L);
    const ctx = await br.newContext({ viewport: { width: 390, height: 780 }, deviceScaleFactor: 2, isMobile: true, hasTouch: true });
    await ctx.route(/^https:\/\//, r => r.abort());
    await ctx.addInitScript(l => { if (!localStorage.getItem('langs:last')) { localStorage.setItem('langs:last', JSON.stringify(l)); localStorage.setItem('langs:v1', JSON.stringify({ active: [l], max: 2, lock: true, note: '' })); localStorage.setItem(l + ':toured', '1'); localStorage.setItem(l + ':ui', JSON.stringify({ tab: 'lib' })); } }, L);
    const pg = await ctx.newPage(); const errs = [];
    pg.on('pageerror', e => errs.push(e.message)); pg.on('console', m => { if (m.type() === 'error' && !/net::ERR|Failed to load resource/.test(m.text())) errs.push(m.text()); });
    await pg.goto(base + L + '.html'); await pg.waitForFunction(() => window.ITApp);
    // 挑一個有例句的名詞：它的例句一定用到這個字，拿來當「自己寫的句子」
    const w = await pg.evaluate(() => { const w = ITApp.WORDS.find(w => w.pos === 'n' && w.sent.split(' ').length > 3); return { id: w.id, word: w.word, sent: w.sent }; });
    await pg.evaluate(id => ITApp.openWord(id), w.id); await pg.waitForSelector('#usForm');
    await pg.click('#usForm [type=submit]'); ok(await pg.evaluate(id => !(ITApp.getRec(id).u || []).length, w.id), '空白不會存');
    await pg.fill('#usIn', w.sent); await pg.click('#usForm [type=submit]'); await pg.waitForSelector('.mysent');
    ok(await pg.evaluate(([id, s]) => { const r = ITApp.getRec(id); return r.u.length === 1 && r.u[0].s === s && r.s === 'new' && JSON.parse(localStorage.getItem('n5:progress')).items[id].u[0].s === s; }, [w.id, w.sent]), '句子存進這個字的紀錄和 localStorage，學習狀態不變');
    ok(/已存到我的造句/.test(await pg.textContent('#toast')), '句子裡有這個字：直接存');
    await pg.fill('#usIn', w.sent); await pg.click('#usForm [type=submit]'); await pg.waitForTimeout(100);
    ok(await pg.evaluate(id => ITApp.getRec(id).u.length === 1, w.id), '同一句不會存兩次');
    await pg.fill('#usIn', 'zzz qqq'); await pg.click('#usForm [type=submit]'); await pg.waitForTimeout(150);
    ok(/沒看到/.test(await pg.textContent('#toast')) && await pg.evaluate(id => ITApp.getRec(id).u.length === 2, w.id), '句子裡沒有這個字：還是存，但會提醒');
    await pg.waitForTimeout(350);
    await pg.locator('.sheet-body').evaluate(el => { el.scrollTop = el.scrollHeight; });
    await pg.screenshot({ path: `shot-${L}-sents.png` });
    ok(await pg.evaluate(() => document.documentElement.scrollWidth <= innerWidth && [...document.querySelectorAll('#usBox textarea, #usBox button, #usBox .mysent')].every(x => { const r = x.getBoundingClientRect(); return r.left >= 0 && r.right <= innerWidth; })), '手機寬度：沒有超出螢幕');
    // 答題後還在
    await pg.evaluate(id => { const w = ITApp.WORDS.find(w => w.id === id); ITApp.touch(id, { s: 'queued' }); ITApp.record(w, 'fill', true, 'learn'); }, w.id);
    ok(await pg.evaluate(id => ITApp.getRec(id).s === 'learned' && ITApp.getRec(id).u.length === 2, w.id), '答題後句子還在');
    // 重新整理、清單
    await pg.reload(); await pg.waitForSelector('#listBox');
    await pg.click('#listBox summary'); await pg.click('[data-list="sent"]');
    ok(/2 句/.test(await pg.textContent('#listBox .lrows')), '單字庫清單「我的造句」看得到（2 句）');
    await pg.screenshot({ path: `shot-${L}-sentlist.png`, fullPage: true });
    await pg.click('#listBox .lrows button[data-id]'); await pg.waitForSelector('[data-usdel]');
    // 刪除（要按兩次）
    await pg.click('[data-usdel="1"]'); ok(await pg.evaluate(id => ITApp.getRec(id).u.length === 2, w.id), '刪除按第一次只是確認');
    await pg.click('[data-usdel="1"]'); await pg.waitForTimeout(150);
    ok(await pg.evaluate(([id, s]) => { const u = ITApp.getRec(id).u; return u.length === 1 && u[0].s === s; }, [w.id, w.sent]), '刪掉第二句，第一句還在');
    await pg.click('.pk-x'); await pg.waitForTimeout(300);
    // 清除學習紀錄：句子留著
    await pg.evaluate(() => { document.querySelectorAll('details.lst').forEach(d => d.open = true); });
    await pg.click('#resetIt'); await pg.click('#rsYes'); await pg.waitForTimeout(300);
    ok(await pg.evaluate(id => ITApp.getRec(id).s === 'new' && ITApp.getRec(id).u.length === 1, w.id), '清除學習紀錄後句子還在');
    ok(!errs.length, '沒有 JavaScript 錯誤' + (errs.length ? '：' + errs.join(' | ') : ''));
    await ctx.close();
  }
  await br.close(); srv.close();
  console.log(bad ? bad + ' 項失敗' : '全部通過'); process.exit(bad ? 1 : 0);
})().catch(e => { console.error(e); process.exit(1); });
