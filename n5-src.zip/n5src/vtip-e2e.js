// 用真的瀏覽器測「動詞變化小提醒＋題目置中」（shared/verb-tip.js）：node n5src/vtip-e2e.js n5work
// 需要 playwright 和 Chrome（不在 test-all.js 裡）。會留下 shot-vtip-*.png
let chromium; try { ({ chromium } = require('playwright')); } catch (e) { ({ chromium } = require('/opt/npm-tools/node_modules/playwright')); }
const http = require('http'), fs = require('fs'), path = require('path');
const ROOT = path.resolve(process.argv[2] || 'n5work');
const srv = http.createServer((q, r) => { const f = path.join(ROOT, decodeURIComponent(q.url.split('?')[0])); fs.readFile(f, (e, d) => { if (e) { r.writeHead(404); return r.end(); } r.writeHead(200, { 'content-type': f.endsWith('.html') ? 'text/html; charset=utf-8' : 'text/javascript' }); r.end(d); }); });
let bad = 0; const ok = (c, m) => { console.log((c ? '✓ ' : '✗ ') + m); if (!c) bad++; };
(async () => {
  await new Promise(r => srv.listen(0, r)); const base = 'http://127.0.0.1:' + srv.address().port + '/';
  const br = await chromium.launch({ executablePath: process.env.CHROME || (fs.existsSync('/usr/bin/google-chrome') ? '/usr/bin/google-chrome' : undefined), args: ['--no-sandbox'] });
  for (const [L, file, pre, vw, vh, theme] of [['ja', 'index.html', 'n5', 385, 827, 'dark'], ['it', 'it.html', 'it', 360, 740, 'light'], ['ru', 'ru.html', 'ru', 412, 915, 'light'], ['de', 'de.html', 'de', 390, 844, 'dark']]) {
    const ctx = await br.newContext({ viewport: { width: vw, height: vh }, deviceScaleFactor: 2, isMobile: true, hasTouch: true }); await ctx.route(/^https:\/\//, r => r.abort());
    await ctx.addInitScript(([l, pre, theme]) => { if (!localStorage.getItem('langs:last')) { localStorage.setItem('langs:last', JSON.stringify(l)); localStorage.setItem('langs:v1', JSON.stringify({ active: [l], max: 2, lock: true, note: '' })); localStorage.setItem(pre + ':toured', '1'); localStorage.setItem('n5:settings', JSON.stringify({ pop: 'off', theme })); localStorage.setItem(pre + ':ui', JSON.stringify({ tab: 'card', cardSrc: 'new' })); } }, [L, pre, theme]);
    const pg = await ctx.newPage(); const errs = []; pg.on('pageerror', e => errs.push(e.message));
    await pg.goto(base + file); await pg.waitForSelector('#tab-card [data-a="queue"]'); await pg.waitForTimeout(400);
    const m = async tag => {
      const r = await pg.evaluate(() => {
        const t = document.querySelector('.tab:not([hidden])'), bar = document.querySelector('.tabbar').getBoundingClientRect(), top = document.querySelector('header').getBoundingClientRect().bottom;
        const kids = [...t.children].filter(x => !x.classList.contains('vtip-slot') && x.offsetHeight);
        const a = kids[0].getBoundingClientRect(), z = kids[kids.length - 1].getBoundingClientRect();
        const s = t.querySelector('.vtip-slot'), tip = s && !s.hidden && s.querySelector('.vtip');
        return { tip: !!tip, tipH: tip ? tip.offsetHeight : 0, above: Math.round(a.top - top), below: Math.round(bar.top - z.bottom), pad: parseFloat(t.style.paddingTop) || 0, scroll: document.documentElement.scrollHeight > innerHeight, slots: document.querySelectorAll('.vtip-slot:not([hidden])').length, forms: tip ? tip.querySelectorAll('.vtip-f').length : 0 };
      });
      ok(!r.scroll, `${L} ${tag}：不用捲動`);
      if (r.tip) ok(r.pad === 0 && r.forms >= 2, `${L} ${tag}：題目在上面，下面放了動詞變化（${r.forms} 個形，高 ${r.tipH}px）`);
      else ok(r.pad > 0 ? Math.abs(r.above - r.below) < 40 : true, `${L} ${tag}：沒放提醒，題目置中（上 ${r.above}px／下 ${r.below}px）`);
      ok(r.slots <= 1, `${L} ${tag}：只有一個提醒`);
      await pg.screenshot({ path: `shot-vtip-${L}-${tag}.png` }); return r;
    };
    await m('card');
    for (let i = 0; i < 4; i++) { await pg.click('#tab-card [data-a="queue"]'); await pg.waitForTimeout(150); }
    await m('card2');
    await pg.click('[data-tab="mc"]'); await pg.waitForSelector('#mcq .opt'); await pg.waitForTimeout(300); const rm = await m('mc');
    const y0 = await pg.evaluate(() => document.querySelector('#mcq').getBoundingClientRect().top);
    await pg.click('#mcq .opt >> nth=0'); await pg.waitForTimeout(400);
    const y1 = await pg.evaluate(() => document.querySelector('#mcq').getBoundingClientRect().top);
    const sy = await pg.evaluate(() => scrollY);
    ok(Math.abs(y1 + sy - y0) < 1, `${L} 單選答完：題目沒有因為重新排版移動`);
    await pg.click('[data-tab="fill"]'); await pg.waitForSelector('#fillIn'); await pg.waitForTimeout(300); const rf = await m('fill');
    // 看更多
    if (await pg.$('.vtip-more')) {
      await pg.click('.vtip-more'); await pg.waitForTimeout(400);
      if (L === 'ja') ok(await pg.evaluate(() => !document.querySelector('#tab-mc').hidden && /詞性變化/.test(document.querySelector('#tab-mc').textContent)), 'ja 看更多：到單選的詞性變化練習');
      else { ok(await pg.evaluate(() => !!document.querySelector('.pk:not([hidden]) .t')), `${L} 看更多：打開動詞的變化表`); await pg.click('.pk-x'); await pg.waitForTimeout(300); }
    }
    // 設定關掉：題目置中
    await pg.evaluate(() => { const st = JSON.parse(localStorage.getItem('n5:settings')); st.vtip = 'off'; localStorage.setItem('n5:settings', JSON.stringify(st)); });
    await pg.evaluate(p => { const u = JSON.parse(localStorage.getItem(p + ':ui')); u.tab = 'card'; localStorage.setItem(p + ':ui', JSON.stringify(u)); }, pre);
    await pg.reload(); await pg.waitForSelector('#tab-card [data-a="queue"]'); await pg.waitForTimeout(400);
    const off = await m('off');
    ok(!off.tip, `${L} 設定不顯示：沒有動詞變化`);
    ok(!errs.length, `${L} 沒有錯誤訊息` + (errs.length ? '：' + errs.join(' | ') : ''));
    await ctx.close();
  }
  await br.close(); srv.close(); console.log(bad ? `✗ ${bad} 項失敗` : '全部通過'); process.exit(bad ? 1 : 0);
})();
