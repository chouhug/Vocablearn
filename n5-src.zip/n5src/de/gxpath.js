(function (G) { const DE = G.DE || (G.DE = {});
/* 德文文法關卡：由淺到深，後面的關卡會用到前面學過的東西 */
DE.GX_PATH = [
  ['開口說', '我、你、他，「我是…」「我叫…」', ['pron', 'sein', 'intro']],
  ['名詞和冠詞', '三個性別、der／die／das、ein／eine、複數，「…很…」', ['noun-gender', 'art-def', 'art-indef', 'noun-plural', 'adj-pred']],
  ['動詞現在式', '動詞換字尾、haben、會變母音的動詞、動詞放第二位、數字', ['pres-reg', 'haben', 'stem', 'v2', 'num']],
  ['問句和否定', '疑問詞、是非問句、du 和 Sie、kein 和 nicht、und／aber／denn', ['wfrage', 'janein', 'sie', 'kein', 'konj']],
  ['受格', '「做什麼」的對象 den／einen、es gibt、喜歡做、我想要', ['cases', 'akk', 'esgibt', 'gern', 'moechte']],
  ['能、想、得，句框', '情態動詞、第二個動詞放句尾、分離動詞、命令、man', ['modal', 'satzklammer', 'sep', 'imper', 'man']],
  ['與格和「我的」', '給誰 dem／der、代名詞 mich／mir、gefallen、mein、dieser', ['dat', 'pron-obj', 'gefallen', 'poss', 'demo']],
  ['介係詞', '接受格、接與格、在哪裡和去哪裡、im／ins、在家和回家', ['prep-akk', 'prep-dat', 'prep-wechsel', 'contract', 'zuhause']],
  ['時間', '幾點、星期、月份', ['time', 'days']],
  ['過去', '完成式 haben／sein、war 和 hatte、反身動詞', ['perf-haben', 'perf-sein', 'praet', 'refl']],
  ['形容詞和長句子', '形容詞詞尾、比較級、weil／dass 子句', ['adj-end', 'compar', 'subord']]
];
})(typeof window !== 'undefined' ? window : globalThis);
