/* 把單字第一欄的「大寫母音＝重音」換成重音符號（U+0301）：node ru/stress.js
   - кнИга → кни́га；開頭是 ! 的（專有名詞）不轉換，只去掉 !，重音直接用 ́ 寫
   - 轉換過的檔案再跑一次也不會變 */
'use strict';
const fs = require('fs');
const path = require('path');
const V = { А: 'а', Е: 'е', И: 'и', О: 'о', У: 'у', Ы: 'ы', Э: 'э', Ю: 'ю', Я: 'я' };
for (const f of ['data1.js', 'data2.js', 'data3.js', 'data4.js', 'data5.js']) {
  const p = path.join(__dirname, f);
  let n = 0;
  const s = fs.readFileSync(p, 'utf8').replace(/^(\s*\[)'([^']*)'/gm, (m, a, w) => {
    let out;
    if (w.startsWith('!')) out = w.slice(1).replace(/\\u0301/g, '́');
    else out = w.replace(/[АЕИОУЫЭЮЯ]/g, c => V[c] + '́');
    if (out !== w) n++;
    return a + "'" + out + "'";
  });
  fs.writeFileSync(p, s);
  console.log(f, n, '個字加上重音');
}
