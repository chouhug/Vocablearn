/* 俄文頁的設定 */
window.LANGCFG = {
  id: 'ru', name: '俄文', short: '俄', level: 'A1', glyph: 'Я', tts: 'ru-RU',
  tourPron: '33 個字母分成五組，先從長得像英文的認起；點一下可以聽發音、看例字。「規則」整理重音和母音弱化，「練習」有聽音選拼字、看拼字選讀法。',
  tourFill: '重音記號不用打，ё 寫成 е 也算對；沒重音的母音拼錯會提醒你。',
  ttsSample: 'Здравствуйте! Как дела? Спасибо, хорошо.',
  voiceNames: /milena|yuri|katya|irina|pavel|svetlana|dmitry|dariya|tatyana|maxim|ekaterina|mikhail|anna|alena|filipp|zahar|ermil|jane|omazh|madirus/,
  noVoiceHelp: '這台裝置沒有俄文語音。iPhone／iPad：到「設定 → 輔助使用 → 朗讀內容 → 聲音 → 俄文」下載語音。Android：到「文字轉語音」設定下載俄文。',
  persons: ['я', 'ты', 'он/она', 'мы', 'вы', 'они'],
  sayPerson: i => ['я', 'ты', 'он', 'мы', 'вы', 'они'][i],
  impPersons: ['ты', 'вы（您；你們）'],
  pastPersons: ['он（陽性）', 'она（陰性）', 'оно（中性）', 'они（複數）'],
  sayPast: i => ['он', 'она', 'оно', 'они'][i],
  pastLabel: '過去式',
  artLabel: '格與性別',
  accentNote: '，但注意拼寫（沒重音的 о／а、е／и 唸起來一樣）',
  gramPh: '搜尋文法：格、過去式、нравится…',
  posZh: { v1: '動詞（第一變位）', v2: '動詞（第二變位）', 'v-irr': '不規則動詞', part: '語氣詞', pred: '無人稱述語' },
  verbTags: c => [{ v1: '第一變位', v2: '第二變位', 'v-irr': '不規則動詞' }[c.type] || '動詞', c.pf ? '完成體' : '未完成體']
    .concat(c.pair ? [(c.pf ? '未完成體：' : '完成體：') + c.pair] : [], c.refl ? ['-ся 動詞'] : [],
      c.motion ? [c.motion === 'uni' ? '運動動詞（單向）' : '運動動詞（來回、經常）'] : [],
      !c.pf && !c.fut ? ['將來式：буду ' + c.inf] : []),
  ruleShort: { 'r-noun': '名詞', 'r-case': '名詞的格', 'r-adj': '形容詞', 'r-pron': '代名詞', 'r-v1': '第一變位', 'r-v2': '第二變位', 'r-refl': '-ся 動詞', 'r-irr': '不規則動詞', 'r-asp': '完成體', 'r-motion': '運動動詞' },
  letterGroups: [
    { title: '長得像英文，唸法也像（5 個）', from: 0, to: 5 },
    { title: '假朋友：長得像英文，唸法不同（7 個）', from: 5, to: 12 },
    { title: '新的子音（13 個）', from: 12, to: 25 },
    { title: '其他母音（6 個）', from: 25, to: 31 },
    { title: '符號（2 個）', from: 31, to: 33, fo: true }
  ],
  cursiveTitle: '手寫體（俄國人平常寫的字）',
  letterNote: '點字母看發音、例字和手寫體。俄文字母共 33 個。母音 я、е、ё、ю、и 會讓前面的子音變「軟」；重音位置不固定，沒重音的 о 唸成「啊」。單字上的 ´ 是重音記號，平常的文章不寫。'
};
