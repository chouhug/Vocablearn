// 用真的瀏覽器測「電腦版填空直接打字、Enter 下一題」：node n5src/fill-keys-e2e.js n5work [ja it …]
// 電腦（1280px、滑鼠）：進填空就對焦在框框；焦點跑掉時打字會回到框框；答完不管焦點在哪按 Enter 都是下一題；日文聽寫也一樣
// 手機（觸控）：不自動對焦（不會一直跳鍵盤）
// 需要 playwright 和 Chrome（不在 test-all.js 裡）。會在目前的資料夾留下 shot-fill-keys-*.png 截圖
let chromium; try { ({ chromium } = require('playwright')); } catch (e) { ({ chromium } = require('/opt/npm-tools/node_modules/playwright')); }
const http = require('http'), fs = require('fs'), path = require('path');
const ROOT = path.resolve(process.argv[2]);
const LANGS = process.argv.slice(3).length ? process.argv.slice(3) : ['ja', 'it'];
const srv = http.createServer((q, r) => { const f = path.join(ROOT, decodeURIComponent(q.url.split('?')[0])); fs.readFile(f, (e, d) => { if (e) { r.writeHead(404); return r.end(); } r.writeHead(200, { 'content-type': f.endsWith('.html') ? 'text/html; charset=utf-8' : f.endsWith('.js') ? 'text/javascript' : 'application/octet-stream' }); r.end(d); }); });
let bad = 0; const ok = (c, m) => { console.log((c ? '✓ ' : '✗ ') + m); if (!c) bad++; };
(async () => {
  await new Promise(r => srv.listen(0, r)); const base = 'http://127.0.0.1:' + srv.address().port + '/';
  const br = await chromium.launch({ executablePath: process.env.CHROME || (fs.existsSync('/usr/bin/google-chrome') ? '/usr/bin/google-chrome' : undefined), args: ['--no-sandbox'] });
  const init = ([l, pre]) => { if (!localStorage.getItem('langs:last')) { localStorage.setItem('langs:last', JSON.stringify(l)); localStorage.setItem('langs:v1', JSON.stringify({ active: [l], max: 2, lock: true, note: '' })); localStorage.setItem(pre + ':toured', '1'); localStorage.setItem('n5:settings', JSON.stringify({ pop: 'off', vtip: 'off' })); localStorage.setItem(pre + ':ui', JSON.stringify({ tab: 'card', cardSrc: 'new' })); localStorage.setItem(pre + ':pop', JSON.stringify({ n: 0, goal: 99, last: new Date().toLocaleDateString('sv-SE') })); } };
  for (const L of LANGS) {
    console.log('—— ' + L);
    const file = L === 'ja' ? 'index.html' : L + '.html', pre = L === 'ja' ? 'n5' : L;
    const ctx = await br.newContext({ viewport: { width: 1280, height: 900 } }); await ctx.route(/^https:\/\//, r => r.abort());
    await ctx.addInitScript(init, [L, pre]);
    const pg = await ctx.newPage(); const errs = []; pg.on('pageerror', e => errs.push(e.message));
    await pg.goto(base + file); await pg.waitForSelector('#tab-card [data-a="queue"]');
    for (let i = 0; i < 6; i++) { await pg.click('#tab-card [data-a="queue"]'); await pg.waitForTimeout(80); }
    const act = () => pg.evaluate(() => (document.activeElement || {}).id || '');
    const prog = () => pg.evaluate(() => { const i = document.getElementById('fillIn'); return i ? (i.readOnly ? 'done' : 'ask') + ':' + i.value : 'none'; });
    const card = () => pg.evaluate(() => (document.getElementById('fillCard') || {}).textContent || '');
    await pg.click('.tabbar [data-tab="fill"]'); await pg.waitForSelector('#fillIn'); await pg.waitForTimeout(200);
    ok(await act() === 'fillIn', '電腦：一進填空就對焦在框框');
    ok(await pg.evaluate(() => getComputedStyle(document.querySelector('.tabbar')).display !== 'none'), '電腦：對焦時底部分頁還在');
    await pg.keyboard.type('zz'); await pg.keyboard.press('Enter'); await pg.waitForTimeout(250);
    ok((await prog()) === 'done:zz', '直接打字 + Enter：送出答案');
    const first = await card();
    await pg.mouse.click(5, 5); await pg.waitForTimeout(100);   // 點空白處，焦點離開框框
    ok(await act() !== 'fillIn', '（點了空白處，焦點不在框框）');
    await pg.keyboard.press('Enter'); await pg.waitForTimeout(300);
    ok((await prog()) === 'ask:' && await card() !== first && await act() === 'fillIn', '答完後焦點不在框框，按 Enter 也會下一題，而且對焦在新的框框');
    await pg.mouse.click(5, 5); await pg.waitForTimeout(100);
    await pg.keyboard.type('ab');
    ok((await prog()) === 'ask:ab', '焦點跑掉時打字：字會打進框框（' + await prog() + '）');
    await pg.click('#fillShow'); await pg.waitForTimeout(250);
    ok((await prog()).startsWith('done') && await act() === 'fillIn', '按「看答案」後焦點回到框框');
    await pg.screenshot({ path: `shot-fill-keys-${L}.png` });
    await pg.keyboard.press('Enter'); await pg.waitForTimeout(300);
    ok((await prog()) === 'ask:', '看答案後按 Enter：下一題');
    // 選單開著時打字不會被搶走
    await pg.click('#tab-fill .pw:has(#fillSrc)'); await pg.waitForSelector('.pk:not([hidden])'); await pg.keyboard.type('q'); await pg.waitForTimeout(100);
    ok((await prog()) === 'ask:', '來源選單打開時打字：不會打進框框');
    await pg.keyboard.press('Escape'); await pg.waitForTimeout(250);
    if (L === 'ja') {
      await pg.click('[data-fmode="dict"]'); await pg.waitForSelector('#dictPlay'); await pg.waitForTimeout(200);
      ok(await act() === 'fillIn', '日文聽寫：一進來就對焦在框框');
      await pg.keyboard.type('zz'); await pg.keyboard.press('Enter'); await pg.waitForTimeout(250);
      await pg.mouse.click(5, 5); await pg.keyboard.press('Enter'); await pg.waitForTimeout(300);
      ok((await prog()) === 'ask:' && await act() === 'fillIn', '日文聽寫：答完按 Enter 下一題');
      await pg.click('[data-fmode="fill"]'); await pg.waitForTimeout(200);
    }
    ok(!errs.length, '沒有 JS 錯誤' + (errs.length ? '：' + errs.join(' | ') : ''));
    await ctx.close();
    // 手機
    const m = await br.newContext({ viewport: { width: 390, height: 844 }, isMobile: true, hasTouch: true }); await m.route(/^https:\/\//, r => r.abort());
    await m.addInitScript(init, [L, pre]);
    const mp = await m.newPage(); await mp.goto(base + file); await mp.waitForSelector('#tab-card [data-a="queue"]');
    for (let i = 0; i < 3; i++) { await mp.tap('#tab-card [data-a="queue"]'); await mp.waitForTimeout(80); }
    await mp.tap('.tabbar [data-tab="fill"]'); await mp.waitForSelector('#fillIn'); await mp.waitForTimeout(200);
    ok(await mp.evaluate(() => document.activeElement && document.activeElement.id) !== 'fillIn', '手機：進填空不自動對焦（不會跳鍵盤）');
    await m.close();
  }
  await br.close(); srv.close();
  console.log(bad ? `${bad} 項失敗` : '全部通過'); process.exit(bad ? 1 : 0);
})();
