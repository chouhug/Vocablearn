// ===== 語言頁的英文對照（介面共用的部分在 i18n-ui.js；各語言的內容在 <代碼>/i18n.js）=====
// LD：語言頁才有的介面文字（整段中文 → 英文）。LR：含變數的句子（正規表示式），放在共用規則前面先比對。
// I18N.en.content：各語言的內容（文法說明 HTML、練習題、例句翻譯…），英文介面時在建立資料前整段換掉（applyContent）。
(() => {
const E = I18N.en;
E.gloss = E.gloss || {};
// 把語言包（LX）和設定（LANGCFG）裡的中文字串，照 content（整段）或 dict 換成英文。
// 單字的中文意思（第 5 欄）不換：意思用「單字意思」設定決定。
E.applyContent = (IT, LC) => {
  const HAN = /[㐀-鿿]/, C = E.content, D = E.dict, seen = new Set();
  const tr = s => C[s] ?? D[s] ?? (C[s.trim()] != null ? s.replace(s.trim(), C[s.trim()]) : s);
  // [外文, 中文] 這種一對（範例拆解的逐字意思、專有名詞…）先用 gloss（外文＋中文 → English），同一個中文在不同字可以翻得不一樣
  const isPair = a => Array.isArray(a) && a.length === 2 && typeof a[0] === 'string' && typeof a[1] === 'string' && !HAN.test(a[0]) && HAN.test(a[1]);
  const walk = (o, depth) => {
    if (!o || typeof o !== 'object' || seen.has(o) || depth > 12) return;
    seen.add(o);
    if (isPair(o)) { o[1] = E.gloss[o[0] + '\u0001' + o[1]] ?? tr(o[1]); return; }
    for (const k of Object.keys(o)) {
      const v = o[k];
      if (typeof v === 'string') { if (HAN.test(v)) o[k] = tr(v); }
      else if (v && typeof v === 'object') walk(v, depth + 1);
    }
  };
  // 單字表：只換例句的中文（第 8 欄）
  for (const e of IT.W || []) if (typeof e[7] === 'string' && HAN.test(e[7])) e[7] = tr(e[7]);
  seen.add(IT.W);
  for (const k of Object.keys(IT)) { const v = IT[k]; if (k === 'W' || typeof v === 'function') continue; if (typeof v === 'string') { if (HAN.test(v)) IT[k] = tr(v); } else walk(v, 0); }
  if (LC) for (const k of Object.keys(LC)) { const v = LC[k]; if (k === 'id' || k === 'name') continue; if (typeof v === 'string') { if (HAN.test(v)) LC[k] = tr(v); } else walk(v, 0); }
  if (LC && E.langName && E.langName[LC.id]) E.title = `${E.langName[LC.id]} ${LC.level} · Vocablearn`;
};
E.langName = { ja: 'Japanese', it: 'Italian', es: 'Spanish', de: 'German', ru: 'Russian', en: 'English' };
const LD = {
// ---- 語言名稱、詞性、性別 ----
'日語': 'Japanese', '義大利文': 'Italian', '西班牙文': 'Spanish', '德文': 'German', '俄文': 'Russian', '英文': 'English',
'名詞': 'Noun', '形容詞': 'Adjective', '副詞': 'Adverb', '介係詞': 'Preposition', '冠詞': 'Article', '代名詞': 'Pronoun', '連接詞': 'Conjunction',
'數字': 'Number', '限定詞': 'Determiner', '疑問詞': 'Question word', '常用語': 'Phrase', '不規則動詞': 'Irregular verb', '我的單字': 'My words',
'動詞 -are': 'Verb -are', '動詞 -ere': 'Verb -ere', '動詞 -ire': 'Verb -ire', '動詞 -ire（-isc-）': 'Verb -ire (-isc-)',
'動詞 -ar': 'Verb -ar', '動詞 -er': 'Verb -er', '動詞 -ir': 'Verb -ir',
'動詞（規則）': 'Verb (regular)', '動詞（強變化）': 'Verb (strong)', '情態動詞': 'Modal verb', '片語動詞': 'Phrasal verb', '片語・搭配': 'Phrase / collocation',
'動詞（第一變位）': 'Verb (1st conjugation)', '動詞（第二變位）': 'Verb (2nd conjugation)', '語氣詞': 'Particle', '無人稱述語': 'Impersonal predicate',
'陽性': 'masculine', '陰性': 'feminine', '中性': 'neuter', '陽': 'm', '陰': 'f', '中': 'n',
'名': 'G', '陽陰': 'mf', '陽陰中': 'mfn',
'名詞・陽': 'Noun · m', '名詞・陰': 'Noun · f', '名詞・中': 'Noun · n', '名詞・複': 'Noun · pl',
'單數': 'Singular', '複數': 'Plural', '複數：': 'Plural: ', '只用複數': 'plural only', '複數（只用複數）': 'Plural (plural only)', '一個': 'One (a/an)', '性別': 'Gender',
'定冠詞': 'Definite article', '不定冠詞': 'Indefinite article', '陽單': 'm. sg.', '陰單': 'f. sg.', '陽複': 'm. pl.', '陰複': 'f. pl.',
'時態': 'Tense', '動詞時態': 'Verb tense', '現在式': 'Present', '過去式': 'Past', '命令式': 'Imperative', '將來式': 'Future', '其他形：': 'Other forms: ',
'放在名詞前面的形：': 'Form before a noun: ', '動詞變化': 'Verb forms', '陽→複數陰': 'm → f. in plural',
'這個動詞通常不用完成式。': 'This verb isn’t usually used in the perfect.', '這個動詞沒有常用的命令式。': 'This verb has no common imperative.',
// ---- 點字查詢的說明（各語言的引擎產生的）----
'原形': 'base form', '單複數同形': 'same in singular and plural', '名詞前的縮短形': 'short form before a noun',
'陽性單數': 'masculine singular', '陰性單數': 'feminine singular', '陽性複數': 'masculine plural', '陰性複數': 'feminine plural', '中性單數': 'neuter singular',
'過去分詞': 'past participle', '過去分詞（陰性）': 'past participle (f.)', '過去分詞（陽性複數）': 'past participle (m. pl.)', '過去分詞（陰性複數）': 'past participle (f. pl.)',
'反身動詞': 'Reflexive verb', '規則動詞': 'Regular verb',
// ---- 上方、分頁、發音 ----
'名詞上的性別標示': 'Gender marks on nouns', '名詞上的性別：開': 'Noun gender: on', '名詞上的性別：關': 'Noun gender: off',
'名詞上方標出性別': 'Showing gender above nouns', '已隱藏性別，點單字可以看詞性': 'Gender hidden — tap a word to see its part of speech',
'發音': 'Sounds', '發音分頁': 'Sound sections', '字母': 'Letters', '規則': 'Rules', '練習': 'Practice', '練習方式': 'Practice type',
'聽音選拼字': 'Listen → spelling', '看拼字選讀法': 'Spelling → sound', '聽發音，選出你聽到的拼法': 'Listen, then pick the spelling you heard',
'字母名稱': 'Letter name', '例字': 'Example word', '詳細': 'Details', '播放': 'Play', '播放例字': 'Play example word', '播放範例': 'Play example', '播放整句': 'Play sentence',
'再聽一次': 'Listen again', '按下按鈕聽發音，再選出意思': 'Tap the button to hear it, then pick the meaning', '播放發音': 'Play sound',
// ---- 查字、單字頁 ----
'查字': 'Look up', '看完整說明': 'See full details', '看完整變化表': 'See full forms', '找不到這個字。': 'Word not found.',
'編輯或刪除這個字': 'Edit or delete this word', '已移回未學': 'Moved back to New', '移回未學': 'Move back to New', '已經會了': 'I know it',
// ---- 單選、填空 ----
'提示：第一個字母是': 'Hint: first letter is', '提示': 'Hint', '收起提示': 'Hide hint', '填入答案': 'Type your answer',
'，但注意重音': ', but watch the accent', '正確寫法：': 'Correct spelling: ', '正確答案：': 'Answer: ',
'這個來源裡沒有動詞。可以換一個題目來源，或先到字卡把動詞列入考題。': 'There are no verbs in this source. Pick another source, or add some verbs to your quiz in Cards first.',
'這一輪完成了': 'Round complete', '再來一輪': 'Another round',
// ---- 文法 ----
'文法關卡': 'Grammar stages', '全部過關了！': 'All stages cleared!', '過關！': 'Passed!', '已過關': 'Passed', '全對，': 'Perfect! ',
'這個文法你會了。': 'You’ve got this grammar point.', '差一點，看一下範例再練一次。': 'Almost — look at the examples and try again.',
'先看範例拆解，再回來試試。': 'Look at the example breakdowns first, then try again.', '再練一次': 'Try again', '看範例': 'Examples', '看範例拆解': 'See example breakdowns',
'文法練習': 'Grammar practice', '文法分頁': 'Grammar sections', '說明': 'Explanation', '練習題': 'Practice', '文法列表': 'Grammar list', '‹ 文法列表': '‹ Grammar list',
'照順序學，後面的文法會用到前面的。每個文法點看完說明和範例，練習題答對八成就過關（6 題要對 5 題）；一關全部過關，下一關就會打開。': 'Learn in order — later points build on earlier ones. Read each point’s explanation and examples; get 80% of the practice right to pass (5 of 6). Clear a whole stage to unlock the next.',
'全部關卡都過了': 'all stages cleared',
'文法排列': 'Grammar view', '關卡（照順序學）': 'Stages (in order)', '分類': 'By topic', '詞性變化規則': 'Word-form rules', '實際變化例子': 'Real examples',
'點一下看完整的變化表。': 'Tap one to see all its forms.', '找不到符合的文法。': 'No matching grammar.', '搜尋文法': 'Search grammar',
'上面是整句，中間每個字下面是它的中文，最後一條一條說明為什麼這樣排。點句子裡的字可以查意思。': 'The whole sentence is on top, each word’s meaning is under it, and the notes explain why it’s put together that way. Tap any word to look it up.',
'白話': 'In plain words', '為什麼：': 'Why: ', '不知道要用哪個？看變化表': 'Not sure which one? See the forms table',
'黃色是這個文法點，點任何一個字可以查意思。': 'This grammar point is highlighted in yellow. Tap any word to look it up.',
'目前的例句裡還沒有用到這個文法。': 'None of the example sentences use this grammar yet.', '出自單字：': 'From the word: ',
// ---- 單字庫、設定 ----
'木琴：字母': 'Xylophone: letters', '字卡、單選、單字庫和點字看意思都會跟著換。': 'Cards, Choice, Words and tap-to-look-up all follow this.',
'切換後會重新載入，所有語言頁一起換。學的語言不變；選 English 時，單字意思、說明和例句翻譯也會換成英文。': 'The page reloads and every language switches together. The language you study stays the same; with English, word meanings, explanations and sentence translations switch to English too.',
'語音只存在這台裝置；速度和日文共用。': 'The voice is saved on this device only; the speed is shared with Japanese.',
'各語言的進度存在同一個帳號裡；備份碼也是同一串，每個語言頁都能匯入。所有設定（外觀、音效、題數、意思、介面語言）各語言共用，在哪一頁改都一樣。': 'All languages’ progress lives in the same account, and the backup code is the same string — import it on any language page. All settings (appearance, sounds, questions per round, meanings, interface language) are shared by every language, whichever page you change them on.',
'每輪題數會套用到發音練習、單選、字卡和填空。「最近學過」一輪會出完範圍內的全部字；錯題複習每輪 10 題，從以前錯過的字輪流抽，抽過的要等其他字都出過才會再出現。': 'Round size applies to sound practice, Choice, Cards and Fill-in. A “Recently learned” round covers every word in the range; mistake review gives 10 per round, rotating through words you got wrong so each comes back only after the others have had a turn.',
'單字或片語': 'Word or phrase', '更多：例句、詞性（可以不填）': 'More: example sentence, part of speech (optional)', '詞性（只用來篩選）': 'Part of speech (for filtering only)',
'單選答錯': 'Choice: wrong', '填空答錯': 'Fill-in: wrong', '單選錯題複習中': 'Choice: reviewing mistakes', '填空錯題複習中': 'Fill-in: reviewing mistakes',
'<p style="padding:16px">這個 App 需要開啟 JavaScript。</p>': '<p style="padding:16px">This app needs JavaScript turned on.</p>',
'重設': 'Reset', '取消': 'Cancel', '震動': 'Vibration', '語音': 'Voice', '倍': '×',
'每個語言的進度會一起存到雲端。': 'Progress for every language is saved to the cloud together.',
'這個 App 需要開啟 JavaScript。': 'This app needs JavaScript turned on.',
// ---- 導覽 ----
'切換語言': 'Switch language', '點左上角的語言名稱可以換到別的語言；也可以鎖定只學其中幾個語言，避免一次學太多。': 'Tap the language name at the top left to switch languages. You can also lock it to just a few languages so you don’t take on too many at once.',
'字母表點一下可以聽發音、看例字；「規則」整理拼字怎麼唸，「練習」有聽音選拼字、看拼字選讀法。': 'Tap a letter to hear it and see an example word. “Rules” explains how spelling is pronounced; “Practice” has listen → spelling and spelling → sound.',
'字卡：挑要學的字': 'Cards: pick words to learn', '新字一張一張看：已經會的按「已經會了」，想練的按「列入考題」，之後單選和填空就會出這些字。': 'Go through new words one card at a time: tap “I know it” for ones you know and “Add to quiz” for ones to practice — Choice and Fill-in will then quiz you on them.',
'看例句打出空格裡的字，答對才算「已學會」，之後照時間排到期複習。': 'Type the missing word in the example sentence. A word only counts as “Learned” once you get it right here; after that it comes back for review on schedule.',
'文法分成好幾關，照順序學：每個文法點有說明、拆開的範例和練習題，答對八成就過關。下面還有詞性變化規則。': 'Grammar is split into stages to learn in order: each point has an explanation, broken-down examples and practice — get 80% right to pass. Word-form rules are further down.',
'單字庫・設定': 'Words & settings', '看進度、搜尋單字、進入錯題和到期複習。下面的「設定」可以調音效、選語音、用 Google 登入同步進度。': 'See your progress, search words, and jump into mistakes and due reviews. “Settings” below lets you adjust sounds, choose a voice and sign in with Google to sync.',
'上方的小按鈕': 'The small buttons on top', '「名」切換名詞上方的性別標示，最右邊切換淺色／深色。': 'The “G” button toggles gender marks above nouns; the one on the far right switches light/dark.',
'最右邊的按鈕切換淺色／深色。': 'The button on the far right switches light/dark.', '小提示': 'Tip',
'例句裡的單字都可以點，會跳出意思和詳細資料。準備好就開始吧！': 'You can tap any word in an example sentence to see its meaning and details. Ready? Let’s start!',
// ---- 語言選單（lang.js）----
'從五十音開始，學 N5 單字和文法': 'Start with kana, then N5 words and grammar', '入門：字母、發音、基本單字和文法': 'Beginner: alphabet, pronunciation, basic words and grammar',
'入門：從西里爾字母開始': 'Beginner: starting with the Cyrillic alphabet', '給已經 B1 的人：B2 單字和片語': 'For B1 learners: B2 words and phrases',
'還沒開始': 'Not started', '語言': 'Languages', '暫停中': 'Paused', '換進來': 'Switch in', '之後會加入': 'Coming later', '準備中': 'In progress',
'鎖定語言': 'Lock languages', '只開放幾個語言，想開新的要先暫停一個': 'Only a few languages are open; pause one to start a new one',
'同時學習': 'Studying at once', '同時學習的語言數': 'Languages at once', '鎖定的理由': 'Why I locked it', '寫一句話提醒自己，想換語言時會先看到它': 'Write a note to yourself — you’ll see it first when you want to switch languages',
'寫下': 'Write', '修改': 'Edit', '開': 'On', '關': 'Off', '儲存': 'Save',
'例如：「先把日文和義大利文學到能用再說」。想換語言時，會先看到這句話。': 'For example: “Get Japanese and Italian to a usable level first.” You’ll see this note first when you want to switch languages.',
'你鎖定時寫下的理由': 'The reason you wrote when locking', '暫停它': 'Pause it', '先不要換': 'Not now',
'你想學哪個語言？': 'Which language do you want to learn?', '先選一個開始。之後隨時可以點左上角的語言名稱換語言，或多加一個一起學。': 'Pick one to start. You can switch any time by tapping the language name at the top left, or add another to study alongside.',
};
const LR = [];
const R = (r, f) => LR.push([r, f]);
const NM = { '日語': 'Japanese', '日文': 'Japanese', '義大利文': 'Italian', '西班牙文': 'Spanish', '德文': 'German', '俄文': 'Russian', '英文': 'English' };
const SH = { '義': 'IT', '西': 'ES', '德': 'DE', '俄': 'RU', '英': 'EN' };
const N = x => NM[x] || x;
const T = x => E.content[x] ?? E.dict[x] ?? x;
const LNS = '(日語|日文|義大利文|西班牙文|德文|俄文|英文)';
const RX = src => new RegExp(src.replace(/LN/g, LNS));
R(/^「(.+)」的一部分$/, 'part of “$1”');
R(/^(現在式|過去式|命令式|將來式|過去分詞|現在分詞|條件式) (.+)$/, (m, a, b) => `${E.dict[a] ?? a} ${b}`);
R(/^原形（不加 (.+)）$/, 'base form (without $1)');
R(/^過去式用 (.+)$/, 'past tense with $1');
R(/^(.+?) 規則動詞$/, '$1 regular verb');
R(/^(義|西|德|俄|英)→中$/, (m, a) => `${SH[a]} → meaning`);
R(/^中→(義|西|德|俄|英)$/, (m, a) => `Meaning → ${SH[a]}`);
R(RX('^歡迎使用LN (\\S+)$'), (m, a, l) => `Welcome to ${N(a)} ${l}`);
R(RX('^從字母和發音開始，學LN (\\S+) 的單字和文法。用 30 秒認識每個分頁。$'), (m, a, l) => `Start with the alphabet and pronunciation, then learn ${N(a)} ${l} words and grammar. Here’s a 30-second tour of each tab.`);
R(RX('^LN發音$'), (m, a) => `${N(a)} pronunciation`);
R(RX('^LN語音（這台裝置）$'), (m, a) => `${N(a)} voice (this device)`);
R(RX('^還沒有讀到LN語音，系統會用預設聲音。$'), (m, a) => `No ${N(a)} voice found yet; the system default will be used.`);
R(RX('^搜尋：LN、中文或英文$'), (m, a) => `Search: ${N(a)}, Chinese or English`);
R(RX('^輸入LN$'), (m, a) => `Type in ${N(a)}`);
R(RX('^清除LN的學習紀錄$'), (m, a) => `Clear ${N(a)} progress`);
R(RX('^清除LN紀錄$'), (m, a) => `Clear ${N(a)} progress`);
R(RX('^只清LN，其他語言的進度不會動。自己新增的單字會留著。$'), (m, a) => `Only ${N(a)} is cleared; other languages aren’t touched. Words you added yourself are kept.`);
R(RX('^確定要清除LN的所有學習紀錄嗎？這個動作不能復原，可以先「匯出進度」備份。其他語言的進度不會動。$'), (m, a) => `Clear all ${N(a)} progress? This can’t be undone — you can “Export progress” first as a backup. Other languages aren’t affected.`);
R(RX('^已清除LN的紀錄$'), (m, a) => `${N(a)} progress cleared`);
R(RX('^這裡只匯入LN；其他語言請在各自的頁面匯入同一串碼。$'), (m, a) => `Only ${N(a)} is imported here; import the same code on each language’s page for the others.`);
R(RX('^已匯入 (\\d+) 筆LN紀錄$'), (m, n, a) => `Imported ${n} ${N(a)} records`);
R(RX('^LN已學會 (.+)$'), (m, a, x) => `${N(a)} learned ${x}`);
R(RX('^目前是LN，點一下切換語言$'), (m, a) => `Current: ${N(a)} — tap to switch language`);
R(RX('^換成LN$'), (m, a) => `Switch to ${N(a)}`);
R(RX('^要開始學LN，得先暫停一個語言。暫停的語言進度都會保留。$'), (m, a) => `To start ${N(a)}, pause one language first. Paused languages keep their progress.`);
R(RX('^已暫停LN$'), (m, a) => `${N(a)} paused`);
R(/^已暫停：(.+)$/, (m, a) => 'Paused: ' + a.split('、').map(N).join(', '));
R(RX('^回到LN$'), (m, a) => `Back to ${N(a)}`);
R(RX('^(.+)（LN）$'), (m, a, b) => `${T(a)} (${N(b)})`);
R(/^學習中（最多 (\d+) 個）$/, 'Studying (up to $1)');
R(/^(\d+) 個$/, '$1');
R(/^已學會 (.+)・(\d+)／(\d+) 字$/, 'Learned $1 · $2/$3 words');
R(/^共 (\d+) 字，包含所有語言。$/, '$1 characters, covering every language.');
R(/^第 (\d+) 關・(.+)$/, (m, n, x) => `Stage ${n} · ${T(x)}`);
R(/^繼續學：(.+)$/, (m, x) => `Continue: ${T(x)}`);
R(/^下一個：(.+)$/, (m, x) => `Next: ${T(x)}`);
R(/^已過關 (\d+) \/ (\d+)$/, 'Passed $1 / $2');
R(/^完成上一關就會打開・先偷看這關的 (\d+) 個文法$/, 'Opens when you finish the previous stage · peek at its $1 grammar points');
R(/^練習題答對 (\d+) 題就過關$/, 'Get $1 right to pass');
R(/^答對 (\d+) 題才算過關。$/, 'You need $1 right to pass. ');
R(/^第 (\d+) 關完成！第 (\d+) 關打開了$/, 'Stage $1 complete! Stage $2 is open');
R(/^第 (\d+) 關完成！全部關卡都過了$/, 'Stage $1 complete! All stages cleared');
R(/^文法練習 (\d+) \/ (\d+)$/, 'Grammar practice $1 / $2');
R(/^看懂了，來練習（(\d+) 題）$/, 'Got it — practice ($1)');
R(/^範例 (\d+)$/, 'Example $1');
R(/^App 裡的字（(\d+)）$/, 'Words in the app ($1)');
R(/^App 裡用到的例句（(\d+)）$/, 'Example sentences in the app ($1)');
R(/^(\d+) 個字$/, (m, n) => n + (n === '1' ? ' word' : ' words'));
R(/^看「(.+)」的詞性和變化$/, 'See part of speech and forms of “$1”');
R(/^播放 (.+)$/, 'Play $1');
R(/^(.+)，字母名稱 (.+)$/, '$1, letter name $2');
R(/^字母名稱：$/, 'Letter name: ');
R(/^(.+)，例字 (.+)$/, '$1, example word $2');
R(/^畫線的「(.+)」怎麼唸？$/, 'How is the underlined “$1” pronounced?');
R(/^，共 (\d+) 個字母$/, (m, n) => `, ${n} letters`);
R(/^，共 (\d+) 個字母（(\d+) 個字）$/, (m, n, k) => `, ${n} letters (${k} words)`);
R(/^（(\d+) 個字）$/, ' ($1 words)');
R(/^答對 (\d+) \/ (\d+) 題$/, '$1 / $2 correct');
R(/^(\d+\/\d+) · 第\s?(\d+)級$/, '$1 · level $2');
R(/^下次複習：(\S+)（第 (\d+) 級）$/, 'Next review: $1 (level $2)');
R(/^已標記為學會，(\d+) 天後會再考一次$/, 'Marked as learned — it comes back in $1 days');
R(/^(.+) · 單字$/, (m, a) => `${E.dict[a] ?? T(a)} · Word`);
R(/^(.+) 是「(.+)」，意思很接近，但這題要的是另一個字，再想想看。$/, '$1 means “$2” — close, but this one wants a different word. Try again.');
R(/^（你寫的是 (.+)）$/, ' (you wrote $1)');
R(/^例句裡找不到「(.+)」。如果這個字在例句裡有變化，請在「例句裡的寫法」填上例句裡的樣子。$/, '“$1” isn’t in the sentence. If it changes form there, enter that form in “Form used in the sentence”.');
R(/^今天的 (\d+) 題完成了！$/, 'Today’s $1 done!');
R(/^填空的提示（第一個字母、字母數）$/, 'Fill-in hints (first letter, letter count)');
R(/^搜尋文法：(.+)$/, 'Search grammar…');

Object.assign(E.dict, LD);
E.re.unshift(...LR);
})();
