// 模擬 Firestore，測 sync.js：node n5src/sync-test.js n5work/sync.js
const fs=require('fs'); global.window=global; global.document={querySelector:()=>null,readyState:'complete'}; global.localStorage={getItem:()=>null,setItem(){}};
eval(fs.readFileSync(process.argv[2],'utf8'));
const tick=()=>new Promise(r=>setTimeout(r,5));
const clone=o=>o===undefined?undefined:JSON.parse(JSON.stringify(o));
class FieldPath{constructor(...s){this.s=s}}
const DEL={__del:1};
function makeDB(opts={}){
  const docs={}; const subs=[]; let writes=0, bytes=0;
  const notify=()=>{ for(const s of subs) s(); };
  const docRef=path=>({path,
    collection:n=>colRef(path+'/'+n),
    onSnapshot(cb,err){ if(opts.denySub&&path.split('/').length>2){setTimeout(()=>err({code:'permission-denied'}));return()=>{};} let last='INIT'; const f=()=>{const j=JSON.stringify(docs[path]); if(j===last)return; last=j; const d=clone(docs[path]); setTimeout(()=>cb({exists:!!d,data:()=>d}));}; subs.push(f); f(); return()=>{subs.splice(subs.indexOf(f),1)}; },
    async get(){const d=clone(docs[path]);return{exists:!!d,data:()=>d}},
    async set(v,o){ apply(path,v,o); writes++; bytes+=JSON.stringify(v).length; notify(); }
  });
  const colRef=path=>({doc:id=>docRef(path+'/'+id),
    onSnapshot(cb,err){ if(opts.denySub){setTimeout(()=>err({code:'permission-denied'}));return()=>{};} const seen={}; const f=()=>{const ch=[]; for(const k of Object.keys(docs)) if(k.startsWith(path+'/')&&k.split('/').length===path.split('/').length+1){const j=JSON.stringify(docs[k]); if(seen[k]!==j){seen[k]=j; const d=clone(docs[k]); ch.push({type:'modified',doc:{id:k.split('/').pop(),data:()=>d}});}} if(ch.length||!f.once){f.once=1; setTimeout(()=>cb({docChanges:()=>ch}));}}; subs.push(f); f(); return()=>{subs.splice(subs.indexOf(f),1)}; }});
  function apply(path,v,o){
    if(opts.denySub&&path.split('/').length>2) throw {code:'permission-denied'};
    if(!o){docs[path]=clone(v);return}
    const d=docs[path]||(docs[path]={});
    for(const f of o.mergeFields){ const segs=f instanceof FieldPath?f.s:[f]; let src=v; for(const s of segs) src=src[s]; let tgt=d; for(const s of segs.slice(0,-1)) tgt=tgt[s]||(tgt[s]={}); const last=segs[segs.length-1]; if(src===DEL) delete tgt[last]; else tgt[last]=clone(src); }
  }
  const db={docs, stats:()=>({writes,bytes}), collection:n=>({doc:id=>docRef(n+'/'+id)}),
    batch(){const ops=[];return{set(r,v,o){ops.push([r.path,v,o])},async commit(){for(const[p,v,o] of ops)apply(p,v,o); writes++; bytes+=JSON.stringify(ops.map(x=>x[1])).length; notify();}}}};
  return db;
}
function client(db, S){
  const st={S, saved:0};
  global.firebase={apps:[1],initializeApp(){},auth:()=>({getRedirectResult:async()=>{},onAuthStateChanged(cb){setTimeout(()=>cb({uid:'U',email:'a@b'}))}}),firestore:Object.assign(()=>db,{FieldPath,FieldValue:{delete:()=>DEL}})};
  global.N5_FIREBASE={};
  const merge=(a,b)=>{const out={items:{},days:{}};const ia=a.items||{},ib=b.items||{};for(const id of new Set([...Object.keys(ia),...Object.keys(ib)])){const x=ia[id],y=ib[id];out.items[id]=!x?y:!y?x:((y.t||0)>(x.t||0)?y:x)}return SyncDays.merge(out,a,b)};
  st.C=makeCloud({getS:()=>st.S,setS:v=>{st.S=v},saveLocal:()=>st.saved++,merge,refresh(){},toast(){} });
  st.C.init(); return st;
}
const rec=(t,extra={})=>Object.assign({s:'learned',n:5,w:{mc:2},lv:3,due:'2026-12-01',st:1,t},extra);
let fail=0; const ok=(c,m)=>{console.log((c?'ok  ':'FAIL')+' '+m); if(!c)fail++};
const settle=async C=>{for(let i=0;i<60;i++){await tick(); await C.upload(); }};
(async()=>{
  // 1. 舊格式文件 → 新版搬家
  let db=makeDB();
  db.docs['users/U']={items:{'あ':rec(100),'it:casa':rec(100),'ru:дом':rec(100)},days:{'2026-11-06':10},v:1};
  const A=client(db,{items:{'it:casa':rec(200,{w:{}}),'de:Haus':rec(150)},days:{'2026-11-07':5}});
  await settle(A.C);
  const sub=Object.keys(db.docs).filter(k=>k.startsWith('users/U/p/')).sort();
  ok(!('items' in db.docs['users/U']),'舊的 users/U.items 已刪掉');
  ok(sub.every(k=>/^users\/U\/p\/(ja|it|ru|de|es|en)-[0-3]$/.test(k)),'分成語言文件：'+sub.map(k=>k.split('/').pop()).join(','));
  const all={}; for(const k of sub) Object.assign(all,db.docs[k].items);
  ok(Object.keys(all).sort().join()===['あ','de:Haus','it:casa','ru:дом'].sort().join(),'四個字都在雲端');
  ok(all['it:casa'].t===200&&JSON.stringify(all['it:casa'].w)==='{}','新的紀錄整筆蓋掉舊的（w 沒殘留）');
  ok(db.docs['users/U'].days['2026-11-06']===10&&db.docs['users/U'].days['2026-11-07']===5&&db.docs['users/U'].v===2,'每日題數合併、v=2');
  ok(Object.keys(A.S.items).length===4,'本機也收到雲端的字');
  // 2. 第二台裝置
  const B=client(db,{items:{},days:{}}); await settle(B.C);
  ok(Object.keys(B.S.items).length===4&&B.S.days['2026-11-06']===10,'第二台裝置拿到全部');
  // 3. B 答一題 → 只寫一筆；A 收到
  const before=db.stats().bytes;
  B.S.items['ru:дом']=rec(300,{lv:4}); B.C.schedule(1); await settle(B.C); await settle(A.C);
  ok(A.S.items['ru:дом'].t===300,'A 收到 B 的新紀錄');
  ok(db.stats().bytes-before<600,'只上傳改到的字（'+(db.stats().bytes-before)+' bytes）');
  // 4. 舊版頁面又整份寫回 users/U
  await db.collection('users').doc('U').set({items:{'あ':rec(50),'es:hola':rec(400)},days:{'2026-11-07':6},v:1,updated:1});
  await settle(A.C);
  ok(!('items' in db.docs['users/U']),'舊頁寫回的 items 又搬走');
  const all2={}; for(const k of Object.keys(db.docs).filter(k=>k.startsWith('users/U/p/'))) Object.assign(all2,db.docs[k].items);
  ok(all2['es:hola']&&all2['es:hola'].t===400&&all2['あ'].t===100,'新字搬進去、舊的時間沒蓋掉新的');
  ok(A.S.days['2026-11-07']===6,'題數取較大值');
  // 5. 規則不允許子集合 → 退回舊格式
  const db2=makeDB({denySub:true}); db2.docs['users/U']={items:{'あ':rec(100)},days:{},v:1};
  const D=client(db2,{items:{'it:casa':rec(200)},days:{}}); await settle(D.C);
  ok(D.C.layout==='single'&&db2.docs['users/U'].items['it:casa']&&db2.docs['users/U'].items['あ']&&D.C.state==='synced','規則不允許時退回整份格式，照常同步（state='+D.C.state+'）');
  // 6. 大量資料：文件大小
  const db3=makeDB(); const big={}; for(const l of ['','it:','es:','de:','ru:','en:']) for(let i=0;i<1500;i++) big[l+'w'+i]=rec(1762500000000,{q:1762000000000,rv:{mc:1762500000000},dd:'2026-11-07'});
  const E=client(db3,{items:big,days:{}}); await settle(E.C);
  const sizes=Object.keys(db3.docs).filter(k=>k.includes('/p/')).map(k=>JSON.stringify(db3.docs[k]).length);
  ok(Math.max(...sizes)<300000,'9000 個字時最大的一份約 '+Math.round(Math.max(...sizes)/1024)+' KB（上限 1024 KB）');
  // 7. 兩台裝置同一天都有練：題數相加
  { const db=makeDB(); const T='2026-11-07';
    const P=client(db,{items:{},days:{}}); const Q=client(db,{items:{},days:{}});
    const bumpAs=(c,dev,k)=>{for(let i=0;i<k;i++){const m=(c.S.dv=c.S.dv||{})[T]=(c.S.dv[T]||{}); m[dev]=(m[dev]||0)+1; c.S.days[T]=Math.max((c.S.days[T]||0)+1,Object.values(m).reduce((a,b)=>a+b,0));}};
    await settle(P.C); await settle(Q.C);
    bumpAs(P,'devP',7); P.C.schedule(1); await settle(P.C);
    bumpAs(Q,'devQ',5); Q.C.schedule(1); await settle(Q.C); await settle(P.C);
    ok(P.S.days[T]===12&&Q.S.days[T]===12,'兩台裝置同一天 7＋5 題 → 兩邊都顯示 12（P='+P.S.days[T]+', Q='+Q.S.days[T]+'）');
    ok(db.docs['users/U'].days[T]===12&&db.docs['users/U'].dv[T].devP===7,'雲端 days=12、dv 各記各的');
    bumpAs(P,'devP',1); P.C.schedule(1); await settle(P.C); await settle(Q.C);
    ok(Q.S.days[T]===13,'之後再做一題 → 13'); }
  // 自己新增的單字：定義放在紀錄的 c 欄位，跟著同步；刪除＝沒有 c 的空白紀錄
  B.S.items['en:my:whisker']=rec(400,{s:'queued',c:{w:'whisker',zh:'鬍鬚',p:'n',s:'The cat has long whiskers.',a:'whiskers'}}); B.C.schedule(1); await settle(B.C); await settle(A.C);
  ok(A.S.items['en:my:whisker']&&A.S.items['en:my:whisker'].c.a==='whiskers','自己新增的單字（c 欄位）同步到另一台');
  A.S.items['en:my:whisker']={s:'new',n:0,w:{},lv:0,due:'',st:0,t:500}; A.C.schedule(1); await settle(A.C); await settle(B.C);
  ok(B.S.items['en:my:whisker'].t===500&&!('c' in B.S.items['en:my:whisker']),'刪掉自己的單字，另一台也刪掉（c 沒殘留）');
  { const o=SyncDays.merge({},{days:{'2026-11-06':10}},{days:{'2026-11-06':8}});
    ok(o.days['2026-11-06']===10,'舊資料（沒有 dv）照舊取大的'); }
  { const S={items:{},days:{}}; for(let i=0;i<3;i++) SyncDays.bump(S,'2026-11-07'); ok(S.days['2026-11-07']===3&&S.dv['2026-11-07'][SyncDays.dev]===3,'SyncDays.bump 加在這台裝置'); }
  console.log(fail?fail+' 項失敗':'全部通過'); process.exit(fail?1:0);
})();
