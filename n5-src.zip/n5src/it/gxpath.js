(function (G) { const IT = G.IT || (G.IT = {});
/* 義大利文文法關卡：由淺到深，後面的關卡會用到前面學過的東西 */
IT.GX_PATH = [
  ['開口說', '「我是…」「你好嗎」', ['essere', 'stare']],
  ['冠詞和名詞', '名詞分男女，前面的冠詞和後面的形容詞都要跟著變', ['noun-gender', 'art-indef', 'art-def', 'noun-plural', 'adj']],
  ['「有」和數字', 'avere（有）、c\'è（那裡有）、數字、禮貌地說「我想要」', ['avere', 'numbers', 'avere-expr', 'ce', 'vorrei']],
  ['現在式', '三種規則動詞換字尾就能說「誰做什麼」，再學否定、問句和敬稱「您」', ['pres-are', 'pres-ere', 'pres-ire', 'pres-isc', 'neg', 'questions', 'lei']],
  ['去哪裡', '介係詞、去哪個城市、搭什麼車，常用的不規則動詞', ['prep', 'place', 'artprep', 'pres-irr', 'andare', 'transport', 'freq']],
  ['能、想、知道，我的、這個', '想／能／必須、sapere 和 conoscere、所有格、指示詞、很多', ['modal', 'sapere', 'poss', 'demo', 'molto']],
  ['時間和天氣', '幾點、星期、月份，天氣怎麼說', ['time', 'dates', 'weather']],
  ['喜歡、自己和代名詞', '倒過來說的「喜歡」、反身動詞、受詞代名詞、si', ['piacere', 'refl', 'pron-obj', 'si']],
  ['過去式和命令', '「做了什麼」的兩種助動詞，還有請人做事', ['pp-avere', 'pp-essere', 'imper']],
  ['長句子', '把句子接起來，還有比較', ['conj', 'compar']]
];
})(typeof window !== 'undefined' ? window : globalThis);
