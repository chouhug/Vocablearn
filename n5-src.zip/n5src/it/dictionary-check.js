/* 用公開的 Hunspell it_IT 字典（LibreOffice／wooorm/dictionaries）檢查拼字。
   需要網路安裝：npm i dictionary-it nspell
   執行：node tests/dictionary-check.js
   檢查：單字原形、名詞複數、形容詞四種形、動詞所有變化形、所有例句裡的字 */
'use strict';
const fs = require('fs');
const path = require('path');
const vm = require('vm');

async function main() {
  let nspell, dict;
  try {
    nspell = require('nspell');
    dict = await import('dictionary-it').then(m => m.default || m);
  } catch (e) {
    console.log('找不到 dictionary-it / nspell，請先執行：npm i dictionary-it nspell');
    process.exit(2);
  }
  const d = typeof dict === 'function' ? await new Promise((res, rej) => dict((err, v) => err ? rej(err) : res(v))) : dict;
  const spell = nspell(d);
  const ctx = { console }; ctx.globalThis = ctx; vm.createContext(ctx);
  for (const f of ['engine', 'data1', 'data2', 'data3', 'data4', 'data5']) vm.runInContext(fs.readFileSync(path.join(__dirname, f + '.js'), 'utf8'), ctx);
  const IT = ctx.IT;
  const forms = new Map();
  const add = (w, src) => { if (!w || w === '-') return; w.split(/[\s/]+/).forEach(x => { x = x.replace(/'$/, ''); if (x && /[a-zà-ù]/i.test(x)) forms.set(x, src); }); };
  IT.W.forEach(e => {
    add(e[0], e[0]);
    if (e[1] === 'n') add(e[3], e[0] + ' 複數');
    if (e[1] === 'adj') IT.adjForms(e).forEach(x => add(x, e[0]));
    if (/^v/.test(e[1])) {
      const c = IT.conjugate(e[0], e[1]);
      c.present.concat([c.pp, c.ppForms.fs, c.ppForms.mp, c.ppForms.fp]).concat(c.imperative || []).forEach(x => add(x.replace(/^si /, ''), e[0] + ' 變化'));
    }
    IT.tokenize(e[6]).filter(t => t.w).forEach(t => add(t.t, e[0] + ' 例句'));
  });
  const bad = [];
  for (const [w, src] of forms) if (!spell.correct(w) && !spell.correct(w.toLowerCase()) && !IT.NAMES[w.toLowerCase()]) bad.push(w + '（' + src + '）');
  console.log('檢查 ' + forms.size + ' 個字形，字典裡找不到 ' + bad.length + ' 個：');
  bad.forEach(b => console.log('  ' + b));
}
main();
