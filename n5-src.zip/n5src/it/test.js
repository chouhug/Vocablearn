/* 資料與引擎測試：node tests/run.js */
'use strict';
const fs = require('fs');
const path = require('path');
const vm = require('vm');

const SRC = __dirname;
const ctx = { console };
ctx.globalThis = ctx;
vm.createContext(ctx);
for (const f of ['engine.js', 'data1.js', 'data2.js', 'data3.js', 'data4.js', 'data5.js', 'grammar.js', 'quiz.js', 'gx1.js', 'gx2.js', 'gx3.js', 'gxpath.js']) {
  const p = path.join(SRC, f);
  if (fs.existsSync(p)) vm.runInContext(fs.readFileSync(p, 'utf8'), ctx, { filename: f });
}
const IT = ctx.IT;
const W = IT.W;
let fails = 0, checks = 0;
const failList = [];
function ok(cond, msg) { checks++; if (!cond) { fails++; failList.push(msg); } }
function eq(a, b, msg) { ok(JSON.stringify(a) === JSON.stringify(b), msg + '：預期 ' + JSON.stringify(b) + '，得到 ' + JSON.stringify(a)); }

/* 1. 欄位格式 */
const POS = new Set(['n', 'adj', 'adv', 'prep', 'art', 'pron', 'conj', 'num', 'det', 'q', 'expr', 'v-are', 'v-ere', 'v-ire', 'v-isc', 'v-irr']);
W.forEach((e, i) => {
  ok(Array.isArray(e) && e.length === 9, `第 ${i} 筆欄位數不是 9：${JSON.stringify(e)}`);
  ok(POS.has(e[1]), `${e[0]}：未知詞性 ${e[1]}`);
  if (e[1] === 'n') ok(e[2] === 'm' || e[2] === 'f', `${e[0]}：名詞缺性別`);
  e.forEach((x, j) => ok(typeof x === 'string' && (x.length > 0), `${e[0]}：第 ${j} 欄是空的`));
  ok(/[。！？]$/.test(e[7]), `${e[0]}：例句中文沒有句末標點：${e[7]}`);
  ok(/[.!?]$/.test(e[6].trim()), `${e[0]}：例句沒有句末標點：${e[6]}`);
});
/* 2. 不可重複 */
const keys = new Set();
W.forEach(e => { const k = e[0] + '|' + e[1]; ok(!keys.has(k), `重複的單字：${k}`); keys.add(k); });

/* 3. 例句要對上填空答案，而且答案是該字的變化形 */
const LOOK = IT.buildLookup(W, Object.assign({}, IT.EXTRA_FORMS, IT.EXTRA_LOOKUP));
function words(s) { return IT.tokenize(s).filter(t => t.w).map(t => t.t.toLowerCase()); }
function containsSeq(sent, ans) {
  const a = words(sent), b = words(ans);
  for (let i = 0; i + b.length <= a.length; i++) if (b.every((x, j) => a[i + j] === x)) return true;
  return false;
}
W.forEach(e => {
  const [w, pos, , pl, , , sent, , ans] = e;
  ok(containsSeq(sent, ans), `${w}：例句「${sent}」裡找不到答案「${ans}」`);
  const a = ans.toLowerCase();
  let isForm = false;
  if (a === w.toLowerCase()) isForm = true;
  else if (/ /.test(w) || / /.test(a)) isForm = (pl && pl.toLowerCase() === a);
  else isForm = (LOOK.get(IT.norm(a)) || []).some(x => x.lemma === w);
  ok(isForm, `${w}：答案「${ans}」不是 ${w} 的變化形`);
});

/* 4. 點字查詢沒有漏字 */
const missing = new Map();
W.forEach(e => {
  IT.tokenize(e[6]).filter(t => t.w).forEach(t => {
    const k = IT.norm(t.t).toLowerCase();
    if (!LOOK.has(k) && !IT.NAMES[k]) missing.set(k, (missing.get(k) || []).concat(e[0]));
  });
});
if (IT.GRAMMAR) IT.GRAMMAR.forEach(g => (g.ex || []).forEach(s => IT.tokenize(s[0]).filter(t => t.w).forEach(t => {
  const k = IT.norm(t.t).toLowerCase();
  if (!LOOK.has(k) && !IT.NAMES[k]) missing.set(k, (missing.get(k) || []).concat('文法:' + g.id));
})));
ok(missing.size === 0, '例句中查不到的字：' + [...missing].map(([k, v]) => k + '(' + v.slice(0, 2).join(',') + ')').join('  '));

/* 5. 名詞性別：用詞尾規則檢查，例外要列在白名單 */
const GENDER_EXC = new Set(['mano', 'radio', 'foto', 'moto', 'auto', 'metro', 'problema', 'cinema', 'papà', 'panorama', 'euro', 'ventuno', 'turista']);
W.filter(e => e[1] === 'n' && !/ /.test(e[0])).forEach(e => {
  const [w, , g] = e;
  if (GENDER_EXC.has(w)) return;
  if (/o$/.test(w)) ok(g === 'm', `${w}：-o 結尾名詞通常是陽性，請確認`);
  if (/(zione|sione|tà|tù|ie|i)$/.test(w) && !/(taxi)$/.test(w)) ok(g === 'f' || /i$/.test(w), `${w}：這個詞尾通常是陰性`);
  if (/a$/.test(w)) ok(g === 'f' || /(ma|ta)$/.test(w) && GENDER_EXC.has(w), `${w}：-a 結尾名詞標成陽性，請確認`);
  if (/(ore|ame|ale|ile)$/.test(w) && !['carne', 'febbre'].includes(w)) ok(g === 'm' || ['fame', 'sete', 'luce', 'chiave'].includes(w), `${w}：這個詞尾通常是陽性`);
});
// 已知性別（與 Wiktionary／Treccani 一致的常見陷阱字）
const KNOWN_G = { mano: 'f', radio: 'f', foto: 'f', moto: 'f', auto: 'f', problema: 'm', cinema: 'm', panorama: 'm', fame: 'f', sete: 'f', notte: 'f', chiave: 'f', luce: 'f', carne: 'f', febbre: 'f', fiore: 'm', mare: 'm', pane: 'm', latte: 'm', nome: 'm', ponte: 'm', fiume: 'm', sole: 'm', cuore: 'm', esame: 'm', dente: 'm', piede: 'm', classe: 'f', lezione: 'f', stazione: 'f', canzone: 'f', gente: 'f', estate: 'f', arte: 'f', fine: 'f', parte: 'f', tosse: 'f', moglie: 'f', nave: 'f', neve: 'f', colazione: 'f', televisione: 'f', frase: 'f', madre: 'f', padre: 'm', genitore: 'm', cliente: 'm', orecchio: 'm', uovo: 'm', braccio: 'm', dito: 'm', paio: 'm', città: 'f', università: 'f', età: 'f', metà: 'f', caffè: 'm', tè: 'm', menù: 'm', tiramisù: 'm', bar: 'm', sport: 'm', film: 'm', computer: 'm', autobus: 'm', hotel: 'm', taxi: 'm', email: 'f' };
W.filter(e => e[1] === 'n').forEach(e => { if (KNOWN_G[e[0]]) eq(e[2], KNOWN_G[e[0]], `${e[0]} 的性別`); });

/* 6. 名詞複數：符合規則，不規則的要在白名單 */
const PLURAL_EXC = { uomo: 'uomini', uovo: 'uova', braccio: 'braccia', dito: 'dita', orecchio: 'orecchie', mano: 'mani', paio: 'paia', mille: 'mila', moglie: 'mogli', foto: 'foto', radio: 'radio', moto: 'moto', auto: 'auto', metro: 'metro', euro: 'euro', cinema: 'cinema', problema: 'problemi', panorama: 'panorami', turista: 'turisti', capelli: 'capelli', pantaloni: 'pantaloni', occhiali: 'occhiali', soldi: 'soldi', contanti: 'contanti', ospite: 'ospiti' };
W.filter(e => e[1] === 'n' && !/ /.test(e[0]) && e[3] !== '-').forEach(e => {
  const [w, , g, pl] = e;
  if (PLURAL_EXC[w]) { eq(pl, PLURAL_EXC[w], `${w} 的複數`); return; }
  const pred = IT.predictPlurals(w, g);
  ok(pred.has(pl), `${w}（${g}）的複數「${pl}」不符合規則（預期 ${[...pred].join(' 或 ')}），若是不規則請加入白名單`);
});
// -co / -go 名詞的實際複數（兩種都有可能，所以逐一確認）
const CO_GO = { amico: 'amici', medico: 'medici', cuoco: 'cuochi', parco: 'parchi', lago: 'laghi', albergo: 'alberghi', gioco: 'giochi', succo: 'succhi', bosco: 'boschi', pacco: 'pacchi', casco: 'caschi' };
W.forEach(e => { if (e[1] === 'n' && CO_GO[e[0]]) eq(e[3], CO_GO[e[0]], `${e[0]} 的複數`); });

/* 7. 形容詞四種形 */
W.filter(e => e[1] === 'adj').forEach(e => {
  const f = IT.adjForms(e);
  const preds = IT.predictAdj(e[0]);
  const inv = ['blu', 'rosa', 'viola'];
  if (inv.includes(e[0])) { eq(f, [e[0], e[0], e[0], e[0]], `${e[0]} 不變化`); return; }
  ok(preds.some(p => p[0] === f[1] && p[1] === f[2] && p[2] === f[3]), `${e[0]} 的變化 ${f.join('/')} 不符合規則`);
});
const ADJ_REF = { bianco: ['bianco', 'bianca', 'bianchi', 'bianche'], simpatico: ['simpatico', 'simpatica', 'simpatici', 'simpatiche'], tedesco: ['tedesco', 'tedesca', 'tedeschi', 'tedesche'], lungo: ['lungo', 'lunga', 'lunghi', 'lunghe'], vecchio: ['vecchio', 'vecchia', 'vecchi', 'vecchie'], grigio: ['grigio', 'grigia', 'grigi', 'grigie'], economico: ['economico', 'economica', 'economici', 'economiche'], stanco: ['stanco', 'stanca', 'stanchi', 'stanche'], ricco: ['ricco', 'ricca', 'ricchi', 'ricche'], antico: ['antico', 'antica', 'antichi', 'antiche'], sporco: ['sporco', 'sporca', 'sporchi', 'sporche'], fresco: ['fresco', 'fresca', 'freschi', 'fresche'], grande: ['grande', 'grande', 'grandi', 'grandi'], obbligatorio: ['obbligatorio', 'obbligatoria', 'obbligatori', 'obbligatorie'] };
W.forEach(e => { if (e[1] === 'adj' && ADJ_REF[e[0]]) eq(IT.adjForms(e), ADJ_REF[e[0]], `${e[0]} 的形容詞變化`); });

/* 8. 冠詞 */
const ART_CASES = [['libro', 'm', 'il libro', 'i libri', 'un'], ['studente', 'm', 'lo studente', 'gli studenti', 'uno'], ['zaino', 'm', 'lo zaino', 'gli zaini', 'uno'], ['amico', 'm', "l'amico", 'gli amici', 'un'], ['amica', 'f', "l'amica", 'le amiche', "un'"], ['casa', 'f', 'la casa', 'le case', 'una'], ['uomo', 'm', "l'uomo", 'gli uomini', 'un'], ['psicologo', 'm', 'lo psicologo', 'gli psicologi', 'uno'], ['yogurt', 'm', 'lo yogurt', 'gli yogurt', 'uno'], ['gnocco', 'm', 'lo gnocco', 'gli gnocchi', 'uno'], ['hotel', 'm', "l'hotel", 'gli hotel', 'un'], ['sport', 'm', 'lo sport', 'gli sport', 'uno'], ['scuola', 'f', 'la scuola', 'le scuole', 'una'], ['zia', 'f', 'la zia', 'le zie', 'una'], ['isola', 'f', "l'isola", 'le isole', "un'"]];
const plMap = { libro: 'libri', studente: 'studenti', zaino: 'zaini', amico: 'amici', amica: 'amiche', casa: 'case', uomo: 'uomini', psicologo: 'psicologi', yogurt: 'yogurt', gnocco: 'gnocchi', hotel: 'hotel', sport: 'sport', scuola: 'scuole', zia: 'zie', isola: 'isole' };
ART_CASES.forEach(([w, g, s, p, ind]) => {
  eq(IT.withArt(w, g, false), s, `${w} 的單數冠詞`);
  eq(IT.withArt(plMap[w], g, true), p, `${w} 的複數冠詞`);
  eq(IT.indefArt(w, g), ind, `${w} 的不定冠詞`);
});
eq(['del', 'dello', "dell'", 'della', 'dei', 'degli', 'delle'].map(x => IT.ART_PREPS[x] && IT.ART_PREPS[x].prep), ['di', 'di', 'di', 'di', 'di', 'di', 'di'], 'di 的合併形');
eq(IT.artPrep('in', 'il') + ' ' + IT.artPrep('in', 'gli') + ' ' + IT.artPrep('su', 'la') + ' ' + IT.artPrep('a', "l'") + ' ' + IT.artPrep('da', 'i'), "nel negli sulla all' dai", '介係詞合併形');

/* 9. 動詞變化（逐字寫出的參考表） */
const REF = {
  parlare: ['parlo parli parla parliamo parlate parlano', 'parlato', 'a', "parla|parli|parliamo|parlate"],
  cercare: ['cerco cerchi cerca cerchiamo cercate cercano', 'cercato', 'a', 'cerca|cerchi|cerchiamo|cercate'],
  pagare: ['pago paghi paga paghiamo pagate pagano', 'pagato', 'a', 'paga|paghi|paghiamo|pagate'],
  mangiare: ['mangio mangi mangia mangiamo mangiate mangiano', 'mangiato', 'a', 'mangia|mangi|mangiamo|mangiate'],
  studiare: ['studio studi studia studiamo studiate studiano', 'studiato', 'a', 'studia|studi|studiamo|studiate'],
  cominciare: ['comincio cominci comincia cominciamo cominciate cominciano', 'cominciato', 'a', 'comincia|cominci|cominciamo|cominciate'],
  viaggiare: ['viaggio viaggi viaggia viaggiamo viaggiate viaggiano', 'viaggiato', 'a', 'viaggia|viaggi|viaggiamo|viaggiate'],
  giocare: ['gioco giochi gioca giochiamo giocate giocano', 'giocato', 'a', 'gioca|giochi|giochiamo|giocate'],
  arrivare: ['arrivo arrivi arriva arriviamo arrivate arrivano', 'arrivato', 'e', 'arriva|arrivi|arriviamo|arrivate'],
  leggere: ['leggo leggi legge leggiamo leggete leggono', 'letto', 'a', 'leggi|legga|leggiamo|leggete'],
  prendere: ['prendo prendi prende prendiamo prendete prendono', 'preso', 'a', 'prendi|prenda|prendiamo|prendete'],
  conoscere: ['conosco conosci conosce conosciamo conoscete conoscono', 'conosciuto', 'a', 'conosci|conosca|conosciamo|conoscete'],
  vedere: ['vedo vedi vede vediamo vedete vedono', 'visto', 'a', 'vedi|veda|vediamo|vedete'],
  scendere: ['scendo scendi scende scendiamo scendete scendono', 'sceso', 'e', 'scendi|scenda|scendiamo|scendete'],
  nascere: ['nasco nasci nasce nasciamo nascete nascono', 'nato', 'e', 'nasci|nasca|nasciamo|nascete'],
  dormire: ['dormo dormi dorme dormiamo dormite dormono', 'dormito', 'a', 'dormi|dorma|dormiamo|dormite'],
  partire: ['parto parti parte partiamo partite partono', 'partito', 'e', 'parti|parta|partiamo|partite'],
  aprire: ['apro apri apre apriamo aprite aprono', 'aperto', 'a', 'apri|apra|apriamo|aprite'],
  offrire: ['offro offri offre offriamo offrite offrono', 'offerto', 'a', 'offri|offra|offriamo|offrite'],
  capire: ['capisco capisci capisce capiamo capite capiscono', 'capito', 'a', 'capisci|capisca|capiamo|capite'],
  finire: ['finisco finisci finisce finiamo finite finiscono', 'finito', 'a', 'finisci|finisca|finiamo|finite'],
  preferire: ['preferisco preferisci preferisce preferiamo preferite preferiscono', 'preferito', 'a', 'preferisci|preferisca|preferiamo|preferite'],
  essere: ['sono sei è siamo siete sono', 'stato', 'e', 'sii|sia|siamo|siate'],
  avere: ['ho hai ha abbiamo avete hanno', 'avuto', 'a', 'abbi|abbia|abbiamo|abbiate'],
  andare: ['vado vai va andiamo andate vanno', 'andato', 'e', "va'/vai|vada|andiamo|andate"],
  fare: ['faccio fai fa facciamo fate fanno', 'fatto', 'a', "fa'/fai|faccia|facciamo|fate"],
  venire: ['vengo vieni viene veniamo venite vengono', 'venuto', 'e', 'vieni|venga|veniamo|venite'],
  dire: ['dico dici dice diciamo dite dicono', 'detto', 'a', "di'|dica|diciamo|dite"],
  potere: ['posso puoi può possiamo potete possono', 'potuto', 'a', ''],
  volere: ['voglio vuoi vuole vogliamo volete vogliono', 'voluto', 'a', ''],
  dovere: ['devo devi deve dobbiamo dovete devono', 'dovuto', 'a', ''],
  uscire: ['esco esci esce usciamo uscite escono', 'uscito', 'e', 'esci|esca|usciamo|uscite'],
  bere: ['bevo bevi beve beviamo bevete bevono', 'bevuto', 'a', 'bevi|beva|beviamo|bevete'],
  sapere: ['so sai sa sappiamo sapete sanno', 'saputo', 'a', 'sappi|sappia|sappiamo|sappiate'],
  rimanere: ['rimango rimani rimane rimaniamo rimanete rimangono', 'rimasto', 'e', 'rimani|rimanga|rimaniamo|rimanete'],
  spegnere: ['spengo spegni spegne spegniamo spegnete spengono', 'spento', 'a', 'spegni|spenga|spegniamo|spegnete'],
  scegliere: ['scelgo scegli sceglie scegliamo scegliete scelgono', 'scelto', 'a', 'scegli|scelga|scegliamo|scegliete'],
  piacere: ['piaccio piaci piace piacciamo piacete piacciono', 'piaciuto', 'e', ''],
  chiamarsi: ['chiamo chiami chiama chiamiamo chiamate chiamano', 'chiamato', 'e', 'chiamati|si chiami|chiamiamoci|chiamatevi'],
  alzarsi: ['alzo alzi alza alziamo alzate alzano', 'alzato', 'e', 'alzati|si alzi|alziamoci|alzatevi'],
  svegliarsi: ['sveglio svegli sveglia svegliamo svegliate svegliano', 'svegliato', 'e', 'svegliati|si svegli|svegliamoci|svegliatevi'],
  vestirsi: ['vesto vesti veste vestiamo vestite vestono', 'vestito', 'e', 'vestiti|si vesta|vestiamoci|vestitevi'],
  mettersi: ['metto metti mette mettiamo mettete mettono', 'messo', 'e', 'mettiti|si metta|mettiamoci|mettetevi'],
  sedersi: ['siedo siedi siede sediamo sedete siedono', 'seduto', 'e', 'siediti|si sieda|sediamoci|sedetevi'],
  rompere: ['rompo rompi rompe rompiamo rompete rompono', 'rotto', 'a', 'rompi|rompa|rompiamo|rompete'],
  chiudere: ['chiudo chiudi chiude chiudiamo chiudete chiudono', 'chiuso', 'a', 'chiudi|chiuda|chiudiamo|chiudete'],
  scrivere: ['scrivo scrivi scrive scriviamo scrivete scrivono', 'scritto', 'a', 'scrivi|scriva|scriviamo|scrivete'],
  spiegare: ['spiego spieghi spiega spieghiamo spiegate spiegano', 'spiegato', 'a', 'spiega|spieghi|spieghiamo|spiegate'],
  dimenticare: ['dimentico dimentichi dimentica dimentichiamo dimenticate dimenticano', 'dimenticato', 'a', 'dimentica|dimentichi|dimentichiamo|dimenticate'],
  tradurre: ['traduco traduci traduce traduciamo traducete traducono', 'tradotto', 'a', 'traduci|traduca|traduciamo|traducete'],
  salire: ['salgo sali sale saliamo salite salgono', 'salito', 'e', 'sali|salga|saliamo|salite'],
  tenere: ['tengo tieni tiene teniamo tenete tengono', 'tenuto', 'a', 'tieni|tenga|teniamo|tenete'],
  stare: ['sto stai sta stiamo state stanno', 'stato', 'e', "sta'/stai|stia|stiamo|state"],
  dare: ['do dai dà diamo date danno', 'dato', 'a', "da'/dai|dia|diamo|date"]
};
const typeOf = {}; W.forEach(e => { if (/^v/.test(e[1])) typeOf[e[0]] = e[1]; });
for (const v of Object.keys(REF)) {
  ok(!!typeOf[v], `參考表的動詞 ${v} 不在單字資料裡`);
  if (!typeOf[v]) continue;
  const c = IT.conjugate(v, typeOf[v]);
  const [pres, pp, aux, imp] = REF[v];
  eq(c.present.join(' '), pres, `${v} 現在式`);
  eq(c.pp, pp, `${v} 過去分詞`);
  eq(c.aux, aux, `${v} 助動詞`);
  eq(c.imperative ? c.imperative.join('|') : '', imp, `${v} 命令式`);
}
// 每個動詞都能產生完整變化表，而且沒有怪字（例如 -ii-、-hia-）
W.filter(e => /^v/.test(e[1])).forEach(e => {
  const c = IT.conjugate(e[0], e[1]);
  ok(c.present.length === 6 && c.present.every(x => /^[a-zàèéìòù]+$/.test(x)), `${e[0]} 現在式不完整：${c.present}`);
  ok(c.present.every(x => !/ii|[cg]h[aou]/.test(x)), `${e[0]} 現在式拼字可疑：${c.present.join(' ')}`);
  ok(/(ato|uto|ito|so|to|sto)$/.test(c.pp), `${e[0]} 過去分詞可疑：${c.pp}`);
  ok(c.passato.length === 6, `${e[0]} 過去式不完整`);
});
eq(IT.conjugate('andare', 'v-irr').passato[0], 'sono andato/andata', 'andare 過去式 io');
eq(IT.conjugate('alzarsi', 'v-are').passato[3], 'ci siamo alzati/alzate', 'alzarsi 過去式 noi');
eq(IT.conjugate('mangiare', 'v-are').passato[5], 'hanno mangiato', 'mangiare 過去式 loro');

/* 10. 答案比對 */
eq(IT.checkAnswer('Parlo', 'parlo'), 'ok', '大小寫');
eq(IT.checkAnswer('citta', 'città'), 'accent', '缺重音');
eq(IT.checkAnswer("citta'", 'città'), 'accent', '用撇號代替重音');
eq(IT.checkAnswer('caffe', 'caffè'), 'accent', '缺重音 2');
eq(IT.checkAnswer('parla', 'parlo'), 'wrong', '答錯');
eq(IT.checkAnswer('  per   favore ', 'per favore'), 'ok', '多餘空白');

/* 11. 文法點都有例句 */
if (IT.GRAMMAR) {
  const all = W.map(e => e[6]);
  IT.GRAMMAR.forEach(g => {
    const n = all.filter(s => IT.grammarMatch(g, s).length).length + (g.ex || []).length;
    ok(n >= 2, `文法點「${g.title}」只找到 ${n} 個例句`);
    (g.ex || []).forEach(x => ok(IT.grammarMatch(g, x[0]).length > 0, `文法點「${g.title}」的範例句沒有被標出：${x[0]}`));
  });
}

/* 12. 冠詞與介係詞題可以產生，而且干擾選項都是錯的 */
if (IT.makeArtQuestion) {
  let made = 0;
  W.forEach(e => {
    const q = IT.makeArtQuestion(e, LOOK, () => 0.42);
    if (!q) return;
    made++;
    ok(q.options.includes(q.answer) && new Set(q.options).size === q.options.length, `${e[0]}：冠詞題選項有問題 ${q.options}`);
    q.options.filter(o => o !== q.answer).forEach(o => ok(IT.artWrong(q, o), `${e[0]}：干擾選項「${o}」可能也對`));
  });
  ok(made > 150, `冠詞與介係詞題太少：${made}`);
}

/* 13. 動詞變化題：選項不重複、只有一個正確 */
{
  let seed = 7; const rnd = () => ((seed = (seed * 9301 + 49297) % 233280) / 233280);
  W.filter(e => /^v/.test(e[1])).forEach(e => {
    for (let k = 0; k < 6; k++) {
      const q = IT.makeVerbQuestion(e, rnd);
      ok(new Set(q.options).size === q.options.length && q.options.filter(o => o === q.answer).length === 1, `${e[0]}：動詞題選項重複 ${q.options}`);
      ok(q.options.length >= 3, `${e[0]}：動詞題選項太少 ${q.options}`);
    }
  });
}
/* 14. 介係詞練習句與發音資料 */
IT.PREP_DRILLS.forEach(d => {
  ok(d[0].includes('___') && !d[2].includes(d[1]) && d[2].length === 3, `介係詞練習格式錯誤：${d[0]}`);
  IT.tokenize(d[0].replace('___', d[1])).filter(t => t.w).forEach(t => { const k = IT.norm(t.t).toLowerCase(); ok(LOOK.has(k) || IT.NAMES[k], `介係詞練習句查不到「${t.t}」`); });
});
eq(IT.ALPHABET.length, 26, '字母數（21＋5）');
IT.READ_ITEMS.forEach(r => ok(new Set(r.opts).size === r.opts.length, `讀法題選項重複：${r.w}`));

/* 結果 */
const nouns = W.filter(e => e[1] === 'n').length, verbs = W.filter(e => /^v/.test(e[1])).length;
/* 文法關卡：每個文法點剛好出現一次 */
const pathIds = (IT.GX_PATH || []).flatMap(x => x[2]);
eq(pathIds.slice().sort(), IT.GRAMMAR.map(g => g.id).sort(), '文法關卡要剛好包含所有文法點');
/* 文法練習題（IT.GX） */
const GX = IT.GX || {};
IT.GRAMMAR.forEach(g => ok(GX[g.id], `文法 ${g.id} 沒有練習題`));
Object.entries(GX).forEach(([id, x]) => {
  ok(IT.GRAMMAR.some(g => g.id === id), `GX ${id} 不在 GRAMMAR`);
  ok(Array.isArray(x.ex) && x.ex.length >= 1, `GX ${id} 沒有範例`);
  ok(Array.isArray(x.q) && x.q.length >= 6, `GX ${id} 題目少於 6`);
  (x.ex || []).forEach((e, i) => {
    ok(e.length === 5 && e[0] && e[1] && e[4], `GX ${id} 範例 ${i} 欄位不全`);
    ok(Array.isArray(e[2]) && e[2].length >= 2 && e[2].every(p => p.length === 2 && p[0] && (p[1] || /^[,.—–!?]$/.test(p[0]))), `GX ${id} 範例 ${i} 拆字格式錯`);
    ok(e[2].every(p => e[0].includes(p[0])), `GX ${id} 範例 ${i} 拆字不在句子裡：${e[2].map(p => p[0]).filter(w => !e[0].includes(w))}`);
    ok(Array.isArray(e[3]) && e[3].length >= 1, `GX ${id} 範例 ${i} 沒有說明`);
    ok(/[。！？]$/.test(e[1]), `GX ${id} 範例 ${i} 中文沒句號：${e[1]}`);
  });
  ok(new Set((x.q || []).map(q => q[0])).size === (x.q || []).length, `GX ${id} 有重複的題目`);
  (x.q || []).forEach((q, i) => {
    ok(q.length === 5 && q[0] && q[1] && q[3] && q[4], `GX ${id} 題 ${i} 欄位不全`);
    ok(q[0].includes('___'), `GX ${id} 題 ${i} 沒有空格：${q[0]}`);
    ok(Array.isArray(q[2]) && q[2].length >= 2 && q[2].length <= 3, `GX ${id} 題 ${i} 選項數`);
    ok(!q[2].includes(q[1]) && new Set(q[2]).size === q[2].length, `GX ${id} 題 ${i} 選項重複或含答案`);
  });
});
console.log(`單字 ${W.length} 個（名詞 ${nouns}、動詞 ${verbs}、形容詞 ${W.filter(e => e[1] === 'adj').length}），文法點 ${IT.GRAMMAR ? IT.GRAMMAR.length : 0} 個`);
console.log(`檢查 ${checks} 項，失敗 ${fails} 項`);
failList.slice(0, 80).forEach(m => console.log(' ✗ ' + m));
process.exit(fails ? 1 : 0);
