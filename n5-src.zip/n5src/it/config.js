/* 義大利文頁的設定 */
window.LANGCFG = {
  id: 'it', name: '義大利文', short: '義', level: 'A1', glyph: 'à', tts: 'it-IT',
  ttsSample: 'Ciao! Come stai? Io sto bene, grazie.',
  voiceNames: /alice|federica|paola|luca|elsa|isabella|diego|giorgio|emma|bianca/,
  noVoiceHelp: '這台裝置沒有義大利文語音。iPhone／Mac：到「設定 → 輔助使用 → 朗讀內容 → 聲音 → 義大利文」下載語音。Android：到「文字轉語音」設定下載義大利文。',
  persons: ['io', 'tu', 'lui/lei', 'noi', 'voi', 'loro'],
  sayPerson: i => ['io', 'tu', 'lui', 'noi', 'voi', 'loro'][i],
  impPersons: ['tu', 'Lei（您）', 'noi', 'voi'],
  pastLabel: '過去式 passato prossimo',
  artLabel: '冠詞介詞',
  verbTags: c => [{ are: '-are 規則動詞', ere: '-ere 規則動詞', ire: '-ire 規則動詞', isc: '-ire 動詞（加 -isc-）', irr: '不規則動詞' }[c.cls] || '']
    .concat(c.refl ? ['反身動詞'] : [], ['過去式用 ' + (c.aux === 'e' ? 'essere' : 'avere'), '過去分詞 ' + c.pp]),
  ruleShort: { 'r-noun': '名詞', 'r-art': '冠詞', 'r-adj': '形容詞', 'r-are': '-are 動詞', 'r-ere': '-ere 動詞', 'r-ire': '-ire 動詞', 'r-ea': 'essere／avere', 'r-irr': '不規則動詞' },
  letterGroups: [{ title: '義大利文字母（21 個）', from: 0, to: 21 }, { title: '外來字母', from: 21, to: 26, fo: true }],
  letterNote: '點字母看發音和例字。母音只有 a、e、i、o、u 五個，幾乎每個字母都照拼字發音。'
};
