// 用真的瀏覽器（手機寬度 390px）測字卡的「最近學過」：node n5src/card-recent-e2e.js n5work [ja it …]
// 需要 playwright 和 Chrome（不在 test-all.js 裡）。會在目前的資料夾留下 shot-card-recent-*.png 截圖
let chromium; try { ({ chromium } = require('playwright')); } catch (e) { ({ chromium } = require('/opt/npm-tools/node_modules/playwright')); }
const http = require('http'), fs = require('fs'), path = require('path');
const ROOT = path.resolve(process.argv[2]);
const LANGS = process.argv.slice(3).length ? process.argv.slice(3) : ['ja', 'it'];
const srv = http.createServer((q, r) => { const f = path.join(ROOT, decodeURIComponent(q.url.split('?')[0])); fs.readFile(f, (e, d) => { if (e) { r.writeHead(404); return r.end(); } r.writeHead(200, { 'content-type': f.endsWith('.html') ? 'text/html; charset=utf-8' : f.endsWith('.js') ? 'text/javascript' : 'application/octet-stream' }); r.end(d); }); });
let bad = 0; const ok = (c, m) => { console.log((c ? '✓ ' : '✗ ') + m); if (!c) bad++; };
(async () => {
  await new Promise(r => srv.listen(0, r)); const base = 'http://127.0.0.1:' + srv.address().port + '/';
  const br = await chromium.launch({ executablePath: process.env.CHROME || (fs.existsSync('/usr/bin/google-chrome') ? '/usr/bin/google-chrome' : undefined), args: ['--no-sandbox'] });
  for (const L of LANGS) {
    console.log('—— ' + L);
    const file = L === 'ja' ? 'index.html' : L + '.html', pre = L === 'ja' ? 'n5' : L;
    const ctx = await br.newContext({ viewport: { width: 390, height: 780 }, deviceScaleFactor: 2, isMobile: true, hasTouch: true });
    await ctx.route(/^https:\/\//, r => r.abort());
    await ctx.addInitScript(([l, pre]) => { if (!localStorage.getItem('langs:last')) { localStorage.setItem('langs:last', JSON.stringify(l)); localStorage.setItem('langs:v1', JSON.stringify({ active: [l], max: 2, lock: true, note: '' })); localStorage.setItem(pre + ':toured', '1'); localStorage.setItem(pre + ':ui', JSON.stringify({ tab: 'card', cardSrc: 'new' })); localStorage.setItem(pre + ':pop', JSON.stringify({ n: 0, goal: 99, last: new Date().toLocaleDateString('sv-SE') })); } }, [L, pre]);
    const pg = await ctx.newPage(); const errs = [];
    pg.on('pageerror', e => errs.push(e.message)); pg.on('console', m => { if (m.type() === 'error' && !/net::ERR|Failed to load resource/.test(m.text())) errs.push(m.text()); });
    await pg.goto(base + file); await pg.waitForSelector('#tab-card [data-a="queue"]');
    ok(await pg.evaluate(() => [...document.querySelectorAll('#cardSrc option')].some(o => o.value === 'recent')), '字卡來源有「最近學過」');
    for (let i = 0; i < 12; i++) { await pg.click('#tab-card [data-a="queue"]'); await pg.waitForTimeout(120); }
    const setSel = async (sel, v) => { await pg.evaluate(([sel, v]) => { const el = document.querySelector(sel); el.value = v; el.dispatchEvent(new Event('change')); }, [sel, v]); await pg.waitForTimeout(200); };
    await setSel('#cardSrc', 'recent');
    ok(!!(await pg.$('#tab-card #recentSel')) && !(await pg.$('#tab-card [data-possel]')), '選「最近學過」後顯示範圍選單、不顯示詞性');
    const meta = async () => (await pg.textContent('#fcHost .qh-l .meta')).trim();
    ok(/共 12$/.test(await meta()), '最近 1 天：一疊是全部 12 個字（' + await meta() + '）');
    ok(/最近學過 12/.test(await pg.textContent('#cardSrc option[value="recent"]')), '選單上的數字是 12');
    await setSel('#recentSel', 'c10');
    ok(/共 10$/.test(await meta()), '改成最近 10 個字：一疊 10 張（' + await meta() + '）');
    ok(JSON.parse(await pg.evaluate(() => localStorage.getItem('n5:settings'))).recent === 'c10', '範圍存進設定（和單選、填空共用）');
    await pg.click('#fcHost [data-a="next"]'); await pg.waitForTimeout(150);
    ok(/剩 9 · 共 10$/.test(await meta()), '按「下一張」剩 9 張');
    ok(await pg.evaluate(() => { const r = document.querySelector('#tab-card .ctl').getBoundingClientRect(); return r.right <= innerWidth + 1; }), '手機寬度：上方選單沒有超出螢幕');
    await pg.screenshot({ path: `shot-card-recent-${L}.png` });
    // 單選也共用同一個範圍
    await pg.click('.tabbar [data-tab="mc"], nav [data-tab="mc"]'); await pg.waitForSelector('#mcSrc', { state: 'attached' });
    await setSel('#mcSrc', 'recent');
    ok((await pg.evaluate(() => document.querySelector('#recentSel').value)) === 'c10', '單選的「最近學過」用同一個範圍');
    // 清除後：範圍內沒有字時有提示
    await pg.click('.tabbar [data-tab="card"], nav [data-tab="card"]'); await pg.waitForTimeout(200);
    await pg.evaluate(() => { const p = JSON.parse(localStorage.getItem('n5:progress')); Object.values(p.items).forEach(r => { if (r.q) r.q = 1; if (r.t) r.t = 1; }); localStorage.setItem('n5:progress', JSON.stringify(p)); });
    await pg.reload(); await pg.waitForSelector('#tab-card #recentSel', { state: 'attached' });
    await setSel('#recentSel', 'd1');
    ok(/範圍內還沒有學過的字/.test(await pg.textContent('#fcHost')), '範圍內沒有字時顯示提示');
    ok(!errs.length, '沒有錯誤訊息' + (errs.length ? '：' + errs.join(' | ') : ''));
    await ctx.close();
  }
  await br.close(); srv.close();
  console.log(bad ? `✗ ${bad} 項失敗` : '全部通過'); process.exit(bad ? 1 : 0);
})();
