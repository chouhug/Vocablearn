// 用真的瀏覽器（手機寬度 390px）測字卡的「最近學過」：node n5src/card-recent-e2e.js n5work [ja it …]
// 需要 playwright 和 Chrome（不在 test-all.js 裡）。會在目前的資料夾留下 shot-card-recent-*.png 截圖
let chromium; try { ({ chromium } = require('playwright')); } catch (e) { ({ chromium } = require('/opt/npm-tools/node_modules/playwright')); }
const http = require('http'), fs = require('fs'), path = require('path');
const ROOT = path.resolve(process.argv[2]);
const LANGS = process.argv.slice(3).length ? process.argv.slice(3) : ['ja', 'it'];
const srv = http.createServer((q, r) => { const f = path.join(ROOT, decodeURIComponent(q.url.split('?')[0])); fs.readFile(f, (e, d) => { if (e) { r.writeHead(404); return r.end(); } r.writeHead(200, { 'content-type': f.endsWith('.html') ? 'text/html; charset=utf-8' : f.endsWith('.js') ? 'text/javascript' : 'application/octet-stream' }); r.end(d); }); });
let bad = 0; const ok = (c, m) => { console.log((c ? '✓ ' : '✗ ') + m); if (!c) bad++; };
(async () => {
  await new Promise(r => srv.listen(0, r)); const base = 'http://127.0.0.1:' + srv.address().port + '/';
  const br = await chromium.launch({ executablePath: process.env.CHROME || (fs.existsSync('/usr/bin/google-chrome') ? '/usr/bin/google-chrome' : undefined), args: ['--no-sandbox'] });
  for (const L of LANGS) {
    console.log('—— ' + L);
    const file = L === 'ja' ? 'index.html' : L + '.html', pre = L === 'ja' ? 'n5' : L;
    const ctx = await br.newContext({ viewport: { width: 390, height: 780 }, deviceScaleFactor: 2, isMobile: true, hasTouch: true });
    await ctx.route(/^https:\/\//, r => r.abort());
    await ctx.addInitScript(([l, pre]) => { if (!localStorage.getItem('langs:last')) { localStorage.setItem('langs:last', JSON.stringify(l)); localStorage.setItem('langs:v1', JSON.stringify({ active: [l], max: 2, lock: true, note: '' })); localStorage.setItem(pre + ':toured', '1'); localStorage.setItem(pre + ':ui', JSON.stringify({ tab: 'card', cardSrc: 'new' })); localStorage.setItem(pre + ':pop', JSON.stringify({ n: 0, goal: 99, last: new Date().toLocaleDateString('sv-SE') })); } }, [L, pre]);
    const pg = await ctx.newPage(); const errs = [];
    pg.on('pageerror', e => errs.push(e.message)); pg.on('console', m => { if (m.type() === 'error' && !/net::ERR|Failed to load resource/.test(m.text())) errs.push(m.text()); });
    await pg.goto(base + file); await pg.waitForSelector('#tab-card [data-a="queue"]');
    ok(await pg.evaluate(() => [...document.querySelectorAll('#cardSrc option')].some(o => o.value === 'recent')), '字卡來源有「最近學過」');
    for (let i = 0; i < 12; i++) { await pg.click('#tab-card [data-a="queue"]'); await pg.waitForTimeout(120); }
    const setSel = async (sel, v) => { await pg.evaluate(([sel, v]) => { const el = document.querySelector(sel); el.value = v; el.dispatchEvent(new Event('change')); }, [sel, v]); await pg.waitForTimeout(200); };
    await setSel('#cardSrc', 'recent');
    ok(!!(await pg.$('#tab-card #recentSel')) && !(await pg.$('#tab-card [data-possel]')), '選「最近學過」後顯示範圍選單、不顯示詞性');
    const meta = async () => (await pg.textContent('#fcHost .qh-l .meta:not(.fc-ago)')).trim();
    ok((await pg.textContent('#fcHost .fc-ago')).trim() === '今天學過', '字卡左上角顯示「今天學過」');
    ok(/共 12$/.test(await meta()), '最近 1 天：一疊是全部 12 個字（' + await meta() + '）');
    ok(/最近學過 12/.test(await pg.textContent('#cardSrc option[value="recent"]')), '選單上的數字是 12');
    const pick = async v => { await pg.click('#tab-card .pw:has(#recentSel)'); await pg.waitForSelector(`.pk:not([hidden]) [data-v="${v}"]`); await pg.click(`.pk:not([hidden]) [data-v="${v}"]`); };
    const ask = async (v, n) => { await pick(v); await pg.waitForSelector('#recentForm #recentN'); await pg.fill('#recentN', String(n)); await pg.click('#recentForm [type=submit]'); await pg.waitForTimeout(500); };
    ok((await pg.evaluate(() => [...document.querySelectorAll('#recentSel option')].map(o => o.value + '=' + o.textContent).join())) === 'd1=最近 1 天,+d=自訂天數…,+c=自訂字數…', '範圍選單只有目前的範圍和兩個自訂');
    await ask('+c', 10);
    ok(/共 10$/.test(await meta()), '改成最近 10 個字：一疊 10 張（' + await meta() + '）');
    ok(JSON.parse(await pg.evaluate(() => localStorage.getItem('n5:settings'))).recent === 'c10', '範圍存進設定（和單選、填空共用）');
    await pg.click('#fcHost [data-a="next"]'); await pg.waitForTimeout(150);
    ok(/剩 9 · 共 10$/.test(await meta()), '按「下一張」剩 9 張');
    ok(await pg.evaluate(() => { const r = document.querySelector('#tab-card .ctl').getBoundingClientRect(); return r.right <= innerWidth + 1; }), '手機寬度：上方選單沒有超出螢幕');
    await pg.screenshot({ path: `shot-card-recent-${L}.png` });
    // 自訂字數：點範圍選單 → 選「自訂字數…」→ 填 11 → 一疊 11 張
    await pick('+c'); await pg.waitForSelector('#recentForm #recentN');
    ok((await pg.evaluate(() => document.querySelector('#recentSel').value)) === 'c10', '選「自訂字數…」時選單先停在原本的值');
    await pg.screenshot({ path: `shot-card-recent-${L}-ask.png` });
    await pg.fill('#recentN', '0'); await pg.click('#recentForm [type=submit]'); await pg.waitForTimeout(150);
    ok(/請填 1 以上的整數/.test(await pg.textContent('#recentErr')) && !!(await pg.$('#recentForm')), '填 0 會提示，面板不關');
    await pg.fill('#recentN', '11'); await pg.press('#recentN', 'Enter'); await pg.waitForTimeout(500);
    ok(JSON.parse(await pg.evaluate(() => localStorage.getItem('n5:settings'))).recent === 'c11', '填 11：存成 c11');
    ok(/共 11$/.test(await meta()), '自訂最近 11 個字：一疊 11 張（' + await meta() + '）');
    ok((await pg.evaluate(() => { const s = document.querySelector('#recentSel'); return s.value + '|' + s.options[s.selectedIndex].textContent; })) === 'c11|最近 11 個字', '選單上出現「最近 11 個字」並選著');
    ok((await pg.evaluate(() => document.querySelectorAll('#recentSel option').length)) === 3, '換了以後選單還是三項（舊的值不留）');
    // 自訂天數：打開後按叉叉不換
    await pick('+d'); await pg.waitForSelector('#recentForm #recentN');
    await pg.click('.pk:not([hidden]) .pk-x'); await pg.waitForTimeout(300);
    ok(JSON.parse(await pg.evaluate(() => localStorage.getItem('n5:settings'))).recent === 'c11', '自訂天數按叉叉關掉：範圍不變');
    await pick('+d'); await pg.waitForSelector('#recentForm #recentN');
    ok(/你最早是 1 天前開始學的/.test(await pg.textContent('#recentForm')), '自訂天數的面板說明最早是幾天前開始學的');
    await pg.fill('#recentN', '30'); await pg.click('#recentForm [type=submit]'); await pg.waitForTimeout(300);
    const tt = await pg.textContent('#toast');
    ok((await pg.evaluate(() => document.querySelector('#recentSel').value)) === 'd1' && /已改成最近 1 天/.test(tt), '填 30 天（只學了今天）自動改成最近 1 天：' + tt);
    ok(/共 12$/.test(await meta()), '最近 1 天：12 張');
    await pick('+c'); await pg.waitForSelector('#recentForm #recentN');
    ok(/你學過 12 個字/.test(await pg.textContent('#recentForm')), '自訂字數的面板說明學過幾個字');
    await pg.fill('#recentN', '500'); await pg.click('#recentForm [type=submit]'); await pg.waitForTimeout(300);
    ok((await pg.evaluate(() => document.querySelector('#recentSel').value)) === 'c12' && /已改成最近 12 個字/.test(await pg.textContent('#toast')), '填 500 個字自動改成 12');
    await pick('+d'); await pg.waitForSelector('#recentForm #recentN'); await pg.fill('#recentN', '1'); await pg.click('#recentForm [type=submit]'); await pg.waitForTimeout(400);
    await pg.click('.tabbar [data-tab="lib"], nav [data-tab="lib"]'); await pg.waitForSelector('#recentSet', { state: 'attached' });
    ok((await pg.evaluate(() => document.querySelector('#recentSet').value)) === 'd1', '設定頁的範圍也顯示自訂的「最近 1 天」');
    await pg.evaluate(() => { const el = document.querySelector('#recentSet'); el.value = '+c'; el.dispatchEvent(new Event('change')); });
    await pg.waitForSelector('#recentForm #recentN'); await pg.fill('#recentN', '10'); await pg.click('#recentForm [type=submit]'); await pg.waitForTimeout(400);
    ok(JSON.parse(await pg.evaluate(() => localStorage.getItem('n5:settings'))).recent === 'c10', '設定頁也能自訂（填 10）');
    await pg.click('.tabbar [data-tab="card"], nav [data-tab="card"]'); await pg.waitForTimeout(200);
    // 單選也共用同一個範圍
    await pg.click('.tabbar [data-tab="mc"], nav [data-tab="mc"]'); await pg.waitForSelector('#mcSrc', { state: 'attached' });
    await setSel('#mcSrc', 'recent');
    ok((await pg.evaluate(() => document.querySelector('#recentSel').value)) === 'c10', '單選的「最近學過」用同一個範圍');
    // 清除後：範圍內沒有字時有提示
    await pg.click('.tabbar [data-tab="card"], nav [data-tab="card"]'); await pg.waitForTimeout(200);
    // 改成 3 天前開始學：左上角顯示「3 天前學過」，自訂天數最多 3 天
    await pg.evaluate(() => { const p = JSON.parse(localStorage.getItem('n5:progress')); Object.values(p.items).forEach(r => { if (r.q) r.q -= 3 * 864e5; if (r.t) r.t -= 3 * 864e5; }); localStorage.setItem('n5:progress', JSON.stringify(p)); });
    await pg.reload(); await pg.waitForSelector('#tab-card #recentSel', { state: 'attached' });
    await ask('+d', 99);
    ok((await pg.evaluate(() => document.querySelector('#recentSel').value)) === 'd3', '3 天前開始學：填 99 天改成最近 3 天');
    ok((await pg.textContent('#fcHost .fc-ago')).trim() === '3 天前學過', '字卡左上角顯示「3 天前學過」');
    await pg.screenshot({ path: `shot-card-recent-${L}-ago.png` });
    await pg.evaluate(() => { const p = JSON.parse(localStorage.getItem('n5:progress')); Object.values(p.items).forEach(r => { if (r.q) r.q = 1; if (r.t) r.t = 1; }); localStorage.setItem('n5:progress', JSON.stringify(p)); });
    await pg.reload(); await pg.waitForSelector('#tab-card #recentSel', { state: 'attached' });
    await ask('+d', 1);
    ok(/範圍內還沒有學過的字/.test(await pg.textContent('#fcHost')), '範圍內沒有字時顯示提示');
    ok(!errs.length, '沒有錯誤訊息' + (errs.length ? '：' + errs.join(' | ') : ''));
    await ctx.close();
  }
  await br.close(); srv.close();
  console.log(bad ? `✗ ${bad} 項失敗` : '全部通過'); process.exit(bad ? 1 : 0);
})();
