// 用真的瀏覽器（手機寬度 390px）走一遍日文頁的「我的單字」：node n5src/mine-ja-e2e.js n5work
// 需要 playwright 和 Chrome（不在 test-all.js 裡）；線上字典用假的回應；會在目前的資料夾留下 shot-ja-*.png
let chromium; try { ({ chromium } = require('playwright')); } catch (e) { ({ chromium } = require('/opt/npm-tools/node_modules/playwright')); }
const http = require('http'), fs = require('fs'), path = require('path');
const ROOT = path.resolve(process.argv[2]);
const srv = http.createServer((q, r) => { const f = path.join(ROOT, decodeURIComponent(q.url.split('?')[0])); fs.readFile(f, (e, d) => { if (e) { r.writeHead(404); return r.end(); } r.writeHead(200, { 'content-type': f.endsWith('.html') ? 'text/html; charset=utf-8' : 'text/javascript' }); r.end(d); }); });
let bad = 0; const ok = (c, m) => { console.log((c ? '✓ ' : '✗ ') + m); if (!c) bad++; };
(async () => {
  await new Promise(r => srv.listen(0, r));
  const br = await chromium.launch({ executablePath: process.env.CHROME || (fs.existsSync('/usr/bin/google-chrome') ? '/usr/bin/google-chrome' : undefined), args: ['--no-sandbox'] });
  const ctx = await br.newContext({ viewport: { width: 390, height: 780 }, deviceScaleFactor: 2, isMobile: true, hasTouch: true });
  await ctx.route(/^https:\/\//, r => r.abort());
  const cors = { 'access-control-allow-origin': '*' };
  await ctx.route(/en\.wiktionary\.org\/api\/rest_v1\/page\/definition\//, r => { const t = decodeURIComponent(r.request().url().split('/').pop()); if (t !== '髭') return r.fulfill({ status: 404, contentType: 'application/json', headers: cors, body: '{}' }); r.fulfill({ contentType: 'application/json', headers: cors, body: JSON.stringify({ ja: [{ partOfSpeech: 'Noun', language: 'Japanese', definitions: [{ definition: 'a <a href="/wiki/beard">beard</a>, a moustache' }] }], zh: [{ partOfSpeech: 'Noun', language: 'Chinese', definitions: [{ definition: 'x' }] }] }) }); });
  await ctx.route(/api\.mymemory\.translated\.net\/get/, r => { const u = new URL(r.request().url()), q = u.searchParams.get('q'); r.fulfill({ contentType: 'application/json', headers: cors, body: JSON.stringify(q === '髭' && u.searchParams.get('langpair') === 'ja|zh-TW' ? { responseData: { translatedText: '鬍子' }, matches: [{ segment: q, translation: '鬍子', quality: 70, match: 1 }] } : { responseData: { translatedText: q }, matches: [] }) }); });
  await ctx.addInitScript(() => { if (!localStorage.getItem('langs:last')) { localStorage.setItem('langs:last', '"ja"'); localStorage.setItem('langs:v1', JSON.stringify({ active: ['ja'], max: 2, lock: true, note: '' })); localStorage.setItem('n5:toured', '1'); localStorage.setItem('n5:ui', JSON.stringify({ tab: 'lib' })); } });
  const pg = await ctx.newPage(); const errs = [];
  pg.on('pageerror', e => errs.push(e.message)); pg.on('console', m => { if (m.type() === 'error' && !/net::ERR|Failed to load resource/.test(m.text())) errs.push(m.text()); });
  await pg.goto('http://127.0.0.1:' + srv.address().port + '/index.html'); await pg.waitForSelector('#addMine');
  const P = () => pg.evaluate(() => JSON.parse(localStorage.getItem('n5:progress') || '{"items":{}}').items);
  const submit = async () => { await pg.click('#myForm [type=submit]'); await pg.waitForTimeout(400); };
  const msg = () => pg.textContent('#myMsg');
  // 新增：各種錯誤
  await pg.click('#addMine'); await pg.waitForSelector('#myForm');
  ok(await pg.locator('#my-p').count() === 0 && await pg.locator('#my-r').count() === 1 && await pg.locator('#my-sr').count() === 1, '日文表單：有讀音、例句的讀法，沒有詞性');
  await pg.fill('#my-w', '猫'); await pg.fill('#my-zh', '貓'); await submit(); ok(/本來就有/.test(await msg()), '單字庫已有的字不能重複新增');
  await pg.fill('#my-w', '髭'); await pg.fill('#my-zh', ''); await pg.click('#myLook'); await pg.waitForSelector('#myDict [data-fill]');
  ok(/a beard, a moustache/.test(await pg.textContent('#myDict')) && !/Chinese|x<\/button>/.test(await pg.innerHTML('#myDict')), '查字典：只列日文的解釋');
  await pg.click('#myDict .dict-zh [data-fill]'); ok(await pg.inputValue('#my-zh') === '鬍子', '點中文翻譯會填進意思');
  await pg.screenshot({ path: 'shot-ja-form.png' });
  await submit(); ok(/有漢字/.test(await msg()), '有漢字沒填讀音會提示');
  await pg.fill('#my-r', 'hige'); await submit(); ok(/假名/.test(await msg()), '讀音不是假名會提示');
  await pg.fill('#my-r', 'ひげ'); await pg.fill('#my-s', '父は髭を剃ります。'); await pg.fill('#my-sz', '爸爸刮鬍子。');
  await pg.fill('#my-sr', 'ちちはひげをそる。'); await submit(); ok(/對不起來/.test(await msg()), '例句的讀法對不上會提示');
  await pg.fill('#my-sr', 'ちちはひげをそります。'); await submit();
  let it = await P(); const id = 'v:my:髭';
  ok(it[id] && it[id].s === 'queued' && it[id].c.r === 'ひげ' && it[id].c.sr === 'ちちはひげをそります。', '存好：列入考題、寫進 localStorage');
  // 清單
  await pg.click('#listBox summary'); await pg.click('[data-list="mine"]');
  ok((await pg.textContent('#listBox .lrows')).includes('髭'), '「我的單字」清單看得到');
  await pg.screenshot({ path: 'shot-ja-lib.png', fullPage: true });
  await pg.fill('#q', 'hige'); ok((await pg.textContent('#results')).includes('鬍子'), '用拼音搜尋找得到');
  await pg.fill('#q', 'ぬるぽ'); ok(await pg.isVisible('#results [data-addmine]'), '搜尋不到時可以查字典並新增');
  await pg.fill('#q', '');
  // 填空（有讀法：漢字、假名、拼音都算對）
  await pg.click('.tabbar [data-tab="fill"]'); await pg.waitForSelector('#fillIn');
  ok((await pg.textContent('#tab-fill')).includes('爸爸刮鬍子'), '填空出了這個字');
  ok((await pg.innerHTML('#fillSent')).includes('<rt>ちち</rt>'), '填了例句讀法：其他漢字有振り仮名');
  await pg.screenshot({ path: 'shot-ja-fill.png' });
  await pg.fill('#fillIn', 'hige'); await pg.click('#fillGo'); await pg.waitForTimeout(300);
  ok(/答對了/.test(await pg.textContent('#fillAfter')), '填空用拼音答對');
  ok((await P())[id].s === 'learned' && !!(await P())[id].c, '答對後算學會，定義還在');
  // 單選各題型、聽寫、字卡、文法：都不能出錯
  await pg.evaluate(id => { const s = JSON.parse(localStorage.getItem('n5:progress')); s.items[id].s = 'queued'; s.items[id].t = Date.now(); localStorage.setItem('n5:progress', JSON.stringify(s)); }, id);
  await pg.reload(); await pg.waitForSelector('.tabbar');
  await pg.click('.tabbar [data-tab="mc"]'); await pg.waitForSelector('#tab-mc .opt');
  ok((await pg.textContent('#tab-mc')).includes('髭'), '重新整理後還在，單選出了這個字');
  await pg.screenshot({ path: 'shot-ja-mc.png' });
  for (const m of await pg.evaluate(() => [...document.querySelectorAll('#tab-mc select')].flatMap(s => /題型|模式|方式/.test(s.getAttribute('aria-label') || '') ? [...s.options].map(o => o.value) : []))) {
    await pg.evaluate(m => { const s = [...document.querySelectorAll('#tab-mc select')].find(s => [...s.options].some(o => o.value === m)); s.value = m; s.dispatchEvent(new Event('change', { bubbles: true })); }, m); await pg.waitForTimeout(200);
  }
  await pg.click('.tabbar [data-tab="fill"]'); await pg.waitForTimeout(200);
  await pg.evaluate(() => { const b = [...document.querySelectorAll('#tab-fill .seg button')].find(b => /聽寫/.test(b.textContent)); if (b) b.click(); }); await pg.waitForTimeout(300);
  await pg.click('.tabbar [data-tab="card"]'); await pg.waitForTimeout(300);
  await pg.click('.tabbar [data-tab="gram"]'); await pg.waitForTimeout(300);
  // 編輯：例句讀法拿掉、字在例句裡有變化
  await pg.click('.tabbar [data-tab="lib"]'); await pg.waitForSelector('#listBox'); await pg.click('#listBox summary'); await pg.click('[data-list="mine"]');
  await pg.click('#listBox .lrows button[data-id]'); await pg.waitForSelector('#myDel');
  await pg.fill('#my-sr', ''); await submit();
  ok((await P())[id].c.sr === undefined && (await P())[id].s === 'queued', '編輯後進度保留（例句讀法可以不填）');
  await pg.click('.tabbar [data-tab="fill"]'); await pg.waitForTimeout(200);
  ok(/沒有|空|先/.test(await pg.textContent('#tab-fill')) && !(await pg.textContent('#tab-fill')).includes('刮鬍子'), '沒有例句讀法的字不出聽寫');
  await pg.evaluate(() => { const b = [...document.querySelectorAll('#tab-fill .seg button')].find(b => /填空/.test(b.textContent)); b.click(); }); await pg.waitForSelector('#fillIn');
  ok(!(await pg.innerHTML('#fillSent')).includes('<rt>ちち</rt>') && (await pg.textContent('#fillSent')).includes('父'), '沒填例句讀法：其他漢字照樣顯示，只是沒有振り仮名');
  await pg.fill('#fillIn', '髭'); await pg.click('#fillGo'); await pg.waitForTimeout(300);
  ok(/答對了/.test(await pg.textContent('#fillAfter')), '填空用漢字答對');
  // 動詞：例句裡有變化、沒有例句讀法 → 要求填
  await pg.evaluate(() => { document.activeElement.blur(); document.body.classList.remove('typing'); });   // 打字時底部分頁會收起來
  await pg.click('.tabbar [data-tab="lib"]'); await pg.click('#addMine'); await pg.waitForSelector('#myForm');
  await pg.fill('#my-w', '剃る'); await pg.fill('#my-r', 'そる'); await pg.fill('#my-zh', '刮'); await pg.fill('#my-s', '父は髭を剃ります。'); await submit();
  ok(/找不到/.test(await msg()), '例句裡沒有原形會提示填「例句裡的寫法」');
  await pg.fill('#my-a', '剃ります'); await submit(); ok(/請填「例句的讀法」/.test(await msg()), '變化形有漢字、沒有例句讀法會要求填');
  await pg.fill('#my-sr', 'ちちはひげをそります。'); await submit();
  ok(!!(await P())['v:my:剃る'], '填了讀法就能存');
  // 片假名、沒有例句
  await pg.click('.tabbar [data-tab="lib"]'); await pg.click('#addMine'); await pg.waitForSelector('#myForm');
  await pg.fill('#my-w', 'シェーバー'); await pg.fill('#my-zh', '電動刮鬍刀'); await submit();
  ok(!!(await P())['v:my:シェーバー'], '全假名的字不用填讀音、可以沒有例句');
  // 刪除
  await pg.click('#listBox summary'); await pg.click('[data-list="mine"]'); await pg.click('#listBox .lrows button[data-id]'); await pg.waitForSelector('#myDel');
  await pg.click('#myDel'); await pg.click('#myDel'); await pg.waitForTimeout(300);
  it = await P(); ok(Object.keys(it).filter(k => k.startsWith('v:my:') && it[k].c).length === 2, '刪除一個，剩兩個');
  await pg.click('#addMine'); await pg.waitForSelector('#myForm');
  ok(await pg.evaluate(() => document.documentElement.scrollWidth <= innerWidth && [...document.querySelectorAll('#myForm input, #myForm textarea, #myForm button')].every(x => { const r = x.getBoundingClientRect(); return r.left >= 0 && r.right <= innerWidth && r.height >= 40; })), '手機寬度：表單沒有超出螢幕');
  ok(!errs.length, '沒有 JavaScript 錯誤' + (errs.length ? '：' + errs.join(' | ') : ''));
  await br.close(); srv.close();
  console.log(bad ? bad + ' 項失敗' : '全部通過'); process.exit(bad ? 1 : 0);
})().catch(e => { console.error(String(e).slice(0, 600)); process.exit(1); });
