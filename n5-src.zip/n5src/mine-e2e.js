// 用真的瀏覽器（手機寬度 390px）走一遍「我的單字」：node n5src/mine-e2e.js n5work [en it es de ru]
// 需要 playwright 和 Chrome（GitHub Actions 沒有，所以不在 test-all.js 裡；改了 shared/mine.js 或 lang-app.js 的 syncMine 後在本機跑）
// 會在目前的資料夾留下 shot-*.png 截圖
let chromium; try { ({ chromium } = require('playwright')); } catch (e) { ({ chromium } = require('/opt/npm-tools/node_modules/playwright')); }
const http = require('http'), fs = require('fs'), path = require('path');
const ROOT = path.resolve(process.argv[2]);
const LANGS = process.argv.slice(3).length ? process.argv.slice(3) : ['en'];
const SAMPLE = { en: ['whisker', 'whiskers', 'The cat has long whiskers.', 'cat'], it: ['baffo', 'baffi', 'Il gatto ha i baffi lunghi.', 'gatto'], es: ['bigote', 'bigotes', 'El gato tiene bigotes largos.', 'gato'], de: ['Schnurrhaar', 'Schnurrhaare', 'Die Katze hat lange Schnurrhaare.', 'Katze'], ru: ['усы', 'усами', 'Кот шевелит усами.', 'кот'] };
const srv = http.createServer((q, r) => { const f = path.join(ROOT, decodeURIComponent(q.url.split('?')[0])); fs.readFile(f, (e, d) => { if (e) { r.writeHead(404); return r.end(); } r.writeHead(200, { 'content-type': f.endsWith('.html') ? 'text/html; charset=utf-8' : f.endsWith('.js') ? 'text/javascript' : 'application/octet-stream' }); r.end(d); }); });
let bad = 0; const ok = (c, m) => { console.log((c ? '✓ ' : '✗ ') + m); if (!c) bad++; };
(async () => {
  await new Promise(r => srv.listen(0, r)); const base = 'http://127.0.0.1:' + srv.address().port + '/';
  const br = await chromium.launch({ executablePath: process.env.CHROME || (fs.existsSync('/usr/bin/google-chrome') ? '/usr/bin/google-chrome' : undefined), args: ['--no-sandbox'] });
  for (const L of LANGS) {
    console.log('—— ' + L);
    const [W, FORM, SENT, BUILTIN] = SAMPLE[L];
    const ctx = await br.newContext({ viewport: { width: 390, height: 780 }, deviceScaleFactor: 2, isMobile: true, hasTouch: true });
    await ctx.route(/^https:\/\//, r => r.abort());
    await ctx.addInitScript(l => { if (!localStorage.getItem('langs:last')) { localStorage.setItem('langs:last', JSON.stringify(l)); localStorage.setItem('langs:v1', JSON.stringify({ active: [l], max: 2, lock: true, note: '' })); localStorage.setItem(l + ':toured', '1'); localStorage.setItem(l + ':ui', JSON.stringify({ tab: 'lib' })); } }, L);
    const pg = await ctx.newPage(); const errs = [];
    pg.on('pageerror', e => errs.push(e.message)); pg.on('console', m => { if (m.type() === 'error' && !/net::ERR|Failed to load resource/.test(m.text())) errs.push(m.text()); });
    await pg.goto(base + L + '.html'); await pg.waitForSelector('#addMine');
    const total0 = await pg.evaluate(() => ITApp.WORDS.length);
    // 新增：先故意出錯
    await pg.click('#addMine'); await pg.waitForSelector('#myForm');
    await pg.click('#myForm [type=submit]'); ok(await pg.isVisible('#myMsg'), '沒填單字會提示');
    await pg.fill('#my-w', await pg.evaluate(() => ITApp.WORDS[5].word.toUpperCase())); await pg.fill('#my-zh', '測試'); await pg.click('#myForm [type=submit]');
    ok(/本來就有/.test(await pg.textContent('#myMsg')), '單字庫已有的字不能重複新增');
    await pg.fill('#my-w', W); await pg.fill('#my-zh', '鬍鬚'); await pg.selectOption('#my-p', 'n'); await pg.fill('#my-s', SENT); await pg.fill('#my-sz', '貓的鬍鬚很長。');
    if (FORM !== W) { await pg.click('#myForm [type=submit]'); ok(/找不到/.test(await pg.textContent('#myMsg')), '例句裡沒有這個字會提示'); }
    await pg.fill('#my-a', FORM);
    await pg.screenshot({ path: `shot-${L}-form.png` });
    await pg.click('#myForm [type=submit]'); await pg.waitForTimeout(400);
    const st = await pg.evaluate(w => { const id = Object.keys(ITApp.S().items).find(k => k.includes(':my:')); const r = ITApp.S().items[id]; return { id, s: r.s, c: r.c, n: ITApp.WORDS.length, stored: JSON.parse(localStorage.getItem('n5:progress')).items[id] }; }, W);
    ok(st.n === total0 + 1 && st.s === 'queued' && st.c.w === W && st.stored && st.stored.c.zh === '鬍鬚', '存好：進了單字庫、列入考題、寫進 localStorage（' + st.id + '）');
    // 清單
    await pg.click('#listBox summary'); await pg.click('[data-list="mine"]');
    ok((await pg.textContent('#listBox .lrows')).includes(W), '「我的單字」清單看得到');
    await pg.screenshot({ path: `shot-${L}-lib.png`, fullPage: true });
    // 搜尋
    await pg.fill('#q', W.slice(0, 4)); ok((await pg.textContent('#results')).includes('鬍鬚'), '搜尋找得到');
    await pg.fill('#q', 'zzqqxx'); ok(await pg.isVisible('#results [data-addmine]'), '搜尋不到時可以直接新增');
    await pg.fill('#q', '');
    // 單字頁
    await pg.evaluate(id => ITApp.openWord(id), st.id); await pg.waitForSelector('[data-wa="edit"]');
    await pg.screenshot({ path: `shot-${L}-word.png` });
    await pg.click('.pk-x'); await pg.waitForTimeout(300);
    // 填空
    await pg.evaluate(() => { ITApp.UI.fillSrc = 'learn'; ITApp.UI.pos = 'all'; ITApp.showTab('fill'); });
    await pg.waitForSelector('#fillIn');
    ok((await pg.textContent('#tab-fill')).includes('鬍鬚'), '填空出了這個字');
    await pg.screenshot({ path: `shot-${L}-fill.png` });
    await pg.fill('#fillIn', FORM); await pg.click('#fillGo'); await pg.waitForTimeout(300);
    ok(/答對了/.test(await pg.textContent('#fillAfter')), '填空答對');
    ok(await pg.evaluate(id => ITApp.getRec(id).s === 'learned' && !!ITApp.getRec(id).c, st.id), '答對後算學會，定義還在');
    // 單選（三種基本題型＋特殊題型都不能出錯）
    for (const m of await pg.evaluate(() => { ITApp.touch(Object.keys(ITApp.S().items).find(k => k.includes(':my:')), { s: 'queued' }); return ['it2zh', 'zh2it', 'listen', 'verb', 'art']; })) {
      await pg.evaluate(m => { ITApp.UI.mcMode = m; ITApp.UI.mcSrc = 'learn'; ITApp.showTab('mc'); }, m); await pg.waitForTimeout(150);
      if (m === 'it2zh') { ok((await pg.textContent('#tab-mc')).includes(W), '單選出了這個字'); const n = await pg.locator('#tab-mc .opt').count(); ok(n === 4, '單選有 4 個選項'); await pg.screenshot({ path: `shot-${L}-mc.png` }); }
    }
    // 字卡、文法頁、例句點字
    await pg.evaluate(() => { ITApp.UI.cardSrc = 'queued'; ITApp.showTab('card'); }); await pg.waitForTimeout(150);
    ok((await pg.textContent('#tab-card')).includes(W), '字卡出了這個字');
    await pg.screenshot({ path: `shot-${L}-card.png` });
    await pg.evaluate(() => ITApp.showTab('gram')); await pg.waitForTimeout(200);
    await pg.evaluate(w => ITApp.openToken(w), W); await pg.waitForTimeout(200);
    ok((await pg.textContent('.sheet-body')).includes('鬍鬚'), '點例句裡的字查得到自己新增的字');
    await pg.click('.pk-x'); await pg.waitForTimeout(300);
    // 重新整理後還在
    await pg.reload(); await pg.waitForFunction(() => window.ITApp);
    ok(await pg.evaluate(id => !!ITApp.WORDS.find(w => w.id === id), st.id), '重新整理後還在');
    // 另一個分頁改了（模擬同步合併進來）
    await pg.evaluate(() => { const s = JSON.parse(localStorage.getItem('n5:progress')); const p = Object.keys(s.items).find(k => k.includes(':my:')).split(':my:')[0]; s.items[p + ':my:fromcloud'] = { s: 'queued', n: 0, w: {}, lv: 0, due: '', st: 0, t: Date.now() + 5, c: { w: 'fromcloud', zh: '雲端來的', p: 'o' } }; localStorage.setItem('n5:progress', JSON.stringify(s)); window.dispatchEvent(new StorageEvent('storage', { key: 'n5:progress' })); });
    ok(await pg.evaluate(() => !!ITApp.WORDS.find(w => w.word === 'fromcloud')), '別的分頁／雲端合併進來的字會出現');
    // 改名＋刪除
    await pg.evaluate(() => ITApp.showTab('lib')); await pg.evaluate(id => ITApp.openWord(id), st.id);
    await pg.click('[data-wa="edit"]'); await pg.waitForSelector('#myForm');
    await pg.fill('#my-zh', '鬍鬚；觸鬚'); await pg.click('#myForm [type=submit]'); await pg.waitForTimeout(400);
    ok(await pg.evaluate(id => ITApp.WORDS.find(w => w.id === id).zh === '鬍鬚；觸鬚' && ITApp.getRec(id).s === 'queued', st.id), '編輯後意思更新、進度保留');
    await pg.evaluate(id => ITApp.openWord(id), st.id); await pg.click('[data-wa="edit"]'); await pg.waitForSelector('#myDel');
    await pg.click('#myDel'); await pg.click('#myDel'); await pg.waitForTimeout(400);
    ok(await pg.evaluate(id => !ITApp.WORDS.find(w => w.id === id) && !ITApp.getRec(id).c && ITApp.getRec(id).t > 0, st.id), '刪除後不見了，留下帶時間的空白紀錄');
    // 版面：表單不能比螢幕寬
    await pg.click('#addMine'); await pg.waitForSelector('#myForm');
    ok(await pg.evaluate(() => document.documentElement.scrollWidth <= innerWidth && [...document.querySelectorAll('#myForm input, #myForm textarea, #myForm select, #myForm button')].every(x => { const r = x.getBoundingClientRect(); return r.left >= 0 && r.right <= innerWidth && r.height >= 40; })), '手機寬度：表單沒有超出螢幕，按鈕夠大');
    ok(!errs.length, '沒有 JavaScript 錯誤' + (errs.length ? '：' + errs.join(' | ') : ''));
    await ctx.close();
  }
  await br.close(); srv.close();
  console.log(bad ? bad + ' 項失敗' : '全部通過'); process.exit(bad ? 1 : 0);
})().catch(e => { console.error(e); process.exit(1); });
