// 用真的瀏覽器測「文法小提醒＋題目靠下」（shared/gram-tip.js）：node n5src/tip-e2e.js n5work
// 需要 playwright 和 Chrome（不在 test-all.js 裡）。會留下 shot-tip-*.png
let chromium; try { ({ chromium } = require('playwright')); } catch (e) { ({ chromium } = require('/opt/npm-tools/node_modules/playwright')); } const http=require('http'),fs=require('fs'),path=require('path');
const ROOT=path.resolve(process.argv[2]||'n5work');let bad=0;const ok=(c,m)=>{console.log((c?'✓ ':'✗ ')+m);if(!c)bad++;};
const srv=http.createServer((q,r)=>{const f=path.join(ROOT,decodeURIComponent(q.url.split('?')[0]));fs.readFile(f,(e,d)=>{if(e){r.writeHead(404);return r.end();}r.writeHead(200,{'content-type':f.endsWith('.html')?'text/html; charset=utf-8':'text/javascript'});r.end(d);});});
(async()=>{await new Promise(r=>srv.listen(0,r));const base='http://127.0.0.1:'+srv.address().port+'/';
const br=await chromium.launch({args:['--no-sandbox']});
for (const [L,file,pre,vw,vh,theme] of [['ja','index.html','n5',385,827,'dark'],['it','it.html','it',360,740,'light'],['ru','ru.html','ru',412,915,'light']]) {
const ctx=await br.newContext({viewport:{width:vw,height:vh},deviceScaleFactor:2,isMobile:true,hasTouch:true});await ctx.route(/^https:\/\//,r=>r.abort());
await ctx.addInitScript(([l,pre,theme])=>{if(!localStorage.getItem('langs:last')){localStorage.setItem('langs:last',JSON.stringify(l));localStorage.setItem('langs:v1',JSON.stringify({active:[l],max:2,lock:true,note:''}));localStorage.setItem(pre+':toured','1');localStorage.setItem('n5:settings',JSON.stringify({pop:'off',theme}));localStorage.setItem(pre+':ui',JSON.stringify({tab:'card',cardSrc:'new'}));}},[L,pre,theme]);
const pg=await ctx.newPage();const errs=[];pg.on('pageerror',e=>errs.push(e.message));
await pg.goto(base+file);await pg.waitForSelector('#tab-card [data-a="queue"]');await pg.waitForTimeout(400);
const m=async(tag)=>{const r=await pg.evaluate(()=>{const t=document.querySelector('.tab:not([hidden])');const kids=[...t.children].filter(x=>!x.classList.contains('gtip-slot'));const last=kids[kids.length-1].getBoundingClientRect();const bar=document.querySelector('.tabbar').getBoundingClientRect();const s=document.querySelector('.tab:not([hidden]) .gtip-slot');return {gapBottom:Math.round(bar.top-last.bottom),slot:s&&!s.hidden?Math.round(s.offsetHeight):0,tip:!!(s&&s.querySelector('.gtip')),full:!!(s&&s.querySelector('.gtip-ex')),scroll:document.documentElement.scrollHeight>innerHeight};});ok(r.gapBottom>=20&&r.gapBottom<=60&&!r.scroll,`${L} ${tag}：題目貼在下面（離底部分頁 ${r.gapBottom}px）、不用捲動`);ok(r.slot>0,`${L} ${tag}：上面空出 ${r.slot}px${r.tip?'，放了文法小提醒'+(r.full?'（含例句）':'（精簡）'):'（放不下提醒）'}`);await pg.screenshot({path:`shot-tip-${L}-${tag}.png`});return r;};
await m('card');
for(let i=0;i<4;i++){await pg.click('#tab-card [data-a="queue"]');await pg.waitForTimeout(150);}
await m('card2');
await pg.click('[data-tab="mc"]');await pg.waitForSelector('#mcq .opt');await pg.waitForTimeout(300);await m('mc');
const y0=await pg.evaluate(()=>document.querySelector('#mcq .opt').getBoundingClientRect().top);
await pg.click('#mcq .opt >> nth=0');await pg.waitForTimeout(300);
const y1=await pg.evaluate(()=>document.querySelector('#mcq .opt').getBoundingClientRect().top);
ok(true,`${L} 單選答完：選項位移 ${Math.round(y1-y0)}px（答錯時會往下捲出「下一題」）`);
await pg.click('[data-tab="fill"]');await pg.waitForSelector('#fillIn');await pg.waitForTimeout(300);await m('fill');
ok(!errs.length,`${L} 沒有錯誤訊息`+(errs.length?'：'+errs.join(' | '):''));
await ctx.close();}
await br.close();srv.close();console.log(bad?`✗ ${bad} 項失敗`:'全部通過');process.exit(bad?1:0);})();
