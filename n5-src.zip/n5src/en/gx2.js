/* 英文 B2 文法的範例拆解與練習題（2）：比較、被動與子句、假設、連接詞 */
(function (G) {
  const EN = G.EN || (G.EN = {});
  EN.GX = Object.assign(EN.GX || {}, {
    // ---------- 第 5 關：比較 ----------
    "compar": {
      ex: [["This flat is bigger than mine, but it's the most expensive.", "這間公寓比我的大，但它是最貴的。", [["This", "這間"], ["flat", "公寓"], ["is", "是"], ["bigger", "更大"], ["than", "比"], ["mine", "我的"], [",", ""], ["but", "但是"], ["it's", "它是"], ["the", "（最）"], ["most", "最"], ["expensive", "貴的"]],
        ["短的形容詞加 -er／-est：big → bigger → the biggest。", "長的形容詞用 more／the most：the most expensive。"],
        "一兩個音節加 -er，三個音節以上用 more；比較用 than，最高級前面加 the。"]],
      q: [["She's ___ than her brother.", "taller", ["more tall", "tallest"], "她比她哥哥高。", "短形容詞加 -er。"],
        ["It's the ___ film I've ever seen.", "worst", ["baddest", "worse"], "這是我看過最爛的電影。", "bad → worse → the worst。"],
        ["This test is ___ difficult than the last one.", "more", ["most", "much"], "這次考試比上次難。", "長形容詞用 more … than。"]]
    },
    "so-such": {
      ex: [["It was such a good film that I watched it twice.", "那部電影好看到我看了兩次。", [["It", "它"], ["was", "是"], ["such", "這麼"], ["a", "一部"], ["good", "好的"], ["film", "電影"], ["that", "以至於"], ["I", "我"], ["watched", "看"], ["it", "它"], ["twice", "兩次"]],
        ["such ＋ (a) ＋ 形容詞 ＋ 名詞 ＋ that…", "so ＋ 形容詞 ＋ that…：The film was so good that…"],
        "後面有名詞用 such，只有形容詞用 so；that 後面接「結果」。"]],
      q: [["The soup was ___ hot that I couldn't eat it.", "so", ["such", "such a"], "湯燙到我不能吃。", "只有形容詞用 so。"],
        ["She's ___ a kind person.", "such", ["so", "too"], "她真是個好人。", "形容詞 ＋ 名詞前用 such。"],
        ["We had ___ fun that we didn't want to leave.", "such", ["so", "such a"], "我們玩得太開心，都不想走了。", "fun 是不可數名詞：such fun（不加 a）。"]]
    },
    "too-enough": {
      ex: [["The coffee is too hot to drink, and I'm not old enough to vote.", "咖啡燙到不能喝，而我年紀還不夠投票。", [["The", "那杯"], ["coffee", "咖啡"], ["is", "是"], ["too", "太"], ["hot", "燙"], ["to", "（以致不能）"], ["drink", "喝"], [",", ""], ["and", "而且"], ["I'm", "我"], ["not", "不"], ["old", "老"], ["enough", "足夠"], ["to", "（去）"], ["vote", "投票"]],
        ["too ＋ 形容詞＝太…（有問題）。", "形容詞 ＋ enough＝夠…；enough 放在形容詞後面。"],
        "too 放形容詞前面，enough 放形容詞後面、名詞前面：old enough、enough money。"]],
      q: [["He isn't ___ to reach the shelf.", "tall enough", ["enough tall", "too tall"], "他不夠高，搆不到架子。", "形容詞 ＋ enough。"],
        ["We don't have ___ time.", "enough", ["too", "too much enough"], "我們時間不夠。", "名詞前面放 enough。"],
        ["This bag is ___ heavy for me to carry.", "too", ["enough", "so"], "這個包包太重，我拿不動。", "太…（有問題）用 too。"]]
    },
    "degree": {
      ex: [["The exam was fairly easy, but the last part was extremely hard.", "考試還算簡單，但最後一部分非常難。", [["The", "那場"], ["exam", "考試"], ["was", "是"], ["fairly", "還算"], ["easy", "簡單"], [",", ""], ["but", "但是"], ["the", "那個"], ["last", "最後的"], ["part", "部分"], ["was", "是"], ["extremely", "極度"], ["hard", "難"]],
        ["fairly＝還算（輕）、quite／rather＝相當、extremely＝非常非常。"],
        "程度由弱到強：a bit → fairly → quite／rather → very → extremely。rather 常帶「比預期更…」的意思。"]],
      q: [["It's ___ cold today — wear a coat.", "rather", ["rather a", "fairly a"], "今天相當冷，穿件外套。", "rather＋形容詞＝相當（常是不好的方面）。"],
        ["The view was ___ beautiful.", "absolutely", ["very much", "fairly very"], "景色美極了。", "beautiful 很強時可以用 absolutely。"],
        ["I'm ___ tired, but I can keep going.", "a bit", ["extremely", "absolutely"], "我有點累，但還能繼續。", "還能繼續，表示只是一點點：a bit。"]]
    },
    // ---------- 第 6 關：被動和子句 ----------
    "passive": {
      ex: [["The bridge was built in 1990.", "這座橋是 1990 年建的。", [["The", "那座"], ["bridge", "橋"], ["was", "被"], ["built", "建造"], ["in", "在"], ["1990", "1990"]],
        ["be ＋ 過去分詞＝被動。", "重點是橋，不是誰蓋的，所以用被動。"],
        "不知道、或不重要是誰做的時候，用被動：be 照時態變，後面接過去分詞。"]],
      q: [["English ___ all over the world.", "is spoken", ["speaks", "is speaking"], "全世界都說英文。", "現在式被動：is ＋ 過去分詞。"],
        ["The window ___ last night.", "was broken", ["broke by", "has broken"], "窗戶昨晚被打破了。", "過去式被動：was ＋ 過去分詞。"],
        ["The results will ___ tomorrow.", "be announced", ["announced", "being announced"], "結果明天公布。", "未來被動：will be ＋ 過去分詞。"]]
    },
    "have-done": {
      ex: [["I had my hair cut yesterday.", "我昨天去剪了頭髮。", [["I", "我"], ["had", "讓（別人）"], ["my", "我的"], ["hair", "頭髮"], ["cut", "剪"], ["yesterday", "昨天"]],
        ["have ＋ 東西 ＋ 過去分詞＝請別人幫你做。", "不是自己剪，是理髮師剪。"],
        "I cut my hair＝我自己剪；I had my hair cut＝我請人剪。"]],
      q: [["We're having our kitchen ___ .", "painted", ["paint", "painting"], "我們正在請人油漆廚房。", "have ＋ 東西 ＋ 過去分詞。"],
        ["You should get your eyes ___ .", "tested", ["test", "to test"], "你該去檢查眼睛。", "get ＋ 東西 ＋ 過去分詞，跟 have 一樣。"],
        ["She ___ her car repaired last week.", "had", ["made", "did"], "她上週把車送修了。", "請人做：had ＋ 東西 ＋ 過去分詞。"]]
    },
    "relative": {
      ex: [["The woman who lives next door is a doctor.", "住隔壁的那位女士是醫生。", [["The", "那位"], ["woman", "女士"], ["who", "（她）"], ["lives", "住"], ["next", "旁邊"], ["door", "門"], ["is", "是"], ["a", "一位"], ["doctor", "醫生"]],
        ["who lives next door 整段用來說明是哪一位女士。", "中文把說明放前面（住隔壁的女士），英文放後面。"],
        "人用 who，東西用 which，兩者都可以用 that；「…的」所有格用 whose。"]],
      q: [["This is the book ___ I told you about.", "that", ["who", "whose"], "這就是我跟你說的那本書。", "東西用 that 或 which。"],
        ["I have a friend ___ father is a pilot.", "whose", ["who", "which"], "我有個朋友，他爸爸是機師。", "「他的爸爸」用 whose。"],
        ["The man ___ called you is my boss.", "who", ["which", "whose"], "打給你的那個人是我老闆。", "人用 who。"]]
    },
    "reported": {
      ex: [["She said that she was tired.", "她說她很累。", [["She", "她"], ["said", "說"], ["that", "（說）"], ["she", "她"], ["was", "是"], ["tired", "累的"]],
        ["她原本說 I am tired，轉述時時態往前退一格：am → was。", "I 也要改成 she。"],
        "間接引述：時態往過去退（is → was、will → would、has done → had done），人稱也要換。"]],
      q: [["He said he ___ come tomorrow.", "would", ["will", "is"], "他說他明天會來。", "will 轉述時變 would。"],
        ["She told me she ___ already eaten.", "had", ["has", "have"], "她跟我說她已經吃過了。", "has eaten 轉述時變 had eaten。"],
        ["They ___ me that the shop was closed.", "told", ["said", "said to"], "他們告訴我店關了。", "後面直接接人用 told；said 後面不直接接人。"]]
    },
    "rep-q": {
      ex: [["Do you know where the station is?", "你知道車站在哪嗎？", [["Do", "（問句）"], ["you", "你"], ["know", "知道"], ["where", "哪裡"], ["the", "那個"], ["station", "車站"], ["is", "在"]],
        ["直接問：Where is the station?", "間接問：…where the station is，主詞在前、動詞在後，不倒裝。"],
        "問句包在另一句裡面時，順序變回直述句：where it is，不是 where is it。"]],
      q: [["Could you tell me what time ___ ?", "it is", ["is it", "does it"], "可以告訴我現在幾點嗎？", "間接問句不倒裝。"],
        ["I wonder ___ he'll come.", "if", ["that", "does"], "不知道他會不會來。", "是非問句轉間接，用 if／whether。"],
        ["Do you know where ___ ?", "she lives", ["does she live", "lives she"], "你知道她住哪嗎？", "不倒裝，也不用 does。"]]
    },
    // ---------- 第 7 關：假設 ----------
    "cond1": {
      ex: [["If it rains, we'll stay at home.", "如果下雨，我們就待在家。", [["If", "如果"], ["it", "（天氣）"], ["rains", "下雨"], [",", ""], ["we'll", "我們會"], ["stay", "待"], ["at", "在"], ["home", "家"]],
        ["if 子句用現在式（rains），不用 will。", "結果用 will ＋ 原形。"],
        "真的可能發生的事：If ＋ 現在式, will ＋ 原形。"]],
      q: [["If you ___ hard, you'll pass.", "study", ["will study", "studied"], "如果你用功，就會及格。", "if 子句用現在式。"],
        ["If I see him, I ___ tell him.", "'ll", ["would", "am"], "如果我看到他，我會告訴他。", "結果用 will。"],
        ["We'll miss the bus if we ___ hurry.", "don't", ["won't", "didn't"], "如果不快點，我們會錯過公車。", "if 子句否定用 don't。"]]
    },
    "cond2": {
      ex: [["If I had more money, I would travel.", "如果我有更多錢，我就會去旅行。", [["If", "如果"], ["I", "我"], ["had", "有（假設）"], ["more", "更多"], ["money", "錢"], [",", ""], ["I", "我"], ["would", "會"], ["travel", "旅行"]],
        ["現在不是真的（我沒有更多錢），所以用過去式 had。", "結果用 would ＋ 原形。"],
        "跟現在事實相反的想像：If ＋ 過去式, would ＋ 原形。"]],
      q: [["If I ___ you, I'd take the job.", "were", ["am", "will be"], "如果我是你，我會接這份工作。", "假設語氣的 be 常用 were。"],
        ["What ___ you do if you won the lottery?", "would", ["will", "did"], "如果你中樂透，你會做什麼？", "結果用 would。"],
        ["If he ___ harder, he'd get better marks.", "worked", ["works", "would work"], "如果他更努力，成績就會更好。", "if 子句用過去式。"]]
    },
    "cond3": {
      ex: [["If I had known, I would have helped.", "如果我早知道，我就會幫忙了。", [["If", "如果"], ["I", "我"], ["had", "（過去完成）"], ["known", "知道"], [",", ""], ["I", "我"], ["would", "會"], ["have", "（完成）"], ["helped", "幫忙"]],
        ["過去已經發生，不能改了：if 子句用 had ＋ 過去分詞。", "結果用 would have ＋ 過去分詞。"],
        "跟過去事實相反（後悔、可惜）：If ＋ had done, would have done。"]],
      q: [["If we had left earlier, we ___ the train.", "would have caught", ["would catch", "had caught"], "如果我們早點出門，就趕上火車了。", "結果用 would have ＋ 過去分詞。"],
        ["If she ___ the ad, she wouldn't have applied.", "hadn't seen", ["didn't see", "wouldn't see"], "如果她沒看到廣告，就不會應徵了。", "if 子句用 had done。"],
        ["I would have called you if I ___ your number.", "had had", ["had", "would have"], "如果我有你的號碼，我就打給你了。", "過去的「有」：had had。"]]
    },
    "wish": {
      ex: [["I wish I lived near the sea.", "真希望我住在海邊。", [["I", "我"], ["wish", "希望"], ["I", "我"], ["lived", "住（假設）"], ["near", "靠近"], ["the", "那片"], ["sea", "海"]],
        ["現在其實沒住海邊，所以 wish 後面用過去式 lived。"],
        "wish 後面跟現在相反用過去式，跟過去相反用 had done：I wish I had studied。"]],
      q: [["I wish I ___ speak French.", "could", ["can", "will"], "真希望我會說法文。", "現在不會 → wish ＋ could。"],
        ["I wish I ___ that.", "hadn't said", ["didn't say", "don't say"], "真希望我沒說那句話。", "後悔過去 → wish ＋ had done。"],
        ["If only it ___ so cold!", "weren't", ["isn't", "won't be"], "要是沒這麼冷就好了！", "if only 跟 wish 一樣，現在相反用過去式。"]]
    },
    "cond-link": {
      ex: [["You won't pass unless you study.", "除非你用功，否則不會及格。", [["You", "你"], ["won't", "不會"], ["pass", "及格"], ["unless", "除非"], ["you", "你"], ["study", "用功"]],
        ["unless＝if … not（除非）。", "unless 後面跟 if 一樣用現在式。"],
        "unless 除非、as long as 只要、provided that 前提是、in case 以防萬一。"]],
      q: [["Take an umbrella ___ it rains.", "in case", ["unless", "as long as"], "帶把傘以防下雨。", "以防萬一用 in case。"],
        ["You can borrow it ___ you bring it back.", "as long as", ["unless", "in case"], "只要你會還，就可以借。", "只要＝as long as。"],
        ["I won't go ___ you come with me.", "unless", ["if", "in case"], "除非你陪我，不然我不去。", "除非＝unless。"]]
    },
    "past-modal": {
      ex: [["You should have told me; he must have forgotten.", "你應該早點告訴我；他一定是忘了。", [["You", "你"], ["should", "應該"], ["have", "（完成）"], ["told", "告訴"], ["me", "我"], [";", ""], ["he", "他"], ["must", "一定"], ["have", "（完成）"], ["forgotten", "忘了"]],
        ["should have done＝當初應該做（但沒做）。", "must have done＝推測過去一定是…。"],
        "情態動詞 ＋ have ＋ 過去分詞＝講過去：後悔 should have，推測 must／might／can't have。"]],
      q: [["I ___ have studied more. I failed.", "should", ["must", "can"], "我當初應該多念一點，我考砸了。", "後悔用 should have。"],
        ["She's not here. She ___ have left already.", "must", ["should", "mustn't"], "她不在，一定已經走了。", "很確定的推測用 must have。"],
        ["He ___ have seen us — it was too dark.", "can't", ["mustn't", "shouldn't"], "他不可能看到我們，太暗了。", "確定沒有用 can't have。"]]
    },
    // ---------- 第 8 關：連接 ----------
    "contrast": {
      ex: [["Although it was raining, we went out. However, we got wet.", "雖然在下雨，我們還是出門了。不過，我們淋濕了。", [["Although", "雖然"], ["it", "（天氣）"], ["was", "（過去）"], ["raining", "下雨"], [",", ""], ["we", "我們"], ["went", "去"], ["out", "外面"], [".", ""], ["However", "不過"], [",", ""], ["we", "我們"], ["got", "變得"], ["wet", "濕的"]],
        ["although 後面接一個完整的句子。", "however 放在新句子的開頭，後面加逗號。", "despite 後面接名詞或 -ing：despite the rain。"],
        "英文不說「雖然…但是…」兩個一起：用了 although 就不加 but。"]],
      q: [["___ the rain, we enjoyed the trip.", "Despite", ["Although", "However"], "雖然下雨，我們還是玩得很開心。", "後面是名詞（the rain），用 despite。"],
        ["___ she was tired, she kept working.", "Although", ["Despite", "However"], "雖然她很累，還是繼續工作。", "後面是完整句子，用 although。"],
        ["It's expensive. ___ , it's worth it.", "However", ["Although", "Despite"], "這很貴。不過，很值得。", "新句子開頭轉折用 however。"]]
    },
    "purpose": {
      ex: [["I'm saving money in order to buy a car.", "我在存錢，為了買車。", [["I'm", "我"], ["saving", "存"], ["money", "錢"], ["in", "（為了）"], ["order", "（為了）"], ["to", "（去）"], ["buy", "買"], ["a", "一台"], ["car", "車"]],
        ["in order to ＋ 原形＝為了…（比較正式的 to）。", "so that ＋ 句子：so that I can buy a car。"],
        "說目的：to／in order to ＋ 原形，或 so that ＋ 完整句子。"]],
      q: [["I left early ___ I wouldn't be late.", "so that", ["in order to", "for"], "我提早出門，這樣才不會遲到。", "後面是完整句子，用 so that。"],
        ["She studies hard in order ___ pass.", "to", ["for", "that"], "她努力念書，為了及格。", "in order to ＋ 原形。"],
        ["I went to the shop ___ some milk.", "to buy", ["for buy", "for buying"], "我去商店買牛奶。", "目的用 to ＋ 原形，不用 for ＋ 動詞。"]]
    },
    "cause": {
      ex: [["The flight was cancelled due to the storm. Therefore, we stayed.", "因為暴風雨，班機取消了。所以我們留下來了。", [["The", "那班"], ["flight", "班機"], ["was", "被"], ["cancelled", "取消"], ["due", "（因為）"], ["to", "（因為）"], ["the", "那場"], ["storm", "暴風雨"], [".", ""], ["Therefore", "所以"], [",", ""], ["we", "我們"], ["stayed", "留下"]],
        ["due to／because of ＋ 名詞。", "because ＋ 完整句子。", "therefore＝所以，放在新句子開頭。"],
        "原因是名詞用 because of／due to，是句子用 because；結果用 so 或 therefore。"]],
      q: [["We stayed inside ___ the rain.", "because of", ["because", "therefore"], "因為下雨我們待在室內。", "後面是名詞，用 because of。"],
        ["She was ill. ___ , she missed the exam.", "Therefore", ["Because", "Due to"], "她生病了，因此錯過了考試。", "新句子開頭說結果用 therefore。"],
        ["I'm late ___ the bus didn't come.", "because", ["because of", "due to"], "我遲到是因為公車沒來。", "後面是完整句子，用 because。"]]
    },
    "markers": {
      ex: [["Actually, I don't agree. Anyway, let's move on.", "其實我不同意。不管怎樣，我們繼續吧。", [["Actually", "其實"], [",", ""], ["I", "我"], ["don't", "不"], ["agree", "同意"], [".", ""], ["Anyway", "不管怎樣"], [",", ""], ["let's", "我們（來）"], ["move", "移動"], ["on", "繼續"]],
        ["actually＝其實（不是「實際上」那麼重）。", "anyway＝話說回來、不管怎樣，用來換話題。"],
        "說話時的小轉折：actually 其實、anyway 總之、by the way 對了、to be honest 老實說。"]],
      q: [["___ , have you seen my keys?", "By the way", ["Actually not", "Therefore"], "對了，你有看到我的鑰匙嗎？", "突然換話題用 by the way。"],
        ["___ , I didn't like the film much.", "To be honest", ["By the way", "In case"], "老實說，我不太喜歡那部電影。", "老實說＝to be honest。"],
        ["It was boring. ___ , it's over now.", "Anyway", ["Actually", "However that"], "很無聊。總之，已經結束了。", "總之、話說回來用 anyway。"]]
    }
  });
})(typeof window !== 'undefined' ? window : globalThis);
