/* 英文頁的設定 */
window.LANGCFG = {
  id: 'en', name: '英文', short: '英', level: 'B2', glyph: 'Aa', tts: 'en-US',
  ttsSample: 'Hello! How are you doing today? I hope you have a great day.',
  voiceNames: /samantha|alex|ava|allison|susan|tom|zoe|evan|nathan|joelle|aaron|nicky|daniel|karen|moira|serena|kate|oliver|arthur|martha|google us|google uk|jenny|guy|aria|davis|sonia|ryan|libby/,
  noVoiceHelp: '這台裝置沒有英文語音。iPhone／iPad：到「設定 → 輔助使用 → 朗讀內容 → 聲音 → 英文」下載語音。Android：到「文字轉語音」設定下載英文。',
  persons: ['原形', '過去式', '過去分詞'],
  sayPerson: () => '',
  impPersons: [],
  pastLabel: '過去式',
  artLabel: '介係詞與搭配',
  accentNote: '',
  gramPh: '搜尋文法：假設語氣、被動、used to…',
  posZh: { v: '動詞', 'v-irr': '不規則動詞', 'v-ph': '片語動詞', expr: '片語・搭配', conj: '連接詞', adv: '副詞', prep: '介係詞' },
  verbTags: c => [c.type === 'v-ph' ? '片語動詞' : c.irregular ? '不規則動詞' : '規則動詞'].concat(c.irregular ? [c.base + ' – ' + c.past + ' – ' + c.pp] : [], c.sep ? ['可以拆開（' + c.head + ' it ' + c.rest + '）'] : []),
  ruleShort: { 'r-irr': '不規則動詞', 'r-ph': '片語動詞', 'r-adj': '比較級', 'r-noun': '名詞複數', 'r-form': '詞性變化', 'r-ed': '-ed／-ing 形容詞' },
  letterAsIs: true, letterTitle: '音標', letterNameLabel: '例字',
  letterGroups: [
    { title: '短母音（7 個）', from: 0, to: 7 },
    { title: '長母音（5 個）', from: 7, to: 12 },
    { title: '雙母音（8 個）', from: 12, to: 20 },
    { title: '容易唸錯的子音（12 個）', from: 20, to: 32 }
  ],
  letterNote: '點音標看發音和例字。英文拼字和發音的關係不固定，查字典時看音標最準。這裡用美式發音；英式最明顯的差別是 car、water 的 r 不捲舌，hot 的 o 唸成圓唇的 /ɒ/。'
};
