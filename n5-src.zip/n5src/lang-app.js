/* 語言頁（義大利文、西班牙文、德文、俄文…）：放在日文 N5 App 裡
   語言專屬的文字和設定放在 window.LANGCFG，資料和變化引擎放在 window.LX
   - 介面、音效、下拉選單、間隔複習規則都跟日文頁一樣
   - 進度存在同一份 n5:progress（id 以語言代碼開頭，例如 it:、es:），所以 Google 同步、每日目標直接共用
   - 外觀、音效、震動、每輪題數、單字意思語言這些設定和日文頁共用（n5:settings） */
(function () {
'use strict';
const IT = window.LX || window.IT;
const LC = window.LANGCFG;
const LP = LC.id + ':';
// 名詞性別的名稱（德文多一個中性），語言包沒給就用陽／陰
const GEN = IT.GENDER || { m: ['陽性', '陽'], f: ['陰性', '陰'] };
const genOf = g => GEN[g] || GEN.f || ['', ''];
// 英文這類沒有名詞性別的語言：LX.GENDER 給空物件，就不顯示性別
const hasGen = g => !!GEN[g];

// ================= 基本工具 =================
const $ = (s, r = document) => r.querySelector(s);
const $$ = (s, r = document) => [...r.querySelectorAll(s)];
const GOAL = 20;

// ================= 資料 =================
const POS_ZH = { n: '名詞', adj: '形容詞', adv: '副詞', prep: '介係詞', art: '冠詞', pron: '代名詞', conj: '連接詞', num: '數字', det: '限定詞', q: '疑問詞', expr: '常用語', 'v-are': '動詞 -are', 'v-ere': '動詞 -ere', 'v-ire': '動詞 -ire', 'v-isc': '動詞 -ire（-isc-）', 'v-irr': '不規則動詞', ...(LC.posZh || {}) };
const isVerbPos = p => /^v/.test(p);
const pgOf = p => isVerbPos(p) ? 'v' : (p === 'n' || p === 'adj' ? p : 'o');
const WORDS = IT.W.map(e => {
  const pos = e[1];
  const title = pos === 'n' ? IT.nounForms(e).sg : e[0];
  return { id: LP + e[0] + '|' + pos, e, word: e[0], title, pos, pg: pgOf(pos), zh: e[4], en: e[5], sent: e[6], sentZh: e[7], ans: e[8], kind: 'w' };
});
const WMAP = Object.fromEntries(WORDS.map(w => [w.id, w]));
const ALL_IDS = WORDS.map(w => w.id);
const LOOK = IT.getLookup();
const idOfEntry = e => LP + e[0] + '|' + e[1];
// 字卡順序：常用語先，再讓名詞、動詞、形容詞、其他輪流出現
const ORDER = (() => {
  const g = { expr: [], n: [], v: [], adj: [], o: [] };
  WORDS.forEach(w => (w.pos === 'expr' ? g.expr : g[w.pg]).push(w));
  const out = g.expr.slice(), lists = [g.n, g.v, g.adj, g.o, g.n, g.v], idx = lists.map(() => 0), used = new Set();
  let added = true;
  while (added) {
    added = false;
    lists.forEach((L, i) => {
      while (idx[i] < L.length && used.has(L[idx[i]].id)) idx[i]++;
      if (idx[i] < L.length) { const w = L[idx[i]++]; used.add(w.id); out.push(w); added = true; }
    });
  }
  return out;
})();

// ================= 進度與設定（和日文頁共用） =================
let S = store.get('n5:progress', null);
if (!S || typeof S !== 'object' || !S.items) S = { items: {}, days: {} };
S.days = S.days || {};
const SET = Object.assign({ vib: 'on', sfx: 'on', round: 20, recent: 'd1', mean: 'zh', theme: 'system', rate: 0.9 }, store.get('n5:settings', {}));
UIKit.bind({ SET });   // ui.js 的音效、震動、下拉選單用這頁的設定
const ISET = Object.assign({ voice: '' }, store.get(LP + 'settings', {}));
const UI = Object.assign({ tab: 'card', pronSec: 'abc', pronMode: 'listen', mcMode: 'it2zh', mcSrc: 'learn', fillSrc: 'learn', cardSrc: 'new', pos: 'all', gramSel: '', gramQ: '', gramView: 'path' }, store.get(LP + 'ui', {}));
// 每次都重新讀一次共用設定再寫回，避免蓋掉日文頁剛改的值
const saveSet = () => { const cur = store.get('n5:settings', {}); store.set('n5:settings', Object.assign(cur, SET)); };
const saveISet = () => store.set(LP + 'settings', ISET);
const saveUI = () => store.set(LP + 'ui', UI);
const saveLocal = () => store.set('n5:progress', S);
// 別的分頁（日文頁）改了進度時，先合併再寫，不會互相覆蓋
function reloadShared() { const cur = store.get('n5:progress', null); if (cur && cur.items) S = mergeState(S, cur); }

const getRec = id => S.items[id] || blankRec();
function putRec(id, rec) { reloadShared(); S.items[id] = rec; saveLocal(); Cloud.schedule(); }
function touch(id, patch) {
  const old = getRec(id), now = Date.now();
  const r = Object.assign(JSON.parse(JSON.stringify(old)), patch, { t: now });
  if (patch.s === 'queued' && old.s !== 'queued' && old.s !== 'learned') r.q = now;
  else if (!r.q && (old.s === 'queued' || old.s === 'learned') && old.t) r.q = old.t;
  putRec(id, r);
}
// 作答規則 applyAnswer、複習間隔、出題 pickRound、合併 mergeState、備份碼：在 core.js（和日文頁共用）
function bumpDay() {
  reloadShared();
  const d = today();
  SyncDays.bump(S, d);   // 加一題（只留最近 90 天）
  saveLocal(); renderGoal(); Cloud.schedule();   // 只有題數變了（文法練習等）也要同步
  if (S.days[d] === GOAL) toast(`今天的 ${GOAL} 題完成了！`, true);
}
function record(w, mode, correct, source) {
  reloadShared();
  const old = getRec(w.id), now = Date.now();
  const rec = applyAnswer(old, mode, correct, source, today(), now);
  if (!rec.q && (rec.s === 'queued' || rec.s === 'learned')) rec.q = (old.s === 'queued' || old.s === 'learned') && old.t ? old.t : now;
  S.items[w.id] = rec;
  bumpDay();
  Cloud.schedule();
}

// ================= 語音 =================
/*@include shared/voice.js*/

// ================= 顯示工具 =================
function revealAboveTabbar(el) {
  requestAnimationFrame(() => {
    const bar = $('.tabbar'), r = el.getBoundingClientRect();
    const lim = innerHeight - (bar ? bar.getBoundingClientRect().height : 0) - 12;
    if (r.bottom > lim) window.scrollBy({ top: r.bottom - lim, behavior: matchMedia('(prefers-reduced-motion: reduce)').matches ? 'auto' : 'smooth' });
  });
}
function meanText(zh, en) {
  if (SET.mean === 'en' && en) return `<span lang="en">${esc(en)}</span>`;
  if (SET.mean === 'both' && en) return `${esc(zh)} <span class="en" lang="en">${esc(en)}</span>`;
  return esc(zh);
}
const meanW = w => meanText(w.zh, w.en);
const meanPlain = w => SET.mean === 'en' && w.en ? w.en : SET.mean === 'both' && w.en ? `${w.zh} / ${w.en}` : w.zh;
function applyTheme() {
  if (SET.theme !== 'light' && SET.theme !== 'dark') { SET.theme = matchMedia('(prefers-color-scheme: dark)').matches ? 'dark' : 'light'; saveSet(); }
  document.documentElement.setAttribute('data-theme', SET.theme);
  const b = $('#themeBtn');
  const [ic, lb] = { light: [ICON.sun, '外觀：淺色'], dark: [ICON.moon, '外觀：深色'] }[SET.theme];
  b.innerHTML = ic; b.setAttribute('aria-label', lb + '（點一下切換）'); b.title = lb;
  const m = $('meta[name="theme-color"]'); if (m) m.setAttribute('content', SET.theme === 'dark' ? '#181e27' : '#ffffff');
}
function renderGoal() {
  const n = S.days[today()] || 0;
  $('#goalText').textContent = `今日 ${n}/${GOAL} 題${n >= GOAL ? ' ✓' : ''}`;
  $('#goalBar').style.width = Math.min(100, n / GOAL * 100) + '%';
}
// 名詞上方的性別小字（像日文的假名，可以在上方按鈕開關）
// 只在這個字一定是名詞、而且性別只有一種時才標；例句裡同形的其他詞性（德文 Sie、俄文 дома）不標
const GCACHE = new Map();
function genOfToken(form) {
  const k = IT.norm(form).toLowerCase();
  if (GCACHE.has(k)) return GCACHE.get(k);
  let g = null;
  const inf = (LOOK.get(k) || []).filter(x => !/的一部分/.test(x.desc || ''));
  if (inf.length && inf.every(x => x.idx >= 0 && IT.W[x.idx][1] === 'n')) {
    const gs = new Set(inf.map(x => IT.W[x.idx][2]));
    if (gs.size === 1) { const one = [...gs][0]; if (GEN[one]) g = one; }
  }
  if (g && LC.id === 'de' && !/^[A-ZÄÖÜ]/.test(form)) g = null; // 德文名詞一定大寫
  GCACHE.set(k, g);
  return g;
}
const genOn = () => SET.gender !== false;
function applyGen() {
  document.body.classList.toggle('hide-gen', !genOn());
  const b = $('#genBtn'); if (!b) return;
  b.setAttribute('aria-pressed', String(genOn()));
  b.title = '名詞上的性別：' + (genOn() ? '開' : '關');
}
// 句子：每個字都能點；ranges 是要標黃的範圍；blank 是挖空的位置；noGen 不標性別（考性別、格的題目）
function sentHTML(s, o = {}) {
  const ranges = o.ranges || [];
  const inR = i => ranges.some(r => i >= r[0] && i < r[1]);
  let pos = 0, out = '';
  for (const t of IT.tokenize(s)) {
    const start = pos; pos += t.t.length;
    if (o.blank && start === o.blank[0]) { out += o.blankHTML; continue; }
    if (o.blank && start > o.blank[0] && start < o.blank[1]) continue;
    if (!t.w) { out += esc(t.t); continue; }
    let tk = `<span class="tk" role="button" tabindex="0" data-w="${esc(t.t)}">${esc(t.t)}</span>`;
    const g = o.noGen ? null : genOfToken(t.t);
    if (g) tk = `<ruby class="gr">${tk}<rt class="gt g-${g}" aria-hidden="true">${esc(GEN[g][1])}</rt></ruby>`;
    out += inR(start) ? `<mark>${tk}</mark>` : tk;
  }
  return out;
}
function exampleBlock(w) {
  return `<div class="example"><div class="ex-row"><div class="sent" lang="${LC.id}">${sentHTML(w.sent)}</div>${iconPlay(w.sent, '播放例句')}</div><div class="zhline">${esc(w.sentZh)}</div></div>`;
}
// 很長的字（здравствуйте、Entschuldigung）縮小字級，避免在字中間斷行
const lenCls = t => { const n = String(t).replace(/[\u0300-\u036f]/g, '').length; return n > 14 ? ' xlong' : n > 10 ? ' long' : ''; };
const posBadge = w => `<button class="posbtn" data-word="${esc(w.id)}" aria-label="看「${esc(w.word)}」的詞性和變化">${esc(POS_ZH[w.pos])}${w.pos === 'n' && hasGen(w.e[2]) ? '・' + genOf(w.e[2])[1] : ''}<span aria-hidden="true">›</span></button>`;

// ================= 拉起式面板（點字、單字詳細、字母） =================
const Sheet = {
  el: null, back: null, prev: null,
  build() {
    this.back = document.createElement('div'); this.back.className = 'pk-back'; this.back.hidden = true;
    this.el = document.createElement('div'); this.el.className = 'pk'; this.el.hidden = true;
    this.el.setAttribute('role', 'dialog'); this.el.setAttribute('aria-modal', 'true');
    document.body.append(this.back, this.el);
    this.back.onclick = () => this.close();
    this.el.addEventListener('click', e => { if (e.target.closest('.pk-x')) this.close(); });
  },
  open(title, body, label) {
    if (!this.el) this.build();
    if (this.el.hidden) this.prev = document.activeElement;
    this.el.setAttribute('aria-label', label || title.replace(/<[^>]+>/g, ''));
    this.el.innerHTML = `<div class="pk-grab" aria-hidden="true"></div><div class="pk-top"><b>${title}</b><button class="pk-x" aria-label="關閉">${ICON.ng}</button></div><div class="sheet-body">${body}</div>`;
    this.back.hidden = false; this.el.hidden = false;
    requestAnimationFrame(() => { this.back.classList.add('in'); this.el.classList.add('in'); $('.pk-x', this.el).focus({ preventScroll: true }); });
    return this.el;
  },
  close() {
    if (!this.el || this.el.hidden) return;
    this.back.classList.remove('in'); this.el.classList.remove('in');
    setTimeout(() => { this.back.hidden = true; this.el.hidden = true; }, 180);
    if (this.prev && document.contains(this.prev)) try { this.prev.focus({ preventScroll: true }); } catch (e) {}
  },
  isOpen() { return this.el && !this.el.hidden; }
};
document.addEventListener('keydown', e => { if (e.key === 'Escape' && Sheet.isOpen()) { e.stopPropagation(); Sheet.close(); } }, true);

function openToken(form) {
  const k = IT.norm(form).toLowerCase();
  const infos = LOOK.get(k) || [];
  const nm = IT.NAMES[k];
  let body = '';
  if (nm) body += `<div class="an"><div class="grow"><b lang="${LC.id}">${esc(nm[0])}</b><div class="meta">${esc(nm[1])}</div></div></div>`;
  const seen = new Set();
  for (const x of infos) {
    const key = x.lemma + '|' + x.desc; if (seen.has(key)) continue; seen.add(key);
    const e = x.idx >= 0 ? IT.W[x.idx] : null;
    if (e) {
      const w = WMAP[idOfEntry(e)];
      body += `<div class="an tk-an"><div class="grow"><div class="tk-h"><b lang="${LC.id}">${esc(w.title)}</b><span class="pos">${esc(POS_ZH[w.pos])}</span></div>${x.desc ? `<div class="meta">${esc(x.desc)}</div>` : ''}<p class="mean-big tk-m">${meanW(w)}</p>
        <div class="tk-ex"><div class="grow"><div lang="${LC.id}">${esc(w.sent)}</div><div class="meta">${esc(w.sentZh)}</div></div>${iconPlay(w.sent, '播放例句')}</div>
        <button class="btn quiet tk-more" data-word="${esc(w.id)}">看完整${isVerbPos(w.pos) ? '變化表' : '說明'}</button></div></div>`;
    } else {
      const ex = IT.EXTRA_FORMS[k] || IT.EXTRA_LOOKUP[k];
      body += `<div class="an"><div class="grow"><b lang="${LC.id}">${esc(x.lemma)}</b><div class="meta">${esc(x.desc || (ex && ex[1]) || '')}</div></div></div>`;
    }
  }
  if (!infos.length && !nm) body += '<p class="meta">找不到這個字。</p>';
  Sheet.open('查字', `<div class="rowx tk-top"><div class="grow"><div class="w1" lang="${LC.id}">${esc(form)}</div></div>${iconPlay(form, '播放 ' + form)}</div>${body}`, form);
}
function conjTable(w, which) {
  const c = IT.conjugate(w.word, w.pos);
  const P = LC.persons;
  let rows;
  if (which === 'pres') rows = c.presentFull.map((f, i) => [P[i], f, LC.sayPerson(i) + ' ' + f]);
  else if (which === 'pass') { const PP = LC.pastPersons || P, SP = LC.sayPast || LC.sayPerson; rows = c.passato.map((f, i) => [PP[i], f, SP(i) + ' ' + f.split('/')[0]]); }
  else rows = c.imperative ? c.imperative.map((f, i) => [LC.impPersons[i], f, f.split('/')[0]]).filter(r => r[1]) : [];
  if (!rows.length) return `<p class="meta">${which === 'pass' ? '這個動詞通常不用完成式。' : '這個動詞沒有常用的命令式。'}</p>`;
  return `<table class="t"><tbody>${rows.map(([p, f, say]) => `<tr><td class="p">${esc(p)}</td><td class="f" lang="${LC.id}">${esc(f)}</td><td class="a">${iconPlay(say, '播放 ' + f)}</td></tr>`).join('')}</tbody></table>`;
}
function verbInfo(w) {
  const c = IT.conjugate(w.word, w.pos);
  const tags = LC.verbTags(c);
  return `<div class="row">${tags.map(t => `<span class="pos">${esc(t)}</span>`).join('')}</div>${c.note ? `<div class="meta">${esc(c.note)}</div>` : ''}`;
}
// 語言包自己提供的變化表（德文：名詞的格、形容詞比較級與詞尾）
function tableHTML(t, play) {
  const head = t.headPl || t.head;
  const cells = r => r.slice(1).map(x => `<td class="f" lang="${LC.id}">${esc(x)}</td>`).join('');
  const say = r => r.slice(1).filter(Boolean)[0] || '';
  let h = `<div class="scroll-x" style="flex-shrink:0"><table class="t">${head ? `<thead><tr>${head.map(x => `<th>${esc(x)}</th>`).join('')}${play ? '<th></th>' : ''}</tr></thead>` : ''}<tbody>${t.rows.map(r => `<tr><td class="p">${esc(r[0])}</td>${cells(r)}${play ? `<td class="a">${say(r) ? iconPlay(say(r), '播放 ' + say(r)) : ''}</td>` : ''}</tr>`).join('')}</tbody></table></div>`;
  if (t.more) h += tableHTML(t.more, false);
  if (t.note) h += `<div class="meta">${esc(t.note)}</div>`;
  return h;
}
function formsHTML(w) {
  const e = w.e;
  // 語言包的變化表：義、西沒有；德文給名詞、形容詞；俄文也給代名詞、限定詞（沒有就回傳 null，照下面的做法）
  if (IT.formsTable && (!isVerbPos(w.pos) || IT.VERB_TABLE)) { const t = IT.formsTable(e); if (t) return (isVerbPos(w.pos) ? verbInfo(w) : '') + tableHTML(t, true); }
  if (w.pos === 'n') {
    const f = IT.nounForms(e);
    let h = `<table class="t"><tbody><tr><td class="p">${f.plOnly ? '複數（只用複數）' : '單數'}</td><td class="f" lang="${LC.id}">${esc(f.sg)}</td><td class="a">${iconPlay(f.sg, '播放')}</td></tr>`;
    if (f.pl) h += `<tr><td class="p">複數</td><td class="f" lang="${LC.id}">${esc(f.pl)}</td><td class="a">${iconPlay(f.pl, '播放')}</td></tr>`;
    if (f.indef) h += `<tr><td class="p">一個</td><td class="f" lang="${LC.id}">${esc(f.indef + (f.indef.endsWith("'") ? '' : ' ') + e[0])}</td><td class="a"></td></tr>`;
    h += '</tbody></table>';
    if (f.plGender !== e[2]) h += `<div class="meta">注意：複數變成陰性（${esc(f.pl)}）。</div>`;
    return h;
  }
  if (w.pos === 'adj') {
    const f = IT.adjForms(e);
    return `<table class="t"><thead><tr><th></th><th>單數</th><th>複數</th></tr></thead><tbody><tr><td class="p">陽性</td><td class="f" lang="${LC.id}">${esc(f[0])}</td><td class="f" lang="${LC.id}">${esc(f[2])}</td></tr><tr><td class="p">陰性</td><td class="f" lang="${LC.id}">${esc(f[1])}</td><td class="f" lang="${LC.id}">${esc(f[3])}</td></tr></tbody></table>` +
      (e[3].split('/').length > 3 ? `<div class="meta">放在名詞前面的形：${esc(e[3].split('/').slice(3).join('、'))}</div>` : '');
  }
  if (isVerbPos(w.pos)) {
    return verbInfo(w) + `<div class="seg" role="group" aria-label="動詞時態"><button data-tense="pres" aria-pressed="true">${esc(IT.conjugate(w.word, w.pos).presTab || '現在式')}</button><button data-tense="pass" aria-pressed="false">過去式</button><button data-tense="imp" aria-pressed="false">命令式</button></div><div id="conj">${conjTable(w, 'pres')}</div>`;
  }
  if (e[3] && e[3] !== '-') return `<div>其他形：<span lang="${LC.id}">${esc(e[3].split('/').join('、'))}</span></div>`;
  return '';
}
const STATUS_TXT = { new: '未學', queued: '待考', learned: '已學會', excluded: '已排除' };
function openWord(id) {
  const w = WMAP[id]; if (!w) return;
  const r = getRec(id);
  const tags = [`<span class="st ${r.s}">${STATUS_TXT[r.s] || '未學'}</span>`];
  if (r.w && r.w.mc) tags.push(`<span class="st wr">單選${r.w.mc === 1 ? '錯題' : '錯題複習'}</span>`);
  if (r.w && r.w.fill) tags.push(`<span class="st wr">填空${r.w.fill === 1 ? '錯題' : '錯題複習'}</span>`);
  const dueTxt = r.s === 'learned' && r.due ? `<div class="meta">下次複習：${r.due.slice(5).replace('-', '/')}（第 ${(r.lv || 0) + 1} 級）</div>` : '';
  const btns = r.s === 'new' || r.s === 'excluded'
    ? `<div class="btnrow"><button class="btn known" data-wa="known">${ICON.ok}已經會了</button><button class="btn solid" data-wa="queue">列入考題</button></div>`
    : `<button class="btn quiet block" data-wa="reset">移回未學</button>`;
  const body = `<div class="rowx"><div class="grow"><div class="w1" lang="${LC.id}">${esc(w.title)}</div><div class="row" style="margin-top:6px"><span class="pos">${esc(POS_ZH[w.pos])}</span>${w.pos === 'n' && hasGen(w.e[2]) ? `<span class="pos ${w.e[2]}">${genOf(w.e[2])[0]}</span>` : ''}${tags.join('')}</div></div>${iconPlay(w.title, '播放單字')}</div>
    <p class="mean-big">${esc(w.zh)}</p><div class="meta" style="margin-top:-8px">${esc(w.en)}</div>
    ${formsHTML(w)}
    <div class="gp-title">例句</div>
    <div class="ex-row"><div class="sent sm" lang="${LC.id}">${sentHTML(w.sent)}</div>${iconPlay(w.sent, '播放例句')}</div><div class="zhline" style="margin-top:-6px">${esc(w.sentZh)}</div>
    ${dueTxt}${btns}`;
  const el = Sheet.open(esc(POS_ZH[w.pos]) + ' · 單字', body, w.word);
  $$('[data-tense]', el).forEach(b => b.onclick = () => { $$('[data-tense]', el).forEach(x => x.setAttribute('aria-pressed', String(x === b))); $('#conj', el).innerHTML = conjTable(w, b.dataset.tense); });
  $$('[data-wa]', el).forEach(b => b.onclick = () => {
    const a = b.dataset.wa;
    if (a === 'queue') { touch(id, { s: 'queued' }); toast('已列入考題'); }
    if (a === 'known') { const gap = SRS[1] + Math.floor(Math.random() * 8); touch(id, { s: 'learned', lv: 1, due: addDays(today(), gap) }); toast(`已標記為學會，${gap} 天後會再考一次`); }
    if (a === 'reset') { touch(id, { s: 'new', lv: 0, due: '', w: {} }); toast('已移回未學'); }
    Sheet.close(); deck = null; refreshPassive(true);
  });
}
document.addEventListener('click', e => {
  const say = e.target.closest('[data-say]');
  if (say) { e.preventDefault(); Voice.speak(say.dataset.say); return; }
  const tk = e.target.closest('.tk[data-w]');
  if (tk && !tk.closest('.opt')) { e.preventDefault(); openToken(tk.dataset.w); return; }
  const wd = e.target.closest('[data-word]');
  if (wd) { e.preventDefault(); openWord(wd.dataset.word); }
});
document.addEventListener('keydown', e => { if ((e.key === 'Enter' || e.key === ' ') && e.target.matches && e.target.matches('.tk[data-w]')) { e.preventDefault(); Sfx.peek(); openToken(e.target.dataset.w); } });

// ================= 自訂下拉選單（和日文頁一樣） =================

// ================= 題庫篩選 =================
const POS_FILTERS = [['all', '全部'], ['n', '名詞'], ['v', '動詞'], ['adj', '形容詞'], ['o', '其他']];
const posOK = w => UI.pos === 'all' || w.pg === UI.pos;
const wrongOf = (id, m) => (getRec(id).w || {})[m] || 0;
// 今天要做的到期複習：到期越久、等級越低的先出；每天最多 SET.dueCap 個（做過的也算在內）
const DUE_CAPS = [10, 20, 30, 50, 'all'];
const dueCap = () => SET.dueCap === 'all' ? Infinity : (Number(SET.dueCap) || 30);
function dueAll() { const t = today(); return WORDS.filter(w => { const r = getRec(w.id); return r.s === 'learned' && r.due && r.due <= t; }); }
function dueToday() {
  const t = today();
  const done = WORDS.filter(w => getRec(w.id).dd === t).length;
  const left = Math.max(0, dueCap() - done);
  const list = dueAll().sort((a, b) => { const x = getRec(a.id), y = getRec(b.id); return x.due < y.due ? -1 : x.due > y.due ? 1 : (x.lv || 0) - (y.lv || 0); });
  return new Set(list.slice(0, left).map(w => w.id));
}
function wordPool(src) {
  const t = today();
  const f = {
    new: w => getRec(w.id).s === 'new',
    learn: w => getRec(w.id).s === 'queued',
    queued: w => getRec(w.id).s === 'queued',
    learned: w => getRec(w.id).s === 'learned',
    recent: (() => { let set; return w => (set || (set = recentIds())).has(w.id); })(),
    due: (() => { let set; return w => (set || (set = dueToday())).has(w.id); })(),
    mcWrong: w => wrongOf(w.id, 'mc') === 1,
    mcReview: w => wrongOf(w.id, 'mc') === 2,
    fillWrong: w => wrongOf(w.id, 'fill') === 1,
    fillReview: w => wrongOf(w.id, 'fill') === 2,
    excluded: w => getRec(w.id).s === 'excluded'
  }[src];
  return (src === 'new' ? ORDER : WORDS).filter(w => f(w));
}
const filtered = src => wordPool(src).filter(posOK);
const srcPool = src => src === 'recent' ? wordPool('recent') : filtered(src);
function posChips() {
  return `<span class="pw"><select class="pill${UI.pos !== 'all' ? ' on' : ''}" data-possel aria-label="詞性">${POS_FILTERS.map(([k, l]) => `<option value="${k}"${UI.pos === k ? ' selected' : ''}>${k === 'all' ? '詞性' : l}</option>`).join('')}</select></span>`;
}
function bindPos(root, cb) { const sel = $('[data-possel]', root); if (sel) sel.onchange = () => { UI.pos = sel.value; saveUI(); cb(); }; }
const REVIEW_ROUND = 10;
const roundSize = () => SET.round === 'all' ? 100000 : (Number(SET.round) || 20);
const RECENT_OPTS = [['d1', '最近 1 天'], ['d3', '最近 3 天'], ['d7', '最近 7 天'], ['c10', '最近 10 個字'], ['c20', '最近 20 個字'], ['c30', '最近 30 個字'], ['c50', '最近 50 個字']];
function recentLabel() { return (RECENT_OPTS.find(x => x[0] === SET.recent) || RECENT_OPTS[0])[1]; }
const recentT = id => { const r = getRec(id); return r.q || r.t || 0; };
function recentIds() {
  const v = SET.recent || 'd1', n = parseInt(v.slice(1), 10) || 1;
  const cand = WORDS.filter(w => { const r = getRec(w.id); return (r.s === 'queued' || r.s === 'learned') && recentT(w.id) > 0; });
  if (v[0] === 'c') return new Set(cand.sort((a, b) => recentT(b.id) - recentT(a.id)).slice(0, n).map(w => w.id));
  const since = Date.now() - n * 864e5;
  return new Set(cand.filter(w => recentT(w.id) >= since).map(w => w.id));
}
function recentCtl(onChange) { return { html: pillSelect('recentSel', '最近學過的範圍', RECENT_OPTS, SET.recent), bind: host => { const rs = $('#recentSel', host); if (rs) rs.onchange = e => { SET.recent = e.target.value; saveSet(); mcRound = null; fillRound = null; onChange(); }; } }; }
function progressLine(round, total) {
  const left = round.queue.length - round.idx;
  const done = round.queue.length ? (round.idx / round.queue.length) * 100 : 0;
  return `<span class="qprog" aria-label="本輪還剩 ${left} 題，此分類共 ${total} 題"><i style="width:${done}%"></i></span><span class="meta">剩 ${left} · 共 ${total}</span>`;
}
function roundDone(host, R, again) {
  Quiz.active = null;
  Sfx.done(); if (SET.vib === 'on' && canVibrate) try { navigator.vibrate([20, 40, 20, 40, 70]); } catch (e) {}
  host.innerHTML = `<div class="card empty"><p style="color:var(--fg);font-size:18px;font-weight:700">這一輪完成了</p><p>答對 ${R.right} / ${R.queue.length} 題</p><button class="btn solid" id="again">再來一輪</button></div>`;
  $('#again', host).onclick = again;
}

// ================= 通用選擇題（和日文頁一樣） =================
const Quiz = { active: null };
function renderChoice(host, q, onNext) {
  const letters = 'ABCD';
  host.innerHTML = `<div class="card qcard">${q.head}<div class="prompt">${q.promptHTML}</div>
    <div class="opts">${q.options.map((o, i) => `<button class="opt" data-i="${i}"${o.lang ? ` lang="${o.lang}"` : ''}><span class="k">${letters[i]}</span><span class="t">${o.html}</span></button>`).join('')}</div><div class="after"></div></div>`;
  const state = { answered: false, host };
  Quiz.active = state;
  const choose = i => {
    if (state.answered) return;
    state.answered = true;
    const ok = !!q.options[i].correct;
    $$('.opt', host).forEach((b, j) => { b.disabled = true; if (q.options[j].correct) b.classList.add('right'); else if (j === i) b.classList.add('wrong'); });
    q.onAnswer(ok, i);
    ok ? Sfx.ok() : Sfx.ng(); buzz(ok);
    const after = $('.after', host);
    after.innerHTML = `<div class="afterbox">${verdict(ok)}${q.explain || ''}<button class="btn solid block" data-next>下一題（Enter）</button>${!ok && q.afterHTML ? q.afterHTML(false) : ''}</div>`;
    if (ok && !q.noAuto) state.timer = setTimeout(() => { if (Quiz.active === state) onNext(); }, 900);
    const nb = $('[data-next]', after);
    nb.onclick = () => { clearTimeout(state.timer); onNext(); };
    if (!ok) { nb.focus({ preventScroll: true }); revealAboveTabbar(nb); }
  };
  state.choose = choose;
  state.goNext = () => { if (state.answered) { clearTimeout(state.timer); onNext(); } };
  $$('.opt', host).forEach(b => b.onclick = () => choose(+b.dataset.i));
}
document.addEventListener('keydown', e => {
  const tag = (e.target.tagName || '').toLowerCase();
  if (tag === 'input' || tag === 'textarea' || tag === 'select') return;
  if (e.metaKey || e.ctrlKey || e.altKey || Sheet.isOpen()) return;
  const st = Quiz.active;
  if (!st || !st.host.isConnected || st.host.closest('.tab').hidden) return;
  const k = e.key.toLowerCase();
  const idx = '1234'.indexOf(k) >= 0 ? '1234'.indexOf(k) : 'abcd'.indexOf(k);
  if (idx >= 0 && k.length === 1 && !st.answered) { e.preventDefault(); if ($$('.opt', st.host)[idx]) st.choose(idx); }
  else if (k === 'enter' && st.answered) { e.preventDefault(); st.goNext(); }
});
function meaningKeys(s) { return String(s).split(/[；;、,，／/]/).map(x => x.replace(/[（(][^）)]*[）)]/g, '').replace(/的$/, '').trim().toLowerCase()).filter(Boolean); }
function sameMeaning(a, b) { const A = meaningKeys(a), B = meaningKeys(b); return A.some(x => B.includes(x)); }
function pickWordDistractors(target, qmode, n = 3) {
  const ok = w => w.id !== target.id && w.word !== target.word && w.title !== target.title && !sameMeaning(w.zh, target.zh) && !sameMeaning(w.en, target.en);
  const chosen = [];
  const accept = w => { if (chosen.length >= n) return; if (chosen.some(c => c.title === w.title || sameMeaning(c.zh, w.zh) || sameMeaning(c.en, w.en))) return; chosen.push(w); };
  shuffle(WORDS.filter(w => w.pg === target.pg && ok(w))).forEach(accept);
  if (chosen.length < n) shuffle(WORDS.filter(ok)).forEach(accept);
  return chosen;
}

// ================= 分頁 =================
const TABS = ['pron', 'mc', 'card', 'fill', 'gram', 'lib'];
function showTab(t) {
  if (!TABS.includes(t)) t = 'card';
  UI.tab = t; saveUI();
  TABS.forEach(x => { $('#tab-' + x).hidden = x !== t; });
  $$('.tabbar button').forEach(b => b.setAttribute('aria-current', b.dataset.tab === t ? 'page' : 'false'));
  document.body.classList.remove('typing');
  Quiz.active = null; Sheet.close();
  ({ pron: renderPron, mc: renderMC, card: renderCard, fill: renderFill, gram: renderGram, lib: renderLib })[t]();
  window.scrollTo(0, 0);
}
$$('.tabbar button').forEach(b => b.onclick = () => showTab(b.dataset.tab));
$('#themeBtn').onclick = () => { SET.theme = SET.theme === 'dark' ? 'light' : 'dark'; saveSet(); applyTheme(); };
{
  const gb = $('#genBtn');
  if (gb && !Object.keys(GEN).length) gb.remove();
  else if (gb) {
    gb.innerHTML = `<ruby>名<rt>${['m', 'f', 'n'].filter(k => GEN[k]).map(k => GEN[k][1]).join('')}</rt></ruby>`;
    gb.onclick = () => { SET.gender = !genOn(); saveSet(); applyGen(); toast(genOn() ? '名詞上方標出性別' : '已隱藏性別，點單字可以看詞性'); };
  }
  applyGen();
}

// ================= 發音 =================
let pronRound = null;
function renderPron() {
  const host = $('#tab-pron');
  Quiz.active = null;
  const seg = `<div class="seg" role="group" aria-label="發音分頁">${[['abc', '字母'], ['rules', '規則'], ['practice', '練習']].map(([k, l]) => `<button data-psec="${k}" aria-pressed="${UI.pronSec === k}">${l}</button>`).join('')}</div>`;
  let body = '';
  if (UI.pronSec === 'abc') {
    const cell = (a, i, fo) => `<button class="kc${fo ? ' fo' : ''}" data-letter="${i}" aria-label="${esc(a[0])}，${LC.letterNameLabel || '字母名稱'} ${esc(a[1])}"><span class="kk">${LC.letterAsIs ? esc(a[0]) : a[0].length > 1 ? a[0].toLowerCase() : a[0] + a[0].toLowerCase()}</span><span class="rr" lang="${LC.id}">${esc(a[1])}</span></button>`;
    body = `<div class="card ksec">${LC.letterGroups.map((g, k) => `<h3${k ? '' : ' style="margin-top:0"'}>${esc(g.title)}</h3><div class="ktable c5">${IT.ALPHABET.slice(g.from, g.to).map((a, i) => cell(a, g.from + i, g.fo)).join('')}</div>`).join('')}
      <p class="meta" style="margin:12px 0 0">${LC.letterNote}</p></div>`;
  } else if (UI.pronSec === 'rules') {
    body = IT.PRON_RULES.map(r => `<div class="card"><div class="gr-head"><h2 style="font-size:18px">${esc(r.t)}</h2></div><p class="gr-desc">${r.d}</p><div class="say-chips">${r.ex.map(x => `<button class="play" data-say="${esc(x[0])}">${ICON.play}<span lang="${LC.id}">${esc(x[0])}</span><em>${esc(x[1])}</em></button>`).join('')}</div></div>`).join('');
  } else {
    body = `<div class="ctl">${pillSelect('pronMode', '練習方式', [['listen', '聽音選拼字'], ['read', '看拼字選讀法']], UI.pronMode)}</div><div id="prq"></div>`;
  }
  host.innerHTML = seg + body;
  $$('[data-psec]', host).forEach(b => b.onclick = () => { if (UI.pronSec === b.dataset.psec) return; UI.pronSec = b.dataset.psec; saveUI(); pronRound = null; renderPron(); });
  $$('[data-letter]', host).forEach(b => b.onclick = () => openLetter(+b.dataset.letter));
  const pm = $('#pronMode', host);
  if (pm) {
    pm.onchange = e => { UI.pronMode = e.target.value; saveUI(); pronRound = null; renderPron(); };
    if (!pronRound || pronRound.mode !== UI.pronMode || pronRound.idx >= pronRound.queue.length) startPron();
    else nextPronQ();
  }
}
function openLetter(i) {
  const a = IT.ALPHABET[i];
  const w = WORDS.find(x => x.word === a[4]);
  Sheet.open(`${LC.letterTitle || '字母'} ${esc(a[0])}`, `<div class="rowx"><div class="grow"><div class="w1">${LC.letterAsIs ? esc(a[0]) : a[0] + ' ' + a[0].toLowerCase()}</div><div class="meta">${LC.letterNameLabel || '字母名稱'}：<span lang="${LC.id}">${esc(a[1])}</span></div></div>${iconPlay(a[1], '播放' + (LC.letterNameLabel || '字母名稱'))}</div>
    <p class="mean-big">${esc(a[2])}</p><p style="margin:0">${esc(a[3])}</p>
    <div class="gp-title">例字</div>
    <div class="an"><div class="grow"><b lang="${LC.id}" style="font-size:22px">${esc(w ? w.title : a[4])}</b>${w ? `<div class="meta">${meanW(w)}</div>` : ''}</div>${iconPlay(w ? w.title : a[4], '播放例字')}${w ? `<button class="btn quiet" data-word="${esc(w.id)}">詳細</button>` : ''}</div>`, a[0]);
  setTimeout(() => Voice.speak(a[1]), 150);
}
function startPron() {
  const mode = UI.pronMode;
  const queue = mode === 'listen'
    ? shuffle(IT.LISTEN_PAIRS).slice(0, 10).map(p => { const ans = p[Math.floor(Math.random() * p.length)]; return { say: ans, answer: ans, options: shuffle(p) }; })
    : shuffle(IT.READ_ITEMS).slice(0, 10).map(r => ({ say: r.w, w: r.w, part: r.part, answer: r.ans, options: shuffle(r.opts) }));
  pronRound = { mode, queue, idx: 0, right: 0 };
  nextPronQ();
}
function boldPart(w, part) { const i = w.toLowerCase().indexOf(part.toLowerCase()); if (i < 0) return esc(w); return esc(w.slice(0, i)) + `<u style="text-decoration-thickness:3px;text-underline-offset:6px;color:var(--pri)">${esc(w.slice(i, i + part.length))}</u>` + esc(w.slice(i + part.length)); }
function nextPronQ() {
  const R = pronRound, host = $('#prq'); if (!R || !host) return;   // 自動跳下一題前範圍被換掉了（R 已清空）
  if (R.idx >= R.queue.length) return roundDone(host, R, () => { pronRound = null; renderPron(); });
  const q = R.queue[R.idx];
  const prompt = R.mode === 'listen'
    ? `<button class="dict-big" data-say="${esc(q.say)}" aria-label="再聽一次">${ICON.play}</button><span class="meta">聽發音，選出你聽到的拼法</span>`
    : `<div class="word-row"><div class="big" lang="${LC.id}">${boldPart(q.w, q.part)}</div>${iconPlay(q.w, '播放')}</div><span class="meta">畫線的「${esc(q.part)}」怎麼唸？</span>`;
  renderChoice(host, {
    head: `<div class="qhead">${progressLine(R, R.queue.length)}</div>`,
    promptHTML: prompt,
    options: q.options.map(o => ({ html: esc(o), correct: o === q.answer, lang: R.mode === 'listen' ? LC.id : '' })),
    onAnswer: ok => { if (ok) R.right++; bumpDay(); },
    afterHTML: () => R.mode === 'listen' ? `<div class="say-chips">${q.options.map(o => `<button class="play" data-say="${esc(o)}">${ICON.play}<span lang="${LC.id}">${esc(o)}</span></button>`).join('')}</div>` : ''
  }, () => { R.idx++; nextPronQ(); });
  if (R.mode === 'listen') setTimeout(() => Voice.speak(q.say), 250);
}

// ================= 單選 =================
const MC_MODES = [['it2zh', LC.short + '→中'], ['zh2it', '中→' + LC.short], ['listen', '聽→中'], ['verb', '動詞變化'], ['art', LC.artLabel]];
function mcPool(src) {
  let pool = srcPool(src);
  if (UI.mcMode === 'verb') pool = pool.filter(w => isVerbPos(w.pos));
  if (UI.mcMode === 'art') pool = pool.filter(w => IT.makeArtQuestion(w.e, LOOK));
  return pool;
}
function artHint(x) {
  if (x.info) return x.info;
  if (x.kind === 'artprep') { const a = IT.ART_PREPS[x.answer]; return `${x.answer} ＝ ${a.prep} ＋ ${a.art}（${IT.ART_INFO[a.art]}）`; }
  if (x.kind === 'art') return `${x.answer}：${IT.ART_INFO[x.answer] || ''}`;
  return `${x.answer}：${(IT.INDEF_INFO || { un: '陽性', uno: '陽性（s+子音、z 前）', una: '陰性', "un'": '陰性（母音前）' })[x.answer] || ''}`;
}
// 單選答完後的單字和例句
const mcWordAfter = w => `<div class="example"><div class="row" style="gap:12px;align-items:center"><b lang="${LC.id}" style="font-size:22px">${esc(w.title)}</b><span>${meanW(w)}</span>${iconPlay(w.title, '播放單字')}</div></div>${exampleBlock(w)}`;
/*@include shared/mc-tab.js*/

// ================= 字卡 =================
function formsLine(w) {
  if (IT.formsLine) { const h = IT.formsLine(w.e); if (h != null) return h ? `<span lang="${LC.id}">${esc(h)}</span>` : ''; }
  if (w.pos === 'n') { const f = IT.nounForms(w.e); return f.pl ? `複數：<span lang="${LC.id}">${esc(f.pl)}</span>` : (f.plOnly ? '只用複數' : ''); }
  if (w.pos === 'adj') return `<span lang="${LC.id}">${esc(IT.adjForms(w.e).join(' / '))}</span>`;
  if (isVerbPos(w.pos)) { const c = IT.conjugate(w.word, w.pos); return `<span lang="${LC.id}">${esc(c.presentFull.slice(0, 3).join('、'))}…</span>`; }
  return '';
}
/*@include shared/card-tab.js*/

// ================= 填空 =================
// 答案在例句裡的位置
function answerSpan(w) {
  const toks = []; let p = 0;
  for (const t of IT.tokenize(w.sent)) { toks.push({ t: t.t, w: t.w, s: p }); p += t.t.length; }
  const aw = IT.tokenize(w.ans).filter(t => t.w).map(t => IT.norm(t.t).toLowerCase());
  const ws = toks.filter(t => t.w);
  for (let i = 0; i + aw.length <= ws.length; i++) {
    if (aw.every((x, j) => IT.norm(ws[i + j].t).toLowerCase() === x)) { const last = ws[i + aw.length - 1]; return [ws[i].s, last.s + last.t.length]; }
  }
  return [0, 0];
}
const letterCount = s => s.replace(/[^\p{L}]/gu, '').length;
// 填的字是不是另一個意思相同的單字（看原形和它的變化形）
function synonymOf(input, w) {
  const k = IT.norm(String(input).trim()).toLowerCase().replace(/[?!.,]$/, '');
  if (!k) return null;
  const cands = [];
  WORDS.forEach(x => { if (x.id !== w.id && IT.checkAnswer(input, IT.plain ? IT.plain(x.word) : x.word, x) !== 'wrong') cands.push(x); });
  (LOOK.get(k) || []).forEach(x => { if (x.idx >= 0) { const o = WMAP[idOfEntry(IT.W[x.idx])]; if (o && o.id !== w.id) cands.push(o); } });
  return cands.find(o => sameMeaning(o.zh, w.zh) || sameMeaning(o.en, w.en)) || null;
}
// 拼寫提醒：把和你寫的不一樣的字母畫底線（長度一樣才逐字比）
function markDiff(ans, mine) {
  const A = [...ans], B = [...(IT.plain ? IT.plain(mine) : mine)];
  if (A.length !== B.length) return esc(ans);
  return A.map((c, i) => c.toLowerCase() !== B[i].toLowerCase() ? `<u style="text-decoration-thickness:2px;text-underline-offset:4px">${esc(c)}</u>` : esc(c)).join('');
}
/*@include shared/fill-tab.js*/

// ================= 文法 =================
let GIDX = null, gramShow = 8, gramPane = 'body', gramPaneId = '';
function gramIndex() {
  if (GIDX) return GIDX;
  GIDX = {};
  for (const g of IT.GRAMMAR) {
    const out = (g.ex || []).map(x => ({ s: x[0], zh: x[1], r: IT.grammarMatch(g, x[0]) }));
    for (const w of WORDS) { const r = IT.grammarMatch(g, w.sent); if (r.length) out.push({ s: w.sent, zh: w.sentZh, r, w }); }
    const seen = new Set();
    GIDX[g.id] = out.filter(x => !seen.has(x.s) && seen.add(x.s)).sort((a, b) => (a.w ? 1 : 0) - (b.w ? 1 : 0) || a.s.length - b.s.length);
  }
  return GIDX;
}
const plain = h => h.replace(/<[^>]+>/g, '');
// 文法列表的預覽：跳過表格，取說明文字；整段都是表格時，把格子用空白分開
const gramPreview = h => { const t = plain(h.replace(/<table[\s\S]*?<\/table>/g, ' ')).trim(); return (t || plain(h.replace(/<\/t[dh]>/g, ' '))).replace(/\s+/g, ' ').trim().slice(0, 60); };
const RULE_SHORT = LC.ruleShort || {};
function ruleDemo(R) {
  const find = (word, pos) => WORDS.find(w => w.word === word && (!pos || w.pos === pos || (pos === 'v' && isVerbPos(w.pos))));
  if (IT.demoTable) {
    const t = IT.demoTable(R.id, R.demo.map(x => find(x, 'n') || find(x, 'adj') || (IT.VERB_TABLE ? find(x) : null)).filter(Boolean).map(w => w.e));
    if (t) return `<div class="scroll-x" style="flex-shrink:0"><table class="t"><thead><tr>${t.head.map(x => `<th>${esc(x)}</th>`).join('')}</tr></thead><tbody>${t.rows.map(r => '<tr>' + r.map(c => c.f ? `<td class="f" lang="${LC.id}">${esc(c.t)}</td>` : `<td class="p">${esc(c.t)}</td>`).join('') + '</tr>').join('')}</tbody></table></div>`;
  }
  if (R.id === 'r-noun') return `<table class="t"><thead><tr><th>單數</th><th>複數</th><th>性別</th></tr></thead><tbody>${R.demo.map(x => find(x, 'n')).filter(Boolean).map(w => { const f = IT.nounForms(w.e); return `<tr><td class="f" lang="${LC.id}">${esc(f.sg)}</td><td class="f" lang="${LC.id}">${esc(f.pl)}</td><td class="p">${genOf(w.e[2])[1]}${f.plGender !== w.e[2] ? '→複數陰' : ''}</td></tr>`; }).join('')}</tbody></table>`;
  if (R.id === 'r-art') {
    const extra = IT.ART_DEMO_EXTRA || { psicologo: ['psicologo', 'n', 'm', 'psicologi'] };
    return `<table class="t"><thead><tr><th>定冠詞</th><th>複數</th><th>不定冠詞</th></tr></thead><tbody>${R.demo.map(x => { const w = find(x, 'n'); return w ? w.e : extra[x]; }).filter(Boolean).map(e => { const f = IT.nounForms(e); return `<tr><td class="f" lang="${LC.id}">${esc(f.sg)}</td><td class="f" lang="${LC.id}">${esc(f.pl)}</td><td lang="${LC.id}">${esc(f.indef + (f.indef.endsWith("'") ? '' : ' ') + e[0])}</td></tr>`; }).join('')}</tbody></table>`;
  }
  if (R.id === 'r-adj') return `<div class="scroll-x"><table class="t"><thead><tr><th>陽單</th><th>陰單</th><th>陽複</th><th>陰複</th></tr></thead><tbody>${R.demo.map(x => find(x, 'adj')).filter(Boolean).map(w => '<tr>' + IT.adjForms(w.e).map(x => `<td class="f" lang="${LC.id}">${esc(x)}</td>`).join('') + '</tr>').join('')}</tbody></table></div>`;
  return R.demo.map(x => find(x, 'v')).filter(Boolean).map(w => `<div class="rc-row" data-vk="${esc(w.id)}"><div class="rc-h"><b lang="${LC.id}">${esc(w.word)}</b><span class="meta">${esc(w.zh)}</span></div>${verbInfo(w)}
    <div class="seg" role="group" aria-label="時態 ${esc(w.word)}" style="margin:8px 0"><button data-tense="pres" aria-pressed="true">${esc(IT.conjugate(w.word, w.pos).presTab || '現在式')}</button><button data-tense="pass" aria-pressed="false">過去式</button><button data-tense="imp" aria-pressed="false">命令式</button></div><div class="vt">${conjTable(w, 'pres')}</div></div>`).join('');
}
// ================= 文法範例拆解＋練習題（IT.GX） =================
// 關卡：IT.GX_PATH = [[關卡名, 說明, [文法id...]]...]；練習題答對八成（gxNeed）＝過關，紀錄存在 items 的 LP+'gx:'+id（跟著同步）
// 說明裡的外文字標上 lang，字型和顏色跟中文分開
function gxNote(t) {
  const re = LC.id === 'ru' ? /[Ѐ-ӿ́]+(?:[ -‑][Ѐ-ӿ́]+)*/g : /[A-Za-zÀ-ÿ̀-ͯ'’]+(?:[ -][A-Za-zÀ-ÿ̀-ͯ'’]+)*/g;
  return esc(t).replace(re, m => `<span class="gx-fw" lang="${LC.id}">${m}</span>`);
}
function gxExamplesHTML(gx) {
  return `<p class="meta gx-tip">上面是整句，中間每個字下面是它的中文，最後一條一條說明為什麼這樣排。點句子裡的字可以查意思。</p>` + gx.ex.map(([s, zh, parts, notes, pl], i) => `<div class="gx-ex">
    <div class="gx-n">範例 ${i + 1}</div>
    <div class="ex-row"><div class="sent" lang="${LC.id}">${sentHTML(s, { noGen: true })}</div>${iconPlay(s, '播放範例')}</div>
    <div class="zhline">${esc(zh)}</div>
    <div class="gx-gloss">${parts.map(([w, g]) => g ? `<span class="gx-w"><b lang="${LC.id}">${esc(w)}</b><i>${esc(g)}</i></span>` : `<span class="gx-p" lang="${LC.id}">${esc(w)}</span>`).join('')}</div>
    <ul class="gx-notes">${notes.map(n => `<li>${gxNote(n)}</li>`).join('')}</ul>
    <div class="gx-plain"><b>白話</b><span>${gxNote(pl)}</span></div>
  </div>`).join('') + `<button class="btn solid block gx-go" data-gpane="q">看懂了，來練習（${gx.q.length} 題）</button>`;
}
// 練習題上方的「看變化表」：把這個文法點說明裡的表格拿來當提示，開關狀態會記住
let gxHintOpen = false;
function gxHintHTML(id) {
  const g = id && IT.GRAMMAR.find(x => x.id === id);
  const t = g ? (g.body.match(/<table[\s\S]*?<\/table>/g) || []).join('') : '';
  return t ? `<details class="gx-hint"${gxHintOpen ? ' open' : ''}><summary>不知道要用哪個？看變化表</summary><div class="gbody scroll-x">${t}</div></details>` : '';
}
function renderGram() {
  const host = $('#tab-gram');
  Quiz.active = null;
  const back = () => { UI.gramSel = ''; saveUI(); renderGram(); window.scrollTo(0, 0); };
  const rule = IT.RULES.find(r => r.id === UI.gramSel);
  if (rule) {
    const words = WORDS.filter(w => rule.filter(w.e));
    host.innerHTML = `<button class="gr-back" id="grBack">‹ 文法列表</button>
      <div class="card"><div class="gr-head"><h2>${esc(rule.title)}</h2><span class="lv">詞性變化規則</span></div><div class="gbody scroll-x">${rule.body}</div></div>
      <div class="card"><div class="gp-title">實際變化例子</div><div class="rc-list">${ruleDemo(rule)}</div></div>
      <div class="card"><div class="gp-title">App 裡的字（${words.length}）</div><p class="meta" style="margin:4px 0 10px">點一下看完整的變化表。</p><div class="rc-words">${words.map(w => `<button class="rc-w" data-word="${esc(w.id)}" lang="${LC.id}">${esc(w.title)}</button>`).join('')}</div></div>`;
    $('#grBack', host).onclick = back;
    $$('[data-vk]', host).forEach(box => $$('[data-tense]', box).forEach(b => b.onclick = () => { $$('[data-tense]', box).forEach(x => x.setAttribute('aria-pressed', String(x === b))); $('.vt', box).innerHTML = conjTable(WMAP[box.dataset.vk], b.dataset.tense); }));
    return;
  }
  const idx = gramIndex();
  const p = IT.GRAMMAR.find(g => g.id === UI.gramSel);
  if (!p) {
    const q = (UI.gramQ || '').trim().toLowerCase();
    const hit = g => !q || (g.title + g.tag + plain(g.body)).toLowerCase().includes(q);
    const rhit = IT.RULES.filter(r => !q || (r.title + plain(r.body)).toLowerCase().includes(q));
    const tags = []; IT.GRAMMAR.forEach(g => { if (!tags.includes(g.tag)) tags.push(g.tag); });
    const groups = tags.map(t => [t, IT.GRAMMAR.filter(g => g.tag === t && hit(g))]).filter(x => x[1].length);
    const usePath = IT.GX_PATH && !q && UI.gramView !== 'cat';
    const viewSeg = IT.GX_PATH && !q ? `<div class="seg gr-view" role="group" aria-label="文法排列">${[['path', '關卡（照順序學）'], ['cat', '分類']].map(([k, l]) => `<button data-gview="${k}" aria-pressed="${(UI.gramView || 'path') === k}">${l}</button>`).join('')}</div>` : '';
    const rulesHTML = rhit.length ? `<div class="gr-group"><h3>詞性變化規則</h3><div class="rc-grid">${rhit.map(r => `<button class="gr-row rc-tile" data-gram="${r.id}"><b>${esc(RULE_SHORT[r.id] || r.title)}</b><span class="gd">${WORDS.filter(w => r.filter(w.e)).length} 個字</span></button>`).join('')}</div></div>` : '';
    host.innerHTML = `<input class="gr-search" id="grQ" type="search" placeholder="${esc(LC.gramPh || '搜尋文法：冠詞、piace、過去式…')}" value="${esc(UI.gramQ || '')}" aria-label="搜尋文法">${viewSeg}
      ${usePath ? gxPathHTML() + rulesHTML : `${rhit.length ? `<div class="gr-group"><h3>詞性變化規則</h3><div class="rc-grid">${rhit.map(r => `<button class="gr-row rc-tile" data-gram="${r.id}"><b>${esc(RULE_SHORT[r.id] || r.title)}</b><span class="gd">${WORDS.filter(w => r.filter(w.e)).length} 個字</span></button>`).join('')}</div></div>` : ''}
      ${groups.map(([h, ps]) => `<div class="gr-group"><h3>${esc(h)}</h3>${ps.map(g => `<button class="gr-row" data-gram="${g.id}"><b>${esc(g.title)}</b><span class="gn"><span>${(idx[g.id] || []).length}</span>›</span><span class="gd">${esc(gramPreview(g.body))}</span></button>`).join('')}</div>`).join('')}
      ${!rhit.length && !groups.length ? '<p class="meta">找不到符合的文法。</p>' : ''}`}`;
    $$('[data-gview]', host).forEach(b => b.onclick = () => { UI.gramView = b.dataset.gview; saveUI(); renderGram(); });
    const inp = $('#grQ', host);
    inp.oninput = () => { UI.gramQ = inp.value; const pos = inp.selectionStart; renderGram(); const i = $('#grQ'); i.focus(); try { i.setSelectionRange(pos, pos); } catch (e) {} };
    return;
  }
  renderGramPoint(host, p, idx[p.id] || []);
}
/*@include shared/gram-tab.js*/

// ================= 單字庫 =================
// 這一頁和日文頁不一樣的地方（共用的分頁程式用 PAGE.…）
const PAGE = {
  voice: {
    GOOD: /natural|neural|premium|enhanced|online|google|siri/i,
    match: v => v.lang.toLowerCase().startsWith(LC.id),
    score(v) {
      let s = 0; const n = (v.name + ' ' + v.voiceURI).toLowerCase();
      if (v.lang.replace('_', '-').toLowerCase() === LC.tts.toLowerCase()) s += 10;
      if (PAGE.voice.GOOD.test(n)) s += 40;
      if (/google/.test(n)) s += 30;
      if (LC.voiceNames && LC.voiceNames.test(n)) s += 8;
      if (/compact|espeak/.test(n)) s -= 30;
      return s;
    },
    saved: () => ISET.voice,
    save(uri) { ISET.voice = uri; saveISet(); },
    text: t => String(t).replace(/_+/g, ' '),   // 練習題的 ___ 不要念出來
    uLang: v => v ? v.lang : LC.tts,
    get label() { return `${LC.name}語音（這台裝置）`; },
    get none() { return `還沒有讀到${LC.name}語音，系統會用預設聲音。`; },
    help: opts => !opts.length ? `<div class="warn">${LC.noVoiceHelp}</div>` : '',
    note: '語音只存在這台裝置；速度和日文共用。',
    get sample() { return LC.ttsSample; }
  },
  gram: {
    prefix: LP + 'gx:',
    get path() { return IT.GX_PATH; },
    gx: id => IT.GX && IT.GX[id],
    title: id => { const g = IT.GRAMMAR.find(x => x.id === id); return g ? g.title : ''; },
    quizQ([pr, ans, wr, zh, why], id) {
      // 句子結尾的撇號（l'）後面不留空格；標點前面的空格拿掉
      const full = (/'$/.test(ans) ? pr.replace('___ ', ans) : pr).replace('___', ans).replace(/\s+([.,!?…])/g, '$1');
      return {
        ans,
        head: gxHintHTML(id),
        prompt: `<div class="sent" lang="${LC.id}">${esc(pr).replace('___', '<span class="blank" id="blank">？</span>')}</div><div class="zhline">${esc(zh)}</div>`,
        options: shuffle([ans].concat(wr)).map(o => ({ html: esc(o), correct: o === ans, lang: LC.id })),
        explain: `<div class="gx-why"><div class="ex-row"><div class="sent" lang="${LC.id}">${esc(full)}</div>${iconPlay(full, '播放整句')}</div><p><b>為什麼：</b>${gxNote(why)}</p></div>`
      };
    },
    quizBound: box => { const hd = $('.gx-hint', box); if (hd) hd.addEventListener('toggle', () => { gxHintOpen = hd.open; }); },
    head: p => [p.title, esc(p.tag)],
    body: p => `<div class="gbody scroll-x">${p.body}</div>`,
    exCard: (p, exs) => `<div class="card"><div class="gp-title" style="margin-bottom:8px">App 裡用到的例句（${exs.length}）</div><p class="meta" style="margin:0 0 6px">黃色是這個文法點，點任何一個字可以查意思。</p>
      ${exs.length ? `<div class="gr-exs">${exs.slice(0, gramShow).map(x => `<div class="gr-ex"><div class="ex-row"><div class="sent" lang="${LC.id}">${sentHTML(x.s, { ranges: x.r })}</div>${iconPlay(x.s, '播放例句')}</div><div class="zhline">${esc(x.zh)}</div>${x.w ? `<div class="from">出自單字：<span lang="${LC.id}">${esc(x.w.title)}</span>（${esc(meanPlain(x.w))}）</div>` : ''}</div>`).join('')}</div>${exs.length > gramShow ? `<button class="btn quiet gr-more" id="grMore">再顯示 ${Math.min(8, exs.length - gramShow)} 句（共 ${exs.length} 句）</button>` : ''}` : '<p class="meta">目前的例句裡還沒有用到這個文法。</p>'}
    </div>`
  },
  mc: {
    get modes() { return MC_MODES; },
    resetOnMode: true,
    roundKey: () => UI.mcMode + ':' + UI.mcSrc + ':' + (UI.mcSrc === 'recent' ? '' : UI.pos),
    // 冠詞題：範圍裡的例句挖不出冠詞時（或語言包只用練習句），改出固定的介係詞練習句
    special(key, pool) {
      if (UI.mcMode !== 'art' || !(IT.DRILLS_ONLY || (!pool.length && srcPool(UI.mcSrc).length))) return false;
      const queue = shuffle(IT.PREP_DRILLS).slice(0, Math.min(10, roundSize())).map(d => ({ drill: d }));
      mcRound = { key, mode: 'art', queue, idx: 0, total: IT.PREP_DRILLS.length, src: UI.mcSrc, pos: UI.pos, right: 0 };
      nextMCQ(); return true;
    },
    pool: src => mcPool(src),
    emptyPool() {
      if (UI.mcMode !== 'verb' || !srcPool(UI.mcSrc).length) return false;
      $('#mcq').innerHTML = '<div class="card empty"><p>這個來源裡沒有動詞。可以換一個題目來源，或先到字卡把動詞列入考題。</p></div>';
      return true;
    },
    recentQueue: pool => shuffle(pool),
    start: () => nextMCQ(),
    // 冠詞／格與性別、動詞變化
    question(R, item, c) {
      const { host, src, head, next } = c;
      if (R.mode === 'art') {
        if (item.drill) {
          const d = item.drill;
          renderChoice(host, {
            head, promptHTML: `<div class="sent" lang="${LC.id}">${esc(d[0]).replace('___', '<span class="blank" id="blank">？</span>')}</div><div class="zhline">${esc(d[3])}</div>`,
            options: shuffle([d[1]].concat(d[2])).map(o => ({ html: esc(o), correct: o === d[1], lang: LC.id })),
            onAnswer: ok => { if (ok) R.right++; R.done = true; bumpDay(); const b = $('#blank'); b.textContent = d[1]; b.classList.add(ok ? 'ok' : 'ng'); }
          }, next);
          return true;
        }
        const w = item, x = IT.makeArtQuestion(w.e, LOOK);
        renderChoice(host, {
          head, promptHTML: `<div class="sent" lang="${LC.id}">${sentHTML(x.sentence, { blank: [x.before.length, x.before.length + x.answer.length], blankHTML: '<span class="blank" id="blank">？</span>', noGen: true })}</div><div class="zhline">${esc(x.zh)}</div>`,
          options: x.options.map(o => ({ html: esc(o), correct: o === x.answer, lang: LC.id })),
          onAnswer: ok => { if (ok) R.right++; R.done = true; bumpDay(); const b = $('#blank'); b.textContent = x.answer; b.classList.add(ok ? 'ok' : 'ng'); },
          afterHTML: () => `<div class="hint"><span>${esc(artHint(x))}</span></div>${mcWordAfter(w)}`
        }, next);
        return true;
      }
      if (R.mode === 'verb') {
        const w = item, q = IT.makeVerbQuestion(w.e);
        renderChoice(host, {
          head, promptHTML: `<div class="mid" lang="${LC.id}">${esc(q.subj)} ＋ ${esc(w.word)}</div><span class="meta">${esc(q.label || (q.tense === 'passato' ? LC.pastLabel : '現在式'))}・${esc(w.zh)}</span>`,
          options: q.options.map(o => ({ html: esc(o), correct: o === q.answer, lang: LC.id })),
          onAnswer: ok => { if (ok) R.right++; R.done = true; record(w, 'mc', ok, src); },
          afterHTML: () => `<div class="hint"><span>正確答案：<b lang="${LC.id}">${esc(q.answer)}</b></span><button class="linkbtn" data-word="${esc(w.id)}" style="align-self:flex-start">看完整變化表</button></div>`
        }, next);
        return true;
      }
      return false;
    },
    word: {
      distractors: (w, mode) => pickWordDistractors(w, mode),
      prompt: (w, mode) => mode === 'it2zh' ? `<div class="word-row"><div class="big${lenCls(w.title)}" lang="${LC.id}">${esc(w.title)}</div>${iconPlay(w.title, '播放單字')}</div><span class="pos">${esc(POS_ZH[w.pos])}</span>`
        : mode === 'zh2it' ? `<div class="zh">${meanW(w)}</div><span class="pos">${esc(POS_ZH[w.pos])}</span>`
        : `<button class="btn solid" data-say="${esc(w.title)}" style="min-width:160px">${ICON.play}播放發音</button><span class="meta">按下按鈕聽發音，再選出意思</span>`,
      option: (o, mode) => mode === 'zh2it' ? { html: esc(o.title), lang: LC.id } : { html: meanW(o) },
      after: w => mcWordAfter(w),
      speak: (w, mode) => { if (mode === 'it2zh' || mode === 'listen') setTimeout(() => Voice.speak(w.title), 250); }
    }
  },
  fill: {
    top: () => '',
    bindTop: () => {},
    recentQueue: pool => shuffle(pool),
    make(w, R) {
      const [a0, a1] = answerSpan(w);
      const ans = w.sent.slice(a0, a1);
      const n = letterCount(ans);
      const blankEmpty = '＿'.repeat(Math.max(2, Math.min(Math.ceil(ans.length / 2), 6)));
      const showHint = SET.fillHint === 'show';
      const hint = n > 1 ? `<span class="meta" id="fillHint"${showHint ? '' : ' hidden'}>提示：第一個字母是 <b style="color:var(--fg)">${esc(ans[0])}</b>，共 ${n} 個字母${/ /.test(ans) ? `（${ans.split(' ').length} 個字）` : ''}</span>` : '';
      let triedSyn = false;
      return {
        blankEmpty, hintSound: true,
        html: `<div class="qhead">${progressLine(R, R.total)}</div>
    <div class="row" style="margin-top:6px">${posBadge(w)}<b>${meanW(w)}</b></div>
    <div class="sent" lang="${LC.id}" style="margin-top:8px">${sentHTML(w.sent, { blank: [a0, a1], blankHTML: `<span class="blank" id="blank">${blankEmpty}</span>` })}</div>
    <div class="hint" style="margin-top:8px"><span>${esc(w.sentZh)}</span>${hint}</div>
    <form class="answerrow" id="fillForm" style="margin-top:12px" autocomplete="off">
      <input id="fillIn" type="text" lang="${LC.id}" inputmode="text" autocapitalize="off" autocorrect="off" spellcheck="false" enterkeyhint="go" placeholder="輸入${LC.name}" aria-label="填入答案">
      <button class="btn solid" type="submit" id="fillGo">送出</button>
    </form>
    <div class="btnrow" style="margin-top:12px">${n > 1 ? `<button class="btn quiet" id="fillHintBtn" aria-pressed="${showHint}">${showHint ? '收起提示' : '提示'}</button>` : ''}<button class="btn quiet" id="fillShow">看答案</button></div>
    <div id="fillAfter"></div>`,
        live(inp, blank) { blank.textContent = inp.value || blankEmpty; },
        check: v => IT.checkAnswer(v, ans, w),
        // 填了意思相同的另一個字（例如「您好」填了 привет）：不算錯，提示再試一次
        retry(v) {
          const syn = synonymOf(v, w);
          if (!syn || triedSyn) return false;
          triedSyn = true;
          $('#fillAfter').innerHTML = `<div class="hl-warn"><b lang="${LC.id}">${esc(syn.title)}</b> 是「${esc(meanPlain(syn))}」，意思很接近，但這題要的是另一個字，再想想看。</div>`;
          const h = $('#fillHint'), hb = $('#fillHintBtn'); if (h) h.hidden = false; if (hb) hb.hidden = true;
          $('#fillIn').select(); Sfx.tick();
          return true;
        },
        reveal: blank => { blank.textContent = ans; },
        hideButtons() { $('#fillShow').hidden = true; const hb = $('#fillHintBtn'); if (hb) hb.hidden = true; const fh = $('#fillHint'); if (fh) fh.hidden = true; },
        verdict: (res, shown, v) => `${verdict(res !== 'wrong', shown ? '（看了答案）' : res === 'accent' ? (LC.accentNote || '，但注意重音') : '', res === 'accent')}
      ${res === 'accent' ? `<div class="hl-warn">正確寫法：<b lang="${LC.id}">${markDiff(ans, v.trim())}</b>（你寫的是 ${esc(v.trim())}）</div>` : ''}`,
        correct: (v, shown) => `<div>正確答案：<b lang="${LC.id}" style="font-size:20px">${esc(ans)}</b>${v && !shown ? `<br><span class="meta">你的答案：${esc(v)}</span>` : ''}</div>`,
        wordRow: () => `<div class="row" style="gap:12px;align-items:center"><b lang="${LC.id}" style="font-size:20px">${esc(w.title)}</b><span>${meanW(w)}</span>${iconPlay(w.title, '播放單字')}</div>`,
        after(ok) { if (!ok) revealAboveTabbar($('#fillGo')); Voice.speak(w.sent); }
      };
    }
  },
  card: {
    pos: w => posBadge(w),
    headRight: () => '',
    afterHead: () => '',
    word: w => `<div class="word-row"><div class="word${lenCls(w.title)}" lang="${LC.id}">${esc(w.title)}</div>${iconPlay(w.title, '播放單字')}</div>`,
    afterMean: w => { const fl = formsLine(w); return fl ? `<div class="forms">${fl}</div>` : ''; },
    bind: () => {}
  },
  lib: {
    searchPh: `搜尋：${LC.name}、中文或英文`,
    voiceTitle: `${LC.name}發音`,
    hintUnit: '字母',
    roundTabs: '發音練習、單選、字卡和填空',
    mallet: '字母',
    meanNote: '',
    langHTML: () => `<section><h4>介面語言 Language</h4>
          <label class="label" for="langSel">介面語言</label>
          <select id="langSel"><option value="zh"${SET.lang !== 'en' ? ' selected' : ''}>中文（繁體）</option><option value="en"${SET.lang === 'en' ? ' selected' : ''}>English</option></select>
          <div class="meta">${LC.name}頁目前只有中文介面；選 English 會套用到日語頁。</div>
          <button class="btn quiet" id="tourBtn" style="min-height:40px;margin-top:6px">重看使用導覽</button>
        </section>`,
    extraHTML: () => '',
    endHTML: () => `<section><h4>重設</h4>
          <button class="btn quiet" id="resetIt" style="min-height:40px">清除${LC.name}的學習紀錄</button>
          <div class="meta">只清${LC.name}，其他語言的進度不會動。</div>
        </section>`,
    syncNote: '各語言的進度存在同一個帳號裡；備份碼也是同一串，每個語言頁都能匯入。所有設定（外觀、音效、題數、意思、介面語言）各語言共用，在哪一頁改都一樣。',
    expNote: n => `共 ${n} 字，包含所有語言。`,
    impNote: `這裡只匯入${LC.name}；其他語言請在各自的頁面匯入同一串碼。`,
    impKeep: id => WMAP[id] || id.startsWith(LP + 'gx:'),
    impToast: n => `已匯入 ${n} 筆${LC.name}紀錄`,
    wordCell: w => `<span class="w" lang="${LC.id}" data-word="${esc(w.id)}" style="cursor:pointer;font-family:var(--font-ui)">${esc(w.title)}</span>`,
    onEntryMc: () => { if (UI.mcMode === 'art') UI.mcMode = 'it2zh'; },
    bind() {
      $('#langSel').onchange = e => { SET.lang = e.target.value; saveSet(); toast(SET.lang === 'en' ? '日語頁會換成英文介面' : '介面語言：中文'); };
      $('#tourBtn').onclick = () => Tour.start(0);
      $('#resetIt').onclick = () => {
        const el = Sheet.open(`清除${LC.name}紀錄`, `<p style="margin:0">確定要清除${LC.name}的所有學習紀錄嗎？這個動作不能復原，可以先「匯出進度」備份。其他語言的進度不會動。</p><div class="btnrow"><button class="btn quiet" id="rsNo">取消</button><button class="btn solid" id="rsYes">清除</button></div>`);
        $('#rsNo', el).onclick = () => Sheet.close();
        $('#rsYes', el).onclick = () => {
          reloadShared();
          const now = Date.now();
          // 留下空白紀錄（帶時間），同步時其他裝置也會一起清掉
          for (const id in S.items) if (id.startsWith(LP)) S.items[id] = Object.assign(blankRec(), { t: now });
          saveLocal(); Cloud.schedule(); Sheet.close(); deck = null; mcRound = null; fillRound = null; renderLib(); toast(`已清除${LC.name}的紀錄`);
        };
      };
    }
  }
};
/*@include shared/lib-tab.js*/
// 切換語言選單裡的進度條（lang.js）
if (window.AppLangs && AppLangs.stats) AppLangs.stats(() => { const c = libCounts(); return { l: c.learned, t: Math.max(1, c.total - c.excluded) }; });
function doSearch(qs) {
  const box = $('#results');
  const q = qs.trim().toLowerCase();
  if (!q) { box.innerHTML = ''; return; }
  const qa = IT.stripAccents(q);
  let hits = WORDS.filter(w => IT.stripAccents((w.word + ' ' + w.title + ' ' + w.e[3]).toLowerCase()).includes(qa) || w.zh.includes(qs.trim()) || (q.length > 1 && /^[a-z ]+$/.test(q) && w.en.toLowerCase().includes(q)));
  hits.sort((a, b) => (IT.stripAccents(a.word.toLowerCase()).startsWith(qa) ? 0 : 1) - (IT.stripAccents(b.word.toLowerCase()).startsWith(qa) ? 0 : 1));
  hits = hits.slice(0, 30);
  if (!hits.length) { box.innerHTML = '<div class="meta">找不到符合的字。</div>'; return; }
  box.innerHTML = hits.map(w => {
    const r = getRec(w.id);
    const canQ = r.s === 'new' || r.s === 'excluded';
    return `<div class="res">
      <div class="hd"><span class="w" lang="${LC.id}" style="font-family:var(--font-ui);font-weight:700">${esc(w.title)}</span><span>${meanW(w)}</span>${posBadge(w)}</div>
      <div class="row"><span class="st ${r.s}">${STATUS_TXT[r.s] || '未學'}</span><span class="meta">作答 ${r.n || 0} 次</span></div>
      <div class="sent sm" lang="${LC.id}">${sentHTML(w.sent)}</div>
      <div class="meta" style="color:var(--fg)">${esc(w.sentZh)}</div>
      <div class="row">${playBtn(w.title, '單字')}${playBtn(w.sent, '例句')}${canQ ? `<button class="btn" data-q="${esc(w.id)}" style="min-height:44px">列入考題</button>` : ''}</div>
    </div>`;
  }).join('');
  $$('[data-q]', box).forEach(b => b.onclick = () => { touch(b.dataset.q, { s: 'queued' }); toast('已列入考題'); doSearch($('#q').value); });
}

// ================= 帳號同步（和日文頁同一份資料） =================
const Cloud = makeCloud({ getS: () => S, setS: v => { S = v; }, saveLocal, merge: mergeState, refresh: refreshPassive, toast, renderAuth: renderAuthBox, reload: reloadShared });   // 程式在 sync.js（所有語言頁共用）
const GOOGLE_G = '<svg viewBox="0 0 48 48" width="18" height="18" aria-hidden="true"><path fill="#FFC107" d="M43.6 20.5H42V20H24v8h11.3C33.7 32.7 29.2 36 24 36c-6.6 0-12-5.4-12-12s5.4-12 12-12c3.1 0 5.8 1.2 7.9 3.1l5.7-5.7C34 6.1 29.3 4 24 4 12.9 4 4 12.9 4 24s8.9 20 20 20 20-8.9 20-20c0-1.3-.1-2.4-.4-3.5z"/><path fill="#FF3D00" d="M6.3 14.7l6.6 4.8C14.7 15.1 19 12 24 12c3.1 0 5.8 1.2 7.9 3.1l5.7-5.7C34 6.1 29.3 4 24 4 16.3 4 9.7 8.3 6.3 14.7z"/><path fill="#4CAF50" d="M24 44c5.2 0 9.9-2 13.4-5.2l-6.2-5.2C29.2 35.1 26.7 36 24 36c-5.2 0-9.6-3.3-11.3-7.9l-6.5 5C9.5 39.6 16.2 44 24 44z"/><path fill="#1976D2" d="M43.6 20.5H42V20H24v8h11.3c-.8 2.2-2.2 4.2-4.1 5.6l6.2 5.2C37 39.2 44 34 44 24c0-1.3-.1-2.4-.4-3.5z"/></svg>';
function renderAuthBox() {
  const top = $('#authTop');
  if (top) {
    if (Cloud.mode === 'google' && !Cloud.user) {
      top.innerHTML = `<div class="authcard"><div><b>用 Google 帳號存進度</b><div class="meta">每個語言的進度會一起存到雲端。</div></div><button class="btn solid gbtn-signin" id="gInTop">${GOOGLE_G}登入</button></div>`;
      $('#gInTop', top).onclick = () => Cloud.signIn();
    } else top.innerHTML = '';
  }
  const box = $('#authBox'); if (!box) return;
  if (Cloud.mode !== 'google') { box.innerHTML = ''; return; }
  if (Cloud.user) {
    box.innerHTML = `<div class="row"><span class="meta">${esc(Cloud.user.email || Cloud.user.displayName || '已登入')}</span><button class="btn quiet" id="gOut" style="min-height:40px">登出</button></div>`;
    $('#gOut', box).onclick = () => Cloud.signOut();
  } else {
    box.innerHTML = `<button class="btn solid block gbtn-signin" id="gIn">${GOOGLE_G}用 Google 登入</button>`;
    $('#gIn', box).onclick = () => Cloud.signIn();
  }
}
// 從雲端或日文頁合併進來後，只更新不會打斷作答的地方
function refreshPassive(force) {
  renderGoal();
  if (UI.tab === 'lib' && (force || (!$('#bk')?.innerHTML && !document.activeElement?.matches?.('#q')))) renderLib();
  if (force && UI.tab === 'card') renderCard();
}
document.addEventListener('visibilitychange', () => { if (document.visibilityState === 'visible') { reloadShared(); renderGoal(); Cloud.schedule(500); } });
// 同一台裝置在別的分頁改了進度（例如日文頁）
window.addEventListener('storage', e => { if (e.key === 'n5:progress') { reloadShared(); renderGoal(); } if (e.key === 'n5:settings') { Object.assign(SET, store.get('n5:settings', {})); applyTheme(); applyGen(); } });

// ================= 首次使用導覽（各語言的文字可以在 config.js 用 tourIntro、tourPron、tourFill 覆寫） =================
PAGE.tour = {
  key: LP + 'toured',
  get art() {
    const g = esc(LC.glyph), fs = [...LC.glyph].length > 1 ? 22 : 28;
    return `<svg class="tour-art" viewBox="0 0 320 110" aria-hidden="true"><rect width="320" height="110" rx="12" fill="var(--surface2)"/><circle cx="252" cy="34" r="16" fill="var(--c2)"/><path d="M0 110 L70 46 L120 82 L170 30 L240 110Z" fill="var(--c1)"/><path d="M150 50 L170 30 L190 50 L180 46 L170 54 L160 46Z" fill="var(--surface)"/><path d="M120 110 L210 62 L320 104 L320 110Z" fill="var(--c3)"/><path d="M0 98 C60 88 110 104 170 96 S280 86 320 96 L320 110 L0 110Z" fill="var(--pri-soft)"/><rect x="26" y="20" width="44" height="44" rx="10" fill="var(--fill)"/><text x="48" y="51" text-anchor="middle" font-size="${fs}" font-weight="700" fill="var(--fill-ink)" font-family="var(--font-ui)">${g}</text></svg>`;
  },
  steps: () => [
    { t: `歡迎使用${LC.name} ${LC.level}`, d: LC.tourIntro || `從字母和發音開始，學${LC.name} ${LC.level} 的單字和文法。用 30 秒認識每個分頁。` },
    { el: '.brand', t: '切換語言', d: '點左上角的語言名稱可以換到別的語言；也可以鎖定只學其中幾個語言，避免一次學太多。' },
    { el: '[data-tab="pron"]', tab: 'pron', t: '發音', d: LC.tourPron || '字母表點一下可以聽發音、看例字；「規則」整理拼字怎麼唸，「練習」有聽音選拼字、看拼字選讀法。' },
    { el: '[data-tab="card"]', tab: 'card', t: '字卡：挑要學的字', d: '新字一張一張看：已經會的按「已經會了」，想練的按「列入考題」，之後單選和填空就會出這些字。' },
    { el: '[data-tab="mc"]', tab: 'mc', t: '單選', d: `${MC_MODES.map(m => m[1]).join('、')}，左上角可以換題型和題目來源。` },
    { el: '[data-tab="fill"]', tab: 'fill', t: '填空', d: '看例句打出空格裡的字，答對才算「已學會」，之後照時間排到期複習。' + (LC.tourFill || '') },
    { el: '[data-tab="gram"]', tab: 'gram', t: '文法', d: '文法分成好幾關，照順序學：每個文法點有說明、拆開的範例和練習題，答對八成就過關。下面還有詞性變化規則。' },
    { el: '[data-tab="lib"]', tab: 'lib', t: '單字庫・設定', d: '看進度、搜尋單字、進入錯題和到期複習。下面的「設定」可以調音效、選語音、用 Google 登入同步進度。' },
    { el: ['#genBtn', '#themeBtn'], t: '上方的小按鈕', d: $('#genBtn') ? '「名」切換名詞上方的性別標示，最右邊切換淺色／深色。' : '最右邊的按鈕切換淺色／深色。' },
    { t: '小提示', d: '例句裡的單字都可以點，會跳出意思和詳細資料。準備好就開始吧！', last: true }
  ],
  fresh: () => !Object.keys(S.items).some(id => id.startsWith(LP))
};
/*@include shared/tour.js*/

// ================= 啟動 =================
applyTheme();
renderGoal();
Voice.init();
showTab(UI.tab);
Cloud.init();
Tour.auto();
window.ITApp = { showTab, Tour, openWord, openToken, getRec, record, touch, S: () => S, UI, SET, WORDS };
})();
