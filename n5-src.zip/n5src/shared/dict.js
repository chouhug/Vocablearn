// ================= 線上查字典（n5src/shared/dict.js） =================
// 給「我的單字」表單用：查英文解釋（英文版 Wiktionary 的 REST API，依語言分好）和中文翻譯（MyMemory，機器翻譯）。
// 兩個服務都不用金鑰、允許網頁直接連（CORS）；sw.js 不會快取這些連線，沒網路就查不到。
// 這個檔不用頁面的變數（只用 fetch），所以 n5src/dict-test.js 可以直接測。
const DICT_POS = { Noun: ['名詞', 'n'], 'Proper noun': ['專有名詞', 'n'], Verb: ['動詞', 'v'], Adjective: ['形容詞', 'adj'], Adverb: ['副詞', 'o'], Preposition: ['介係詞', 'o'], Pronoun: ['代名詞', 'o'], Conjunction: ['連接詞', 'o'], Interjection: ['感嘆詞', 'o'], Determiner: ['限定詞', 'o'], Article: ['冠詞', 'o'], Numeral: ['數詞', 'o'], Particle: ['助詞', 'o'], Phrase: ['片語', 'o'], Idiom: ['慣用語', 'o'], 'Prepositional phrase': ['介係詞片語', 'o'], Proverb: ['諺語', 'o'] };
// Wiktionary 的解釋是 HTML：拿掉標籤，留下文字
const dictText = h => String(h || '').replace(/<style[\s\S]*?<\/style>/gi, '').replace(/<[^>]+>/g, '').replace(/&nbsp;/g, ' ').replace(/&lt;/g, '<').replace(/&gt;/g, '>').replace(/&quot;/g, '"').replace(/&#0?39;|&apos;/g, "'").replace(/&amp;/g, '&').replace(/\s+/g, ' ').trim();
// 回傳 JSON；查不到（404 等）回傳 null；連不上或逾時回傳 undefined
async function dictFetch(url, ms = 8000) {
  const ac = typeof AbortController !== 'undefined' ? new AbortController() : null;
  const timer = setTimeout(() => ac && ac.abort(), ms);
  try { const r = await fetch(url, ac ? { signal: ac.signal } : {}); return r.ok ? await r.json() : null; }
  catch (e) { return undefined; }
  finally { clearTimeout(timer); }
}
// 回傳 { defs: [{ pos, zh 詞性中文, p 詞性分組, defs: [英文解釋…] }], zh: [中文翻譯…], offline: 兩個服務都連不上 }
async function dictLookup(word, lang) {
  word = String(word).trim().replace(/\s+/g, ' ');
  // Wiktionary 的條目分大小寫（德文名詞大寫、句首的字小寫），照打的、全小寫、首字大寫各試一次
  const forms = [...new Set([word, word.toLowerCase(), word.charAt(0).toUpperCase() + word.slice(1)])];
  const wik = (async () => {
    for (const f of forms) {
      const j = await dictFetch('https://en.wiktionary.org/api/rest_v1/page/definition/' + encodeURIComponent(f.replace(/ /g, '_')));
      if (j === undefined) return undefined;
      if (j && Array.isArray(j[lang]) && j[lang].length) return j[lang];
    }
    return [];
  })();
  const mm = dictFetch('https://api.mymemory.translated.net/get?q=' + encodeURIComponent(word) + '&langpair=' + lang + '|zh-TW');
  const [w, m] = await Promise.all([wik, mm]);
  const defs = [];
  for (const e of w || []) {
    const ds = (e.definitions || []).map(d => dictText(d.definition)).filter(Boolean).slice(0, 3);
    const info = DICT_POS[e.partOfSpeech] || [e.partOfSpeech || '', 'o'];
    if (ds.length) defs.push({ pos: e.partOfSpeech || '', zh: info[0], p: info[1], defs: ds });
  }
  // 中文：只留真的有中文字、不太長的；同一個字的翻譯記憶先看品質分數，最後才是整句的機器翻譯
  const zh = [], han = s => /[一-鿿]/.test(s) && s.length <= 20;
  const add = s => { s = String(s || '').trim().replace(/\s+/g, ''); if (han(s) && !zh.includes(s)) zh.push(s); };
  if (m && Array.isArray(m.matches)) {
    m.matches.filter(x => String(x.segment || '').trim().toLowerCase() === word.toLowerCase())
      .sort((a, b) => (Number(b.quality) || 0) - (Number(a.quality) || 0) || (b.match || 0) - (a.match || 0))
      .forEach(x => add(x.translation));
  }
  if (m && m.responseData) add(m.responseData.translatedText);
  return { defs: defs.slice(0, 4), zh: zh.slice(0, 3), offline: w === undefined && m === undefined };
}
// 日文的讀音：從 Wiktionary 條目原始碼的 {{ja-pos|noun|ひげ}}、{{ja-noun|ひげ}}、{{ja-verb|type=1|そる}} 這類標籤找假名。
// 回傳候選讀音（可能是空陣列）；連不上回傳 undefined。這裡不檢查對不對得上，由頁面用 align() 確認後才填。
async function dictReading(word) {
  const j = await dictFetch('https://en.wiktionary.org/w/api.php?action=query&prop=revisions&rvprop=content&rvslots=main&format=json&formatversion=2&redirects=1&origin=*&titles=' + encodeURIComponent(String(word).trim()));
  if (j === undefined) return undefined;
  const pg = j && j.query && j.query.pages && j.query.pages[0];
  const txt = pg && pg.revisions && pg.revisions[0] && pg.revisions[0].slots && pg.revisions[0].slots.main;
  const src = txt ? String(txt.content != null ? txt.content : txt['*'] || '') : '';
  const at = src.indexOf('==Japanese==');
  if (at < 0) return [];
  const rest = src.slice(at + 12), end = rest.search(/\n==[^=]/);
  const ja = end < 0 ? rest : rest.slice(0, end);
  const out = [], kana = /^[ぁ-ゖァ-ヺー]+$/;
  for (const m of ja.matchAll(/\{\{ja-(?:pos|noun|verb|verb-suru|adj|phrase|adv|see)\|([^{}]*)\}\}/g)) {
    for (const a of m[1].split('|')) {
      if (a.includes('=')) continue;
      const k = a.replace(/[\s.\-^%']/g, '');
      if (kana.test(k) && !out.includes(k)) out.push(k);
    }
  }
  return out;
}
