// ================= 拉起式面板 Sheet（日文頁和語言頁共用：n5src/shared/sheet.js） =================
// Sheet.open(標題 HTML, 內容 HTML, 給螢幕閱讀器的名稱) 回傳面板元素；Sheet.close()；Sheet.isOpen()。外觀用 base.css 的 .pk、.sheet-body
const Sheet = {
  el: null, back: null, prev: null,
  build() {
    this.back = document.createElement('div'); this.back.className = 'pk-back'; this.back.hidden = true;
    this.el = document.createElement('div'); this.el.className = 'pk'; this.el.hidden = true;
    this.el.setAttribute('role', 'dialog'); this.el.setAttribute('aria-modal', 'true');
    document.body.append(this.back, this.el);
    this.back.onclick = () => this.close();
    this.el.addEventListener('click', e => { if (e.target.closest('.pk-x')) this.close(); });
  },
  open(title, body, label) {
    if (!this.el) this.build();
    if (this.el.hidden) this.prev = document.activeElement;
    this.el.setAttribute('aria-label', label || title.replace(/<[^>]+>/g, ''));
    this.el.innerHTML = `<div class="pk-grab" aria-hidden="true"></div><div class="pk-top"><b>${title}</b><button class="pk-x" aria-label="關閉">${ICON.ng}</button></div><div class="sheet-body">${body}</div>`;
    this.back.hidden = false; this.el.hidden = false;
    requestAnimationFrame(() => { this.back.classList.add('in'); this.el.classList.add('in'); $('.pk-x', this.el).focus({ preventScroll: true }); });
    return this.el;
  },
  close() {
    if (!this.el || this.el.hidden) return;
    this.back.classList.remove('in'); this.el.classList.remove('in');
    setTimeout(() => { this.back.hidden = true; this.el.hidden = true; }, 180);
    if (this.prev && document.contains(this.prev)) try { this.prev.focus({ preventScroll: true }); } catch (e) {}
  },
  isOpen() { return this.el && !this.el.hidden; }
};
document.addEventListener('keydown', e => { if (e.key === 'Escape' && Sheet.isOpen()) { e.stopPropagation(); Sheet.close(); } }, true);
