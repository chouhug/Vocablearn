// ================= 突然考一組（日文頁和語言頁共用：n5src/shared/pop-quiz.js） =================
// build.js 會把這個檔複製進兩邊的頁面（見 lib-tab.js 開頭的說明）。
// 兩種時機會跳出一組三題（兩題選擇＋一題填空），蓋住整個畫面、做完才能回去（.pop-full，樣式在 base.css）：
//   1. 做了 10～25 題（每次隨機）：設定「突擊測驗」（SET.pop：'off' 關閉，其他＝開，預設開）。record() 每記一題就呼叫 Pop.tick()（單選不算，和每日題數一樣）。
//   2. 隔了好幾天沒打開（POP_AWAY_DAYS 天以上）：啟動時呼叫 Pop.start()。
// 一組的題目：第 1 題看單字選意思；第 2 題考讀音（日文有漢字的字，PAGE.pop.readQ），沒有就看意思選單字；第 3 題填空。
// 題目從「待考」和「已學會」最久沒練到的字裡抽（盡量三題不同字）；作答照單選、填空記錄（選擇不算每日題數，填空算）。
// 各頁要給 PAGE.pop = { key: 存計數的 localStorage key, mode: 看單字選意思的題型代碼, rev: 看意思選單字的題型代碼,
//   readQ(w): 要考讀音時回傳 { prompt, options: [{ html, cls, correct }], after }，不考就回傳 null }。
// 題目和選項的畫法用 PAGE.mc.word 和 fillQuestion（shared/fill-tab.js），和單選、填空分頁一樣。
const POP_MIN = 10, POP_MAX = 25;
const POP_AWAY_DAYS = 2;
const POP_LOCK = 1200;   // 跳出來後「開始作答」要等多久才按得下去（毫秒），避免誤觸
const Pop = {
  timer: null, active: false,
  on() { return SET.pop !== 'off'; },
  goal() { return POP_MIN + Math.floor(Math.random() * (POP_MAX - POP_MIN + 1)); },
  state() { const s = store.get(PAGE.pop.key, null); return s && typeof s === 'object' ? s : { n: 0, last: '' }; },
  save(s) { store.set(PAGE.pop.key, s); },
  // 最久沒練到的字（至少 8 個）裡隨機抽 n 個；字不夠就重複用
  pick(n) {
    const list = WORDS.filter(w => { const s = getRec(w.id).s; return s === 'queued' || s === 'learned'; });
    if (!list.length) return [];
    list.sort((a, b) => (getRec(a.id).t || 0) - (getRec(b.id).t || 0));
    const top = shuffle(list.slice(0, Math.max(8, n)));
    return Array.from({ length: n }, (_, i) => top[i % top.length]);
  },
  // 有其他面板、導覽、選語言畫面開著時先不跳
  busy() { return this.active || document.hidden || (typeof Sheet !== 'undefined' && Sheet.isOpen()) || !!document.querySelector('.pk-back:not([hidden]), .tour-card:not([hidden]), .lg-welcome, .pop-full'); },
  // 每記一題呼叫一次（record() 裡）；突擊測驗本身的題目不算
  tick() {
    if (this.active) return;
    const s = this.state();
    if (!s.goal) s.goal = this.goal();
    s.n = (s.n || 0) + 1; s.last = today();
    if (this.on() && s.n >= s.goal) { s.n = 0; s.goal = this.goal(); this.later('count'); }
    this.save(s);
  },
  // 啟動時呼叫：上次打開是 POP_AWAY_DAYS 天以前就考一組
  start() {
    if (window.AppLangs && AppLangs.welcome) return AppLangs.afterWelcome(() => this.start());
    const s = this.state(), t = today();
    const away = s.last && s.last < t ? Math.round((new Date(t) - new Date(s.last)) / 864e5) : 0;
    s.last = t; if (!s.goal) s.goal = this.goal(); this.save(s);
    if (this.on() && away >= POP_AWAY_DAYS) this.later('away', away);
  },
  // 等目前這題的對錯顯示一下再跳；有東西開著就晚點再試（最多試 20 次）
  later(why, days, tries = 0) {
    clearTimeout(this.timer);
    this.timer = setTimeout(() => {
      if (this.busy()) { if (tries < 20) this.later(why, days, tries + 1); return; }
      this.show(why, days);
    }, tries ? 3000 : 1500);
  },
  // 這一組的三題
  plan() {
    const ws = this.pick(3); if (!ws.length) return [];
    const P = PAGE.pop, canRead = w => !!(P.readQ && P.readQ(w));
    // 讀音題：第 2、3 個字有漢字就用它（和填空的字互換），不然從其他候選字找一個
    let rw = null;
    if (canRead(ws[1])) rw = ws[1];
    else if (canRead(ws[2])) { rw = ws[2]; ws[2] = ws[1]; }
    else rw = this.pick(8).find(w => w !== ws[0] && canRead(w)) || null;
    return [
      { kind: 'mc', w: ws[0], mode: P.mode },
      rw ? { kind: 'read', w: rw } : { kind: 'mc', w: ws[1], mode: P.rev },
      { kind: 'fill', w: ws[2] }
    ];
  },
  show(why, days) {
    const qs = this.plan(); if (!qs.length) return;
    const title = why === 'away' ? '好久不見！先考你一組' : '突擊測驗！';
    const sub = why === 'away' ? `你已經 ${days} 天沒來練習了，看看還記不記得這些字。` : '兩題選擇、一題填空，考考你學過的字。';
    // 整個畫面蓋住、不能直接關掉（沒有叉叉，點旁邊、Esc 都不會關），做完三題才回去。
    // 剛跳出來時手指可能還在點原本的題目：先顯示說明，「開始作答」要等 POP_LOCK 毫秒才按得下去
    const el = document.createElement('div');
    el.className = 'pop-full'; el.setAttribute('role', 'dialog'); el.setAttribute('aria-modal', 'true'); el.setAttribute('aria-label', title);
    el.innerHTML = `<div class="pop-in">
      <div class="pop-head"><div class="pop-title">${esc(title)}</div><p class="meta pop-sub">${esc(sub)}</p></div>
      <div class="card pop-intro" id="popIntro"><div class="pop-big" aria-hidden="true">3</div><p>三題做完才會回到原本的練習</p>
        <button class="btn solid block pop-go" id="popGo" disabled><i aria-hidden="true"></i><span>準備一下…</span></button></div>
      <div class="pop-step" id="popStep" hidden></div><div id="popq"></div>
      <div class="meta pop-note">可以在「單字庫 → 設定 → 練習」關掉突擊測驗。</div>
    </div>`;
    document.body.appendChild(el);
    const host = $('#popq', el), stepEl = $('#popStep', el), goBtn = $('#popGo', el);
    const prev = Quiz.active;   // 原本分頁上的題目：做完後鍵盤操作要接回去
    Quiz.active = null;          // 說明畫面時鍵盤不能答到後面的題目
    if (document.activeElement && document.activeElement.blur) document.activeElement.blur();
    requestAnimationFrame(() => el.classList.add('in'));
    setTimeout(() => { goBtn.disabled = false; $('span', goBtn).textContent = '開始作答'; goBtn.focus({ preventScroll: true }); }, POP_LOCK);
    // 填空用固定的 id，同時只能有一題：考填空前先清掉填空分頁，做完再畫回來（作答過的會接著下一題）
    const fillTab = $('#tab-fill');
    let cleared = false, right = 0, i = 0;
    this.active = true;
    const close = () => {
      this.active = false;
      document.body.classList.remove('typing');
      Quiz.active = prev;
      el.classList.remove('in');
      setTimeout(() => el.remove(), 200);
      if (cleared && !fillTab.hidden) renderFill();
    };
    const R = { queue: qs, idx: 0, total: qs.length, right: 0, done: false };
    const isLast = () => i === qs.length - 1;
    // 答完一題：最後一題的按鈕改成「繼續練習」並顯示這一組的成績（按鈕在作答之後才畫出來，所以等一下）
    const answered = ok => {
      if (ok) right++;
      Promise.resolve().then(() => {
        if (!isLast()) return;
        const b = $('[data-next]', host) || $('#fillGo', host);
        if (b) b.textContent = '繼續練習';
        stepEl.textContent = `這一組答對 ${right}／${qs.length} 題`;
      });
    };
    const step = () => {
      if (i >= qs.length) return close();
      R.idx = i; R.done = false; R.right = 0;
      stepEl.textContent = `第 ${i + 1} 題／共 ${qs.length} 題`;
      el.scrollTop = 0;
      const q = qs[i], w = q.w, rec = getRec(w.id);
      const go = () => { i++; step(); };
      if (q.kind === 'fill') {
        if (fillTab && fillTab.innerHTML.trim()) { fillTab.innerHTML = ''; cleared = true; }
        const src = rec.s === 'learned' && rec.due && rec.due <= today() ? 'due' : 'learn';
        fillQuestion(host, w, R, src, go);
        $$('.qhead', host).forEach(x => x.remove());
        const mo = new MutationObserver(() => { if (R.done) { mo.disconnect(); answered(R.right > 0); } });
        mo.observe($('#fillAfter', host), { childList: true });
        // 打字時（鍵盤打開）把題目捲到看得到的地方
        $('#fillIn', host).addEventListener('focus', () => setTimeout(() => $('#fillCard', host).scrollIntoView({ block: 'start', behavior: 'smooth' }), 300));
        return;
      }
      const src = rec.s === 'learned' ? 'learned' : 'learn';
      const W = PAGE.mc.word;
      const spec = q.kind === 'read' ? PAGE.pop.readQ(w) : null;
      const opts = spec ? null : shuffle([w, ...W.distractors(w, q.mode)]);
      renderChoice(host, {
        head: '',
        promptHTML: spec ? spec.prompt : W.prompt(w, q.mode),
        options: spec ? spec.options : opts.map(o => Object.assign(W.option(o, q.mode), { correct: o.id === w.id })),
        onAnswer: ok => { record(w, 'mc', ok, src); answered(ok); },
        afterHTML: () => spec ? spec.after : W.after(w),
        noAuto: isLast()
      }, go);
      if (!spec && W.speak) W.speak(w, q.mode);
    };
    goBtn.onclick = () => {
      if (goBtn.disabled) return;
      $('#popIntro', el).remove(); stepEl.hidden = false;
      step();
    };
  }
};
