// ================= 突然考一題（日文頁和語言頁共用：n5src/shared/pop-quiz.js） =================
// build.js 會把這個檔複製進兩邊的頁面（見 lib-tab.js 開頭的說明）。
// 兩種時機會跳出一題「看單字選意思」：
//   1. 做了一定題數：設定「突然考一題」（SET.pop：10／20／40 題，'off' 關閉，預設 20）。record() 每記一題就呼叫 Pop.tick()。
//   2. 隔了好幾天沒打開（POP_AWAY_DAYS 天以上）：啟動時呼叫 Pop.start()。
// 題目從「待考」和「已學會」的字裡，挑最久沒練到的幾個隨機抽一個；答題照單選記錄（會進單選錯題，不算每日題數）。
// 各頁要給 PAGE.pop = { key: 存計數的 localStorage key, mode: 單選「看單字選意思」的題型代碼 }，
// 題目和選項的畫法用 PAGE.mc.word（和單選分頁一樣）。
const POP_STEPS = [10, 20, 40];
const POP_AWAY_DAYS = 2;
const Pop = {
  timer: null,
  every() { return SET.pop === 'off' ? 0 : (POP_STEPS.includes(Number(SET.pop)) ? Number(SET.pop) : 20); },
  state() { const s = store.get(PAGE.pop.key, null); return s && typeof s === 'object' ? s : { n: 0, last: '' }; },
  save(s) { store.set(PAGE.pop.key, s); },
  // 最久沒練到的 8 個字裡隨機抽一個
  pick() {
    const list = WORDS.filter(w => { const s = getRec(w.id).s; return s === 'queued' || s === 'learned'; });
    if (list.length < 1) return null;
    list.sort((a, b) => (getRec(a.id).t || 0) - (getRec(b.id).t || 0));
    const top = list.slice(0, 8);
    return top[Math.floor(Math.random() * top.length)];
  },
  // 有其他面板、導覽、選語言畫面開著時先不跳
  busy() { return document.hidden || (typeof Sheet !== 'undefined' && Sheet.isOpen()) || !!document.querySelector('.pk-back:not([hidden]), .tour-card:not([hidden]), .lg-welcome'); },
  // 每記一題呼叫一次（record() 裡）
  tick() {
    const s = this.state();
    s.n = (s.n || 0) + 1; s.last = today();
    const every = this.every();
    if (every && s.n >= every) { s.n = 0; this.later('count'); }
    this.save(s);
  },
  // 啟動時呼叫：上次打開是 POP_AWAY_DAYS 天以前就考一題
  start() {
    if (window.AppLangs && AppLangs.welcome) return AppLangs.afterWelcome(() => this.start());
    const s = this.state(), t = today();
    const away = s.last && s.last < t ? Math.round((new Date(t) - new Date(s.last)) / 864e5) : 0;
    s.last = t; this.save(s);
    if (this.every() && away >= POP_AWAY_DAYS) this.later('away', away);
  },
  // 等目前這題的對錯顯示一下再跳；有東西開著就晚點再試（最多試 20 次）
  later(why, days, tries = 0) {
    clearTimeout(this.timer);
    this.timer = setTimeout(() => {
      if (this.busy()) { if (tries < 20) this.later(why, days, tries + 1); return; }
      this.show(why, days);
    }, tries ? 3000 : 1500);
  },
  show(why, days) {
    const w = this.pick(); if (!w) return;
    const W = PAGE.mc.word, mode = PAGE.pop.mode;
    const title = why === 'away' ? '好久不見！先考你一題' : '突然考你一題！';
    const sub = why === 'away' ? `你已經 ${days} 天沒來練習了，看看還記不記得這個字。` : `已經練了 ${this.every()} 題，來一題突擊測驗。`;
    const el = Sheet.open(title, `<p class="meta pop-sub">${esc(sub)}</p><div id="popq"></div><div class="meta pop-note">可以在「單字庫 → 設定 → 練習」調整多久考一次或關掉。</div>`, title);
    el.classList.add('pop-sheet');
    const host = $('#popq', el);
    const prev = Quiz.active;   // 原本分頁上的題目：關掉後鍵盤操作要接回去
    const done = () => { if (Quiz.active && Quiz.active.host === host) Quiz.active = prev; };
    const close = () => { done(); Sheet.close(); };
    const opts = shuffle([w, ...W.distractors(w, mode)]);
    renderChoice(host, {
      head: '',
      promptHTML: W.prompt(w, mode),
      options: opts.map(o => Object.assign(W.option(o, mode), { correct: o.id === w.id })),
      onAnswer: ok => {
        record(w, 'mc', ok, getRec(w.id).s === 'learned' ? 'learned' : 'learn');
        // 「下一題」在這裡是「繼續練習」（按鈕在 onAnswer 之後才畫出來）
        Promise.resolve().then(() => { const b = $('[data-next]', host); if (b) b.textContent = '繼續練習'; });
      },
      afterHTML: () => W.after(w),
      noAuto: true
    }, close);
    // 用叉叉或點旁邊關掉時也把鍵盤操作接回原本的題目
    const watch = setInterval(() => { if (!Sheet.isOpen() || !document.contains(host)) { clearInterval(watch); done(); } }, 300);
    if (W.speak) W.speak(w, mode);
  }
};
