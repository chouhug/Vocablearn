// ================= 每日目標＋連勝（日文頁和語言頁共用：n5src/shared/streak.js） =================
// build.js 會把這個檔複製進兩邊的頁面（見 lib-tab.js 開頭的說明）。
// 每日目標：設定「單字庫 → 設定 → 練習 → 每日目標」（SET.goal，共用的 n5:settings，預設 20）。
// 連勝：規則在 core.js 的 streakOf（一天 STREAK_MIN 題、每 7 天一個休息日、所有語言一起算、單選不算）。
// 上方「今日 x/目標 題」旁邊的火焰按鈕顯示連勝天數，點了打開說明和最近五週的日曆。
const GOAL_OPTS = [5, 10, 20, 30, 50];
const goalN = () => GOAL_OPTS.includes(Number(SET.goal)) ? Number(SET.goal) : 20;
const FLAME = '<svg viewBox="0 0 24 24" aria-hidden="true"><path fill="currentColor" d="M12 2.5c.6 3.2-1.2 5-2.8 6.8C7.6 11 6 12.8 6 15.6A6 6 0 0 0 12 21.5a6 6 0 0 0 6-5.9c0-2.4-1-4.1-2.1-5.4-.3 1.5-1 2.5-2 3 .4-3.6-.7-7.4-1.9-10.7z"/><path fill="var(--flame-in,#ffd36b)" d="M12 21.5a3.3 3.3 0 0 1-3.3-3.3c0-1.8 1.3-2.8 2.2-3.9.4 1.1 1.1 1.7 1.9 2 .2-1.2.1-2.2-.2-3.1 1.6 1 2.7 2.6 2.7 4.6a3.3 3.3 0 0 1-3.3 3.7z"/></svg>';
function streakNow() { return streakOf(S.days, today()); }
// 上方的火焰按鈕（renderGoal 會呼叫）
function renderStreak() {
  const b = $('#streakBtn'); if (!b) return;
  const st = streakNow();
  b.innerHTML = `${FLAME}<span>${st.cur}</span>`;
  b.classList.toggle('lit', st.today);
  b.setAttribute('aria-label', `連勝 ${st.cur} 天${st.today ? '，今天已經練了' : '，今天還沒練到'}（點一下看說明）`);
  if (!b.dataset.bound) { b.dataset.bound = '1'; b.onclick = () => { Sfx.pop(); openStreak(); }; }
}
// bumpDay 加完一題後呼叫：剛好達到連勝門檻或每日目標時跳提示
function dayToast(d) {
  const n = S.days[d], g = goalN();
  if (n === STREAK_MIN) {
    const st = streakOf(S.days, d);
    toast(n === g ? `今天的 ${g} 題完成了！連勝 ${st.cur} 天` : `連勝 ${st.cur} 天！`, true);
  } else if (n === g) toast(`今天的 ${g} 題完成了！`, true);
}
function openStreak() {
  const t = today(), st = streakNow(), n = S.days[t] || 0;
  const restUsed = st.rest.length ? st.rest[st.rest.length - 1] : '';
  const restOK = !restUsed || addDays(restUsed, 7) <= addDays(t, 1);
  const md = d => d.slice(5).replace('-', '/').replace(/^0/, '');
  const status = st.today ? `今天已經練了 ${n} 題，連勝保住了。`
    : st.cur ? `今天再做 ${STREAK_MIN - n} 題就能延續連勝。` : `今天做 ${STREAK_MIN} 題就開始連勝。`;
  // 最近五週（星期一開頭）
  const dow = (new Date(t + 'T12:00:00').getDay() + 6) % 7;
  const start = addDays(t, -dow - 28);
  let cells = '';
  for (let i = 0; i < 35; i++) {
    const d = addDays(start, i);
    if (d > t) { cells += '<span class="sk-d future"></span>'; continue; }
    const m = st.marks[d] || ((S.days[d] || 0) >= STREAK_MIN ? 'done' : '');
    const lab = m === 'done' ? '有練' : m === 'rest' ? '休息日' : '沒練';
    cells += `<span class="sk-d ${m}${d === t ? ' now' : ''}" title="${md(d)} ${lab}" aria-label="${md(d)} ${lab}">${m === 'rest' ? '休' : Number(d.slice(8))}</span>`;
  }
  Sheet.open(`${FLAME}連勝`, `
    <div class="sk-top"><div class="sk-big${st.today ? ' lit' : ''}">${FLAME}<b>${st.cur}</b><span>天</span></div>
      <div class="sk-best meta">最長紀錄 ${Math.max(st.best, st.cur)} 天</div></div>
    <p class="sk-status">${status}</p>
    <div class="sk-cal" role="img" aria-label="最近五週的練習紀錄">${['一', '二', '三', '四', '五', '六', '日'].map(x => `<span class="sk-h">${x}</span>`).join('')}${cells}</div>
    <div class="sk-legend meta"><span><i class="sk-d done"></i>有練</span><span><i class="sk-d rest"></i>休息日</span><span><i class="sk-d"></i>沒練</span></div>
    <p class="meta">休息日：${st.cur && !restOK ? `這週已經用過（${md(restUsed)}），${md(addDays(restUsed, 7))} 以後才能再休息` : '可以用（漏練一天連勝不會斷）'}</p>
    <div class="meta sk-rule">一天做 ${STREAK_MIN} 題就算有練：填空、聽寫、五十音、發音、文法練習題都算，單選不算。所有語言一起算。每 7 天可以有一天休息不會斷；連兩天沒練就重新開始。每日目標（現在 ${goalN()} 題）可以在「單字庫 → 設定 → 練習」改。</div>`, '連勝');
}
