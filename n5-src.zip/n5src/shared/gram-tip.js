// ================= 文法小提醒（日文頁和語言頁共用：n5src/shared/gram-tip.js） =================
// build.js 會把這個檔複製進兩邊的頁面（見 lib-tab.js 開頭的說明）。
// 字卡、單選、填空分頁的內容不多時，題目和底部分頁之間會空一大塊：在分頁最後面放一個 .gtip-slot 撐滿這塊空白，
// 最下面（靠近底部分頁）放一小段淡色的「文法小提醒」（從已過關的文法和下一個要學的文法裡抽）；放不下就不放。
// 題目照常在上面，slot 在題目下面，所以重新排版時題目不會移動：內容一變（答完出現說明、換題、換分頁、轉螢幕）就重新算。
// 各頁要給 PAGE.gram.tip(id) → { sent: 例句 HTML, zh: 例句中文, plain: 白話說明 }（沒有範例就回傳 null）。
const GramTip = {
  TABS: ['card', 'mc', 'fill'],
  id: '', lastH: 0, busy: false,
  // 換分頁時換一個文法
  pick() {
    const path = PAGE.gram.path || [];
    const ids = path.flatMap(x => x[2]).filter(id => PAGE.gram.tip(id));
    if (!ids.length) return '';
    const nx = gxNext(null);
    const pool = ids.filter(gxPassed).concat(nx && ids.includes(nx) ? [nx] : []);
    const list = pool.length ? pool : ids.slice(0, 1);
    return list[Math.floor(Math.random() * list.length)];
  },
  html(id) {
    const t = PAGE.gram.tip(id); if (!t) return '';
    return `<div class="gtip"><span class="gtip-h">文法小提醒</span><b class="gtip-t">${esc(PAGE.gram.title(id))}</b>${t.plain ? `<span class="gtip-p">${esc(t.plain)}</span>` : ''}<button class="gtip-more" data-gram="${esc(id)}">看說明 ›</button></div>`;
  },
  host() { const t = UI.tab; return this.TABS.includes(t) ? $('#tab-' + t) : null; },
  tab() { this.id = this.pick(); this.lastH = 0; this.layout(); },
  slotOf(host) { const l = host.lastElementChild; return l && l.classList.contains('gtip-slot') ? l : null; },
  // 有東西變了：內容高度變了（或 slot 被重畫掉）才重新排
  check() {
    const host = this.host(); if (!host || host.hidden || document.body.classList.contains('typing')) return;
    const slot = this.slotOf(host);
    if (slot && Math.abs(this.contentH(host, slot) - this.lastH) <= 2) return;
    this.layout();
  },
  contentH(host, slot) { return host.scrollHeight - (slot && !slot.hidden ? slot.offsetHeight + 16 : 0); },
  layout() {
    const host = this.host(); if (!host || host.hidden || this.busy) return;
    this.busy = true;
    // 其他分頁留下的 slot 拿掉（只有目前這個分頁有）
    $$('.gtip-slot').forEach(x => { if (x.parentNode !== host) x.remove(); });
    let slot = this.slotOf(host);
    if (!slot) { slot = document.createElement('div'); slot.className = 'gtip-slot'; host.append(slot); }
    slot.innerHTML = ''; slot.style.height = '0px'; slot.hidden = true;
    const h = host.scrollHeight;   // 沒有 slot 時的內容高度
    this.lastH = h;
    // 底部到畫面底部要留 main 和 .wrap 的 padding-bottom（底部分頁的高度＋間距），剛好不會出現捲動；slot 和內容之間有 flex gap 16px
    const top = host.getBoundingClientRect().top + window.scrollY;
    const main = $('#main'), wrap = main && main.firstElementChild;
    const pad = el => el ? parseFloat(getComputedStyle(el).paddingBottom) || 0 : 0;
    const free = Math.floor(window.innerHeight - pad(main) - pad(wrap) - top - h - 16);
    if (free > 40 && this.id) {
      slot.hidden = false; slot.style.height = free + 'px';
      slot.innerHTML = this.html(this.id);
      const c = slot.firstElementChild;
      if (!c || c.offsetHeight > free) { slot.innerHTML = ''; slot.hidden = true; slot.style.height = '0px'; }
    }
    this.busy = false;
  }
};
// 內容有變化就檢查（下一個畫面更新前做一次）
{
  let raf = 0;
  const later = () => { if (!raf) raf = requestAnimationFrame(() => { raf = 0; GramTip.check(); }); };
  new MutationObserver(recs => { if (!GramTip.busy && recs.some(r => !(r.target.closest && r.target.closest('.gtip-slot')))) later(); })
    .observe($('#main'), { childList: true, subtree: true });
  let rt = 0;
  window.addEventListener('resize', () => { if (document.body.classList.contains('typing')) return; clearTimeout(rt); rt = setTimeout(() => GramTip.layout(), 150); });
}
