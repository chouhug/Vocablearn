// ================= 文法小提醒＋題目靠下（日文頁和語言頁共用：n5src/shared/gram-tip.js） =================
// build.js 會把這個檔複製進兩邊的頁面（見 lib-tab.js 開頭的說明）。
// 字卡、單選、填空分頁的內容不多時，下面（題目和底部分頁之間）會空一大塊。
// 這裡在分頁最上面放一個 .gtip-slot：把剩下的空間撐在上面，題目和分類標籤就貼到下面（手指比較好按），
// 空出來的地方放一張「文法小提醒」（從已過關的文法和下一個要學的文法裡抽）；放不下就只留空白、不放卡片。
// 內容變長（答完出現說明）時不重新排，避免題目往上跳、按錯；換題（內容變短）、換分頁、轉螢幕時才重新排。
// 各頁要給 PAGE.gram.tip(id) → { sent: 例句 HTML, zh: 例句中文, plain: 白話說明 }（沒有範例就回傳 null）。
const GramTip = {
  TABS: ['card', 'mc', 'fill'],
  id: '', lastH: 0, busy: false,
  // 換分頁時換一個文法
  pick() {
    const path = PAGE.gram.path || [];
    const ids = path.flatMap(x => x[2]).filter(id => PAGE.gram.tip(id));
    if (!ids.length) return '';
    const nx = gxNext(null);
    const pool = ids.filter(gxPassed).concat(nx && ids.includes(nx) ? [nx] : []);
    const list = pool.length ? pool : ids.slice(0, 1);
    return list[Math.floor(Math.random() * list.length)];
  },
  html(id, full) {
    const t = PAGE.gram.tip(id); if (!t) return '';
    return `<div class="card gtip"><div class="gtip-h"><span>文法小提醒</span><button class="gtip-more" data-gram="${esc(id)}">看說明 ›</button></div>
      <b class="gtip-t">${esc(PAGE.gram.title(id))}</b>
      ${full ? `<div class="gtip-ex">${t.sent}<div class="meta">${esc(t.zh)}</div></div>` : ''}
      ${t.plain ? `<p class="gtip-p">${esc(t.plain)}</p>` : ''}</div>`;
  },
  host() { const t = UI.tab; return this.TABS.includes(t) ? $('#tab-' + t) : null; },
  tab() { this.id = this.pick(); this.lastH = 0; this.layout(); },
  // 有東西變了：內容變長就不動，變短（換題、重畫）才重新排
  check() {
    const host = this.host(); if (!host || host.hidden || document.body.classList.contains('typing')) return;
    const slot = host.firstElementChild && host.firstElementChild.classList.contains('gtip-slot') ? host.firstElementChild : null;
    const h = this.contentH(host, slot);
    if (slot && Math.abs(h - this.lastH) <= 2) return;   // 差不多：不動
    // 答完題目（出現說明）變長時不動，題目才不會往上跳；字卡換一張、換題就重新排
    const answered = (Quiz.active && Quiz.active.answered && host.contains(Quiz.active.host)) || !!host.querySelector('#fillIn[readonly]');
    if (slot && h > this.lastH && answered) return;
    this.layout();
  },
  contentH(host, slot) { return host.scrollHeight - (slot ? slot.offsetHeight + 16 : 0); },
  layout() {
    const host = this.host(); if (!host || host.hidden || this.busy) return;
    this.busy = true;
    let slot = host.firstElementChild && host.firstElementChild.classList.contains('gtip-slot') ? host.firstElementChild : null;
    if (!slot) { slot = document.createElement('div'); slot.className = 'gtip-slot'; host.prepend(slot); }
    slot.innerHTML = ''; slot.style.height = '0px'; slot.hidden = true;
    const h = host.scrollHeight;   // 沒有 slot 時的內容高度
    this.lastH = h;
    // 題目底部到畫面底部要留 main 和 .wrap 的 padding-bottom（底部分頁的高度＋間距），剛好不會出現捲動；slot 和內容之間有 flex gap 16px
    const top = host.getBoundingClientRect().top + window.scrollY;
    const main = $('#main'), wrap = main && main.firstElementChild;
    const pad = el => el ? parseFloat(getComputedStyle(el).paddingBottom) || 0 : 0;
    const bottom = window.innerHeight - pad(main) - pad(wrap);
    const free = Math.floor(bottom - top - h - 16);
    if (free > 24) {
      slot.hidden = false; slot.style.height = free + 'px';
      // 放得下完整的提醒就放完整的，不然放精簡的（只有名稱和白話），再不行就只留空白
      for (const full of [true, false]) {
        slot.innerHTML = this.id ? this.html(this.id, full) : '';
        const c = slot.firstElementChild;
        if (!c) break;
        if (c.offsetHeight <= free) break;
        slot.innerHTML = '';
      }
    }
    this.busy = false;
  }
};
// 內容有變化就檢查（下一個畫面更新前做一次）
{
  let raf = 0;
  const later = () => { if (!raf) raf = requestAnimationFrame(() => { raf = 0; GramTip.check(); }); };
  new MutationObserver(recs => { if (!GramTip.busy && recs.some(r => !(r.target.closest && r.target.closest('.gtip-slot')))) later(); })
    .observe($('#main'), { childList: true, subtree: true });
  let rt = 0;
  window.addEventListener('resize', () => { if (document.body.classList.contains('typing')) return; clearTimeout(rt); rt = setTimeout(() => GramTip.layout(), 150); });
}
