// ================= 我的單字：新增／編輯自己的單字（n5src/shared/mine.js） =================
// 自己新增的字存在進度紀錄的 c 欄位（S.items[id].c），所以會跟著合併和 Google 同步；頁面的 syncMine() 把它們放進 WORDS。
// 各頁不一樣的地方在 PAGE.mine：
//   prefix 紀錄 id 的開頭、lang 輸入框的語言代碼、name 語言名稱、posOpts 詞性選項（沒有就不顯示詞性）、
//   readings（日文）：多兩個欄位「讀音」c.r 和「例句的讀法」c.sr、
//   dict（有才顯示「查字典」，程式在 shared/dict.js）：線上字典用的語言代碼、
//   needReading(word)（日文）：這個字要不要填讀音、autoReading(word)（日文）：查讀音，回傳對得上的假名或 ''、
//   guessForm(例句, 單字)：沒填「例句裡的寫法」時猜例句裡的樣子（找不到回傳 ''）、
//   builtin(word) 單字庫裡原本就有的同一個字、check(c) 檢查內容（回傳錯誤訊息或 ''）、changed() 存檔或刪除後更新畫面
// 表單只露出「單字、（讀音）、意思」三欄：打完單字會自動查字典，把第一個中文翻譯（日文連讀音）填好；
// 例句、詞性這些放在「更多」裡，可以不填
// look：打開就先查一次字典（從「查字典並加到我的單字」進來）
function editMine(id, preset, look_) {
  const M = PAGE.mine;
  const old = id && S.items[id] && S.items[id].c;
  const c = old || { w: preset || '', zh: '', p: 'o' };
  const field = (k, label, val, lang) => `<label class="label" for="my-${k}">${label}</label><input id="my-${k}" type="text" value="${esc(val || '')}"${lang ? ` lang="${lang}"` : ''} autocapitalize="off" autocorrect="off" spellcheck="false"${k === 'w' && M.dict ? ' enterkeyhint="search"' : ''}>`;
  const hasMore = !!(c.s || (c.p && c.p !== 'o'));
  const el = Sheet.open(old ? '編輯我的單字' : '新增自己的單字', `<form id="myForm" class="myform" autocomplete="off" novalidate>
    ${field('w', `單字或片語（${esc(M.name)}）`, c.w, M.lang)}
    ${M.readings ? `<div id="myRBox"${M.needReading(c.w || '') || c.r ? '' : ' hidden'}>${field('r', '讀音（假名）', c.r, M.lang)}</div>` : ''}
    ${field('zh', '意思', c.zh)}
    ${M.dict ? '<div class="dictbox" id="myDict" hidden></div>' : ''}
    <details class="mymore" id="myMore"${hasMore ? ' open' : ''}><summary>更多：例句${M.posOpts ? '、詞性' : ''}（可以不填）</summary><div class="myform">
    ${M.posOpts ? `<label class="label" for="my-p">詞性（只用來篩選）</label>
    <select id="my-p">${M.posOpts.map(([k, l]) => `<option value="${k}"${(c.p || 'o') === k ? ' selected' : ''}>${l}</option>`).join('')}</select>` : ''}
    <label class="label" for="my-s">例句</label>
    <textarea id="my-s" lang="${M.lang}" rows="2" autocapitalize="off" autocorrect="off" spellcheck="false">${esc(c.s || '')}</textarea>
    ${field('sz', '例句的中文', c.sz)}
    ${M.readings ? field('sr', '例句的讀法（整句用平假名；填了例句的漢字才有振り仮名）', c.sr, M.lang) : ''}
    ${field('a', '例句裡的寫法（通常不用填，App 會自己找；找錯了再填）', c.a, M.lang)}
    </div></details>
    <div class="hl-warn" id="myMsg" role="alert" hidden></div>
    <div class="btnrow${old ? '' : ' one'}">${old ? '<button class="btn quiet" type="button" id="myDel">刪除</button>' : ''}<button class="btn solid" type="submit">儲存</button></div>
    <p class="meta" style="margin:0">存好就列入考題。${M.dict ? '打完單字會自動查字典（Wiktionary、MyMemory），填好的意思可以自己改。' : ''}</p>
  </form>`);
  const val = k => { const x = $('#my-' + k, el); return x ? x.value.trim().replace(/\s+/g, ' ') : ''; };
  const more = $('#myMore', el);
  const msg = t => { const m = $('#myMsg', el); m.textContent = t; m.hidden = !t; if (t) m.scrollIntoView({ block: 'nearest' }); };
  const done = text => { saveLocal(); Cloud.schedule(); Sheet.close(); M.changed(); toast(text); };
  const rbox = $('#myRBox', el);
  const showR = () => { if (rbox) rbox.hidden = !(M.needReading(val('w')) || val('r')); };
  $('#myForm', el).onsubmit = e => {
    e.preventDefault();
    let n = { w: val('w'), zh: val('zh') };
    if (M.posOpts) n.p = $('#my-p', el).value;
    if (M.readings && val('r')) n.r = val('r');
    if (val('s')) { n.s = val('s'); if (val('sz')) n.sz = val('sz'); if (val('a') && val('a') !== n.w) n.a = val('a'); if (M.readings && val('sr')) n.sr = val('sr'); }
    const nid = M.prefix + n.w;
    reloadShared();
    let err = !n.w ? '請輸入單字。' : !n.zh ? '請輸入意思（也可以等字典查完自動填）。' : '';
    if (!err && nid !== id) err = M.builtin(n.w) ? `單字庫裡本來就有「${n.w}」，用上面的搜尋就找得到。` : S.items[nid] && S.items[nid].c ? `你已經新增過「${n.w}」了。` : '';
    if (!err) err = M.check(n);
    // 例句裡找不到原形：猜例句裡的寫法（whisker → whiskers、食べる → 食べました）
    if (err && n.s && !n.a && M.guessForm) {
      const g = M.guessForm(n.s, n.w), n2 = g && g !== n.w ? Object.assign({}, n, { a: g }) : null;
      if (n2 && !M.check(n2)) { n = n2; err = ''; }
    }
    if (err) { Sfx.ng(); if (/例句/.test(err)) more.open = true; return msg(err); }
    const now = Date.now(), prev = id && S.items[id];
    const r = Object.assign(prev ? JSON.parse(JSON.stringify(prev)) : blankRec(), { c: n, t: now });
    if (!prev) { r.s = 'queued'; r.q = now; }
    if (prev && nid !== id) S.items[id] = Object.assign(blankRec(), { t: now });   // 改了單字本身：進度帶到新的，舊的刪掉
    S.items[nid] = r;
    done(old ? '已儲存' : '已加到我的單字，並列入考題');
  };
  // ---- 自動查字典：打完單字（離開欄位或按 Enter）就查，第一個中文翻譯直接填進「意思」----
  const dbox = $('#myDict', el), wIn = $('#my-w', el);
  let seq = 0, lastWord = old ? c.w : '';
  const runLook = async force => {
    const word = val('w');
    if (!dbox || !word || (!force && word === lastWord)) return;
    lastWord = word;
    const my = ++seq, zhIn = $('#my-zh', el), rIn = $('#my-r', el);
    dbox.hidden = false; dbox.innerHTML = '<p class="meta" style="margin:0">正在查「' + esc(word) + '」…</p>';
    const needR = M.readings && M.autoReading && M.needReading(word) && !val('r');
    const [r, rd] = await Promise.all([dictLookup(word, M.dict), needR ? M.autoReading(word) : '']);
    if (my !== seq || !document.contains(dbox)) return;   // 查的時候又改了單字，或面板已經關了
    const notes = [];
    if (rd && rIn && !val('r')) { rIn.value = rd; showR(); notes.push('讀音'); }
    if (r.offline) { dbox.innerHTML = '<p class="meta" style="margin:0">連不上字典。意思請自己填，有網路時可以<button type="button" class="linkbtn" id="myRe">再查一次</button>。</p>'; }
    else if (!r.defs.length && !r.zh.length) { dbox.innerHTML = '<p class="meta" style="margin:0">字典裡查不到「' + esc(word) + '」（可以檢查拼字，或改查原形）。意思請自己填。</p>'; }
    else {
      const first = r.zh[0] || (r.defs[0] && r.defs[0].defs[0]) || '';
      if (first && !zhIn.value.trim()) { zhIn.value = first; notes.push('意思'); }
      dbox.innerHTML = (notes.length ? `<p class="meta dict-auto" style="margin:0">已自動填入${notes.join('和')}，不對可以直接改，或點下面其他的意思。</p>` : '') +
        (r.zh.length ? `<div class="label">中文（機器翻譯，可能不準）</div><div class="chips dict-zh">${r.zh.map(z => `<button type="button" class="chip" data-fill="${esc(z)}"${z === zhIn.value.trim() ? ' aria-pressed="true"' : ''}>${esc(z)}</button>`).join('')}</div>` : '') +
        (r.defs.length ? `<details class="dict-en"${r.zh.length ? '' : ' open'}><summary>英文解釋（Wiktionary）</summary>${r.defs.map(d => `<div class="dict-pos">${esc(d.zh)}${d.zh !== d.pos && d.pos ? ` <span lang="en">${esc(d.pos)}</span>` : ''}</div>${d.defs.map(x => `<button type="button" class="dict-def" lang="en" data-fill="${esc(x)}">${esc(x)}</button>`).join('')}`).join('')}</details>` : '');
      // 點一下：換成這個意思；按住已經填好的再點別的，會接在後面
      $$('[data-fill]', dbox).forEach(b => b.onclick = () => {
        const t = b.dataset.fill, cur = zhIn.value.trim(), auto = notes.includes('意思') && cur === first;
        if (!cur || auto) zhIn.value = t; else if (!cur.split('；').includes(t)) zhIn.value = cur + '；' + t;
        notes.length = 0;
        $$('[data-fill]', dbox).forEach(x => x.setAttribute('aria-pressed', String(zhIn.value.split('；').includes(x.dataset.fill))));
        msg('');
      });
      const sel = $('#my-p', el);
      if (sel && r.defs.length && sel.value === 'o' && M.posOpts.some(o => o[0] === r.defs[0].p)) sel.value = r.defs[0].p;
    }
    const re = $('#myRe', dbox); if (re) re.onclick = () => runLook(true);
  };
  wIn.addEventListener('input', showR);
  wIn.addEventListener('change', () => runLook());
  wIn.addEventListener('keydown', e => { if (e.key === 'Enter' && dbox) { e.preventDefault(); runLook(); $('#my-zh', el).focus(); } });
  if (dbox && look_ && !old && c.w) runLook();
  const del = $('#myDel', el);
  if (del) del.onclick = () => {
    if (!del.dataset.sure) { del.dataset.sure = '1'; del.textContent = '確定刪除？'; return; }
    reloadShared();
    S.items[id] = Object.assign(blankRec(), { t: Date.now() });   // 留下空白紀錄（帶時間），同步時其他裝置也會刪掉
    done('已刪除');
  };
  if (!c.w) setTimeout(() => wIn.focus(), 250);
}
