// ================= 我的單字：新增／編輯自己的單字（n5src/shared/mine.js） =================
// 自己新增的字存在進度紀錄的 c 欄位（S.items[id].c），所以會跟著合併和 Google 同步；頁面的 syncMine() 把它們放進 WORDS。
// 各頁不一樣的地方在 PAGE.mine：
//   prefix 紀錄 id 的開頭、lang 輸入框的語言代碼、name 語言名稱、posOpts 詞性選項、
//   dict（有才顯示「查字典」，程式在 shared/dict.js）：線上字典用的語言代碼、
//   builtin(word) 單字庫裡原本就有的同一個字、check(c) 檢查內容（回傳錯誤訊息或 ''）、changed() 存檔或刪除後更新畫面
// look：打開就先查一次字典（從「查字典並加到我的單字」進來）
function editMine(id, preset, look_) {
  const M = PAGE.mine;
  const old = id && S.items[id] && S.items[id].c;
  const c = old || { w: preset || '', zh: '', p: 'o' };
  const field = (k, label, val, lang) => `<label class="label" for="my-${k}">${label}</label><input id="my-${k}" type="text" value="${esc(val || '')}"${lang ? ` lang="${lang}"` : ''} autocapitalize="off" autocorrect="off" spellcheck="false">`;
  const el = Sheet.open(old ? '編輯我的單字' : '新增自己的單字', `<form id="myForm" class="myform" autocomplete="off" novalidate>
    ${field('w', `單字或片語（${esc(M.name)}）`, c.w, M.lang)}
    ${M.dict ? '<button class="btn quiet" type="button" id="myLook">查字典</button><div class="dictbox" id="myDict" hidden></div>' : ''}
    ${field('zh', '意思', c.zh)}
    <label class="label" for="my-p">詞性</label>
    <select id="my-p">${M.posOpts.map(([k, l]) => `<option value="${k}"${(c.p || 'o') === k ? ' selected' : ''}>${l}</option>`).join('')}</select>
    <label class="label" for="my-s">例句（可以不填）</label>
    <textarea id="my-s" lang="${M.lang}" rows="2" autocapitalize="off" autocorrect="off" spellcheck="false">${esc(c.s || '')}</textarea>
    ${field('a', '例句裡的寫法（這個字在例句裡有變化才要填）', c.a, M.lang)}
    ${field('sz', '例句的中文（可以不填）', c.sz)}
    <div class="hl-warn" id="myMsg" role="alert" hidden></div>
    <div class="btnrow${old ? '' : ' one'}">${old ? '<button class="btn quiet" type="button" id="myDel">刪除</button>' : ''}<button class="btn solid" type="submit">儲存</button></div>
    <p class="meta" style="margin:0">存好後會直接列入考題，字卡、單選、填空都會出；沒有例句時，填空直接考這個字。用 Google 登入會同步到其他裝置；備份碼不包含自己新增的單字。${M.dict ? '按「查字典」時，這個字會送到 Wiktionary 和 MyMemory 兩個免費服務去查。' : ''}</p>
  </form>`);
  const val = k => $('#my-' + k, el).value.trim().replace(/\s+/g, ' ');
  const msg = t => { const m = $('#myMsg', el); m.textContent = t; m.hidden = !t; if (t) m.scrollIntoView({ block: 'nearest' }); };
  const done = text => { saveLocal(); Cloud.schedule(); Sheet.close(); M.changed(); toast(text); };
  $('#myForm', el).onsubmit = e => {
    e.preventDefault();
    const n = { w: val('w'), zh: val('zh'), p: $('#my-p', el).value };
    if (val('s')) { n.s = val('s'); if (val('sz')) n.sz = val('sz'); if (val('a') && val('a') !== n.w) n.a = val('a'); }
    const nid = M.prefix + n.w;
    reloadShared();
    let err = !n.w ? '請輸入單字。' : !n.zh ? '請輸入意思。' : '';
    if (!err && nid !== id) err = M.builtin(n.w) ? `單字庫裡本來就有「${n.w}」，用上面的搜尋就找得到。` : S.items[nid] && S.items[nid].c ? `你已經新增過「${n.w}」了。` : '';
    if (!err) err = M.check(n);
    if (err) { Sfx.ng(); return msg(err); }
    const now = Date.now(), prev = id && S.items[id];
    const r = Object.assign(prev ? JSON.parse(JSON.stringify(prev)) : blankRec(), { c: n, t: now });
    if (!prev) { r.s = 'queued'; r.q = now; }
    if (prev && nid !== id) S.items[id] = Object.assign(blankRec(), { t: now });   // 改了單字本身：進度帶到新的，舊的刪掉
    S.items[nid] = r;
    done(old ? '已儲存' : '已加到我的單字，並列入考題');
  };
  // ---- 查字典：結果點一下填進「意思」----
  const look = $('#myLook', el), dbox = $('#myDict', el);
  let seq = 0;
  const runLook = async () => {
    const word = val('w');
    if (!word) { $('#my-w', el).focus(); return; }
    const my = ++seq;
    look.disabled = true; look.textContent = '查詢中…';
    dbox.hidden = false; dbox.innerHTML = '<p class="meta" style="margin:0">正在查「' + esc(word) + '」…</p>';
    const r = await dictLookup(word, M.dict);
    if (my !== seq || !document.contains(dbox)) return;   // 查的時候又按了一次，或面板已經關了
    look.disabled = false; look.textContent = '再查一次';
    if (r.offline) { dbox.innerHTML = '<p class="meta" style="margin:0">連不上字典，請確認網路後再試。意思可以先自己填。</p>'; return; }
    if (!r.defs.length && !r.zh.length) { dbox.innerHTML = '<p class="meta" style="margin:0">字典裡查不到「' + esc(word) + '」（可以檢查拼字，或改查原形）。意思可以自己填。</p>'; return; }
    dbox.innerHTML = (r.zh.length ? `<div class="label">中文（機器翻譯，可能不準）</div><div class="chips dict-zh">${r.zh.map(z => `<button type="button" class="chip" data-fill="${esc(z)}">${esc(z)}</button>`).join('')}</div>` : '') +
      (r.defs.length ? `<div class="label">英文解釋（Wiktionary）</div>${r.defs.map(d => `<div class="dict-pos">${esc(d.zh)}${d.zh !== d.pos && d.pos ? ` <span lang="en">${esc(d.pos)}</span>` : ''}</div>${d.defs.map(x => `<button type="button" class="dict-def" lang="en" data-fill="${esc(x)}">${esc(x)}</button>`).join('')}`).join('')}` : '') +
      '<p class="meta" style="margin:0">點一下就會填進「意思」，填完還可以自己改。</p>';
    $$('[data-fill]', dbox).forEach(b => b.onclick = () => {
      const inp = $('#my-zh', el), t = b.dataset.fill, cur = inp.value.trim();
      if (!cur) inp.value = t; else if (!cur.split('；').includes(t)) inp.value = cur + '；' + t;
      b.setAttribute('aria-pressed', 'true'); msg('');
    });
    // 詞性還沒選（其他）時，照字典的第一個詞性選
    const sel = $('#my-p', el);
    if (r.defs.length && sel.value === 'o' && M.posOpts.some(o => o[0] === r.defs[0].p)) sel.value = r.defs[0].p;
  };
  if (look) { look.onclick = runLook; if (look_ && !old && c.w) runLook(); }
  const del = $('#myDel', el);
  if (del) del.onclick = () => {
    if (!del.dataset.sure) { del.dataset.sure = '1'; del.textContent = '確定刪除？'; return; }
    reloadShared();
    S.items[id] = Object.assign(blankRec(), { t: Date.now() });   // 留下空白紀錄（帶時間），同步時其他裝置也會刪掉
    done('已刪除');
  };
  if (!c.w) setTimeout(() => $('#my-w', el).focus(), 250);
}
