// ================= 動詞變化小提醒＋題目置中（日文頁和語言頁共用：n5src/shared/verb-tip.js） =================
// build.js 會把這個檔複製進兩邊的頁面（見 lib-tab.js 開頭的說明）。
// 字卡、單選、填空分頁的內容不多時，題目和底部分頁之間會空一大塊：
//   - 放得下：在分頁最後面放一個 .vtip-slot 撐滿空白，最下面（靠近底部分頁）放一小段「動詞變化」，題目照常在上面。
//   - 放不下或設定關掉（SET.vtip === 'off'）：把題目放在中間（分頁上面加 padding-top）。
// 動詞從「待考」和「已學會」的動詞裡抽（沒有就從常用動詞抽），換分頁時換一個。
// 什麼時候重新排：換分頁、轉螢幕、內容高度變了；但置中時答完題目（出現說明）內容變長不重排，題目才不會往上跳。
// 各頁要給 PAGE.vtip = { pick(): 動詞或 null, html(w, short): 變化的 HTML（short＝精簡版）, more(w): 「看更多」按鈕的屬性 }。
const VerbTip = {
  TABS: ['card', 'mc', 'fill'],
  w: null, lastH: 0, busy: false,
  on() { return SET.vtip !== 'off'; },
  host() { const t = UI.tab; return this.TABS.includes(t) ? $('#tab-' + t) : null; },
  slotOf(host) { const l = host.lastElementChild; return l && l.classList.contains('vtip-slot') ? l : null; },
  html(short) {
    const w = this.w; if (!w) return '';
    return `<div class="vtip"><div class="vtip-h"><span>動詞變化</span><button class="vtip-more" ${PAGE.vtip.more(w)}>看更多 ›</button></div>${PAGE.vtip.html(w, short)}</div>`;
  },
  // 換分頁時換一個動詞
  tab() { this.w = this.on() ? PAGE.vtip.pick() : null; this.lastH = 0; this.layout(); },
  // 內容高度變了才重新排；置中時答完題目變長就不動
  check() {
    const host = this.host(); if (!host || host.hidden || document.body.classList.contains('typing')) return;
    const slot = this.slotOf(host);
    const h = host.scrollHeight - (slot && !slot.hidden ? slot.offsetHeight + 16 : 0) - (parseFloat(host.style.paddingTop) || 0);
    if (Math.abs(h - this.lastH) <= 2) return;
    const answered = (Quiz.active && Quiz.active.answered && host.contains(Quiz.active.host)) || !!host.querySelector('#fillIn[readonly]');
    if (h > this.lastH && answered && host.style.paddingTop) return;
    this.layout();
  },
  layout() {
    const host = this.host(); if (!host || host.hidden || this.busy) return;
    this.busy = true;
    // 其他分頁的 slot、置中拿掉
    $$('.vtip-slot').forEach(x => { if (x.parentNode !== host) x.remove(); });
    this.TABS.forEach(t => { const el = $('#tab-' + t); if (el && el !== host) el.style.paddingTop = ''; });
    let slot = this.slotOf(host);
    if (!slot) { slot = document.createElement('div'); slot.className = 'vtip-slot'; host.append(slot); }
    slot.innerHTML = ''; slot.style.height = '0px'; slot.hidden = true; host.style.paddingTop = '';
    const h = host.scrollHeight;   // 沒有 slot、沒有置中時的內容高度
    this.lastH = h;
    // 底部到畫面底部要留 main 和 .wrap 的 padding-bottom（底部分頁的高度＋間距），剛好不會出現捲動；slot 和內容之間有 flex gap 16px
    const top = host.getBoundingClientRect().top + window.scrollY;
    const main = $('#main'), wrap = main && main.firstElementChild;
    const pad = el => el ? parseFloat(getComputedStyle(el).paddingBottom) || 0 : 0;
    const space = Math.floor(window.innerHeight - pad(main) - pad(wrap) - top - h);
    let placed = false;
    if (this.on() && this.w && space - 16 > 40) {
      slot.hidden = false; slot.style.height = (space - 16) + 'px';
      for (const short of [false, true]) {
        slot.innerHTML = this.html(short);
        const c = slot.firstElementChild;
        if (c && c.offsetHeight <= space - 16) { placed = true; break; }
      }
      if (!placed) { slot.innerHTML = ''; slot.hidden = true; slot.style.height = '0px'; }
    }
    // 沒放提醒：題目放在中間
    if (!placed && space > 8) host.style.paddingTop = Math.floor(space / 2) + 'px';
    this.busy = false;
  }
};
// 內容有變化就檢查（下一個畫面更新前做一次）
{
  let raf = 0;
  const later = () => { if (!raf) raf = requestAnimationFrame(() => { raf = 0; VerbTip.check(); }); };
  new MutationObserver(recs => { if (!VerbTip.busy && recs.some(r => !(r.target.closest && r.target.closest('.vtip-slot')))) later(); })
    .observe($('#main'), { childList: true, subtree: true });
  let rt = 0;
  window.addEventListener('resize', () => { if (document.body.classList.contains('typing')) return; clearTimeout(rt); rt = setTimeout(() => VerbTip.layout(), 150); });
}
