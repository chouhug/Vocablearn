// ================= 「最近學過」的範圍（日文頁和語言頁共用：n5src/shared/recent.js） =================
// build.js 會把這個檔複製進兩邊的頁面（見 lib-tab.js 開頭的說明）。
// SET.recent：d<N> = 最近 N 天學過的字（照日曆算，最近 1 天＝昨天和今天），c<N> = 最近學過的 N 個字（開始學的時間 q，舊紀錄用 t）。
// 選單只有三項：目前的範圍、「自訂天數…」「自訂字數…」（打開 recentAsk 的面板自己填數字）。預設是最近 1 天。
// 字卡、單選、填空（日文還有聽寫）共用同一個範圍。
const RECENT_MAX = { d: 365, c: 999 };
function recentName(u, n) { return u === 'd' ? `最近 ${n} 天` : `最近 ${n} 個字`; }
// 目前的範圍 [單位, 數字]；格式不對就當成最近 1 天
function recentVal(v = SET.recent) {
  const m = /^([dc])(\d+)$/.exec(v || '');
  if (!m) return ['d', 1];
  return [m[1], Math.min(RECENT_MAX[m[1]], Math.max(1, +m[2]))];
}
function recentLabel() { const [u, n] = recentVal(); return recentName(u, n); }
// 選單的選項：目前的範圍＋兩個「自訂」
function recentOpts() { const [u, n] = recentVal(); return [[u + n, recentName(u, n)], ['+d', '自訂天數…'], ['+c', '自訂字數…']]; }
const recentT = id => { const r = getRec(id); return r.q || r.t || 0; };
// 學過的字（待考、已學會，有開始學的時間）
const recentCand = () => WORDS.filter(w => { const r = getRec(w.id); return (r.s === 'queued' || r.s === 'learned') && recentT(w.id) > 0; });
function recentIds() {
  const [u, n] = recentVal();
  const cand = recentCand();
  if (u === 'c') return new Set(cand.sort((a, b) => recentT(b.id) - recentT(a.id)).slice(0, n).map(w => w.id));
  return new Set(cand.filter(w => agoDays(recentT(w.id)) <= n).map(w => w.id));
}
// 開始學的時間 t 是幾天前（照日曆算：今天 0、昨天 1）。「最近 N 天」＝ N 天前（含）以後學的，和字卡左上角的「N 天前學過」一致
const agoDays = t => Math.round((new Date(today()) - new Date(ymd(new Date(t)))) / 864e5);
// 目前學過的量：字數（u = 'c'）或從最早學的字到現在幾天（u = 'd'，至少 1）；還沒學過字就是 0
function recentAvail(u) {
  const cand = recentCand();
  if (!cand.length) return 0;
  if (u === 'c') return cand.length;
  return Math.max(1, ...cand.map(w => agoDays(recentT(w.id))));
}
// 這個字是幾天前開始學的（字卡左上角）：今天學過、昨天學過、N 天前學過；沒學過就是 ''
function learnedAgo(id) {
  const r = getRec(id);
  if (!(r.s === 'queued' || r.s === 'learned')) return '';
  const t = recentT(id); if (!t) return '';
  const d = agoDays(t);
  return d <= 0 ? '今天學過' : d === 1 ? '昨天學過' : `${d} 天前學過`;
}
// 換了範圍：存起來，重新出題
function recentSet(v, after) { SET.recent = v; saveSet(); mcRound = null; fillRound = null; deck = null; if (after) after(); }
// 自己填天數（u = 'd'）或字數（u = 'c'）的面板；填好按「確定」才會換。填太大會改成學過的量（recentAvail）
function recentAsk(u, after) {
  const [cu, cn] = recentVal(), max = RECENT_MAX[u], have = recentAvail(u), unit = u === 'd' ? '天' : '個字';
  const el = Sheet.open(u === 'd' ? '自訂天數' : '自訂字數', `<form id="recentForm" class="recent-form" novalidate>
      <p class="meta">${u === 'd' ? '出最近幾天內開始學的字。' : '出最近開始學的幾個字。'}</p>${have ? `<p class="meta">${u === 'd' ? `你最早是 ${have} 天前開始學的，填更多會自動改成 ${have}。` : `你學過 ${have} 個字，填更多會自動改成 ${have}。`}</p>` : ''}
      <label class="recent-row" for="recentN"><span>最近</span><input id="recentN" type="number" inputmode="numeric" pattern="[0-9]*" min="1" step="1" value="${cu === u ? cn : u === 'd' ? 14 : 100}" aria-label="${u === 'd' ? '天數' : '字數'}"><span>${unit}</span></label>
      <p class="recent-err" id="recentErr" role="alert"></p>
      <button class="btn solid block" type="submit">確定</button>
    </form>`, u === 'd' ? '自訂天數' : '自訂字數');
  const inp = $('#recentN', el), err = $('#recentErr', el);
  setTimeout(() => { inp.focus(); inp.select(); }, 60);
  $('#recentForm', el).onsubmit = e => {
    e.preventDefault();
    const s = String(inp.value).trim();
    let n = Number(s);
    if (!/^\d+$/.test(s) || n < 1) { err.textContent = '請填 1 以上的整數'; inp.focus(); return; }
    // 填得比學過的量還多：自動改成學過的量（還沒學過字就只限上限）
    const cap = have ? Math.min(have, max) : max;
    const cut = n > cap; if (cut) n = cap;
    Sheet.close(); recentSet(u + n, after);
    toast(cut && have && n === have ? (u === 'd' ? `你最早是 ${n} 天前開始學的，已改成最近 ${n} 天` : `你學過 ${n} 個字，已改成最近 ${n} 個字`) : `最近學過：${recentName(u, n)}`);
  };
}
// 選單變了：選「自訂…」就打開面板（選單先跳回原本的值，按確定才換），其他直接換
function recentChange(sel, after) {
  const v = sel.value;
  if (v[0] !== '+') return recentSet(v, after);
  sel.value = recentVal().join('');
  setTimeout(() => recentAsk(v[1], after), 200);   // 等選單面板收起來
}
function recentCtl(onChange) { return { html: pillSelect('recentSel', '最近學過的範圍', recentOpts(), recentVal().join('')), bind: host => { const rs = $('#recentSel', host); if (rs) rs.onchange = () => recentChange(rs, onChange); } }; }
