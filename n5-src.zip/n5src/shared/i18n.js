// ================= 介面語言（中文／English；日文頁和語言頁共用：n5src/shared/i18n.js） =================
// 程式裡的介面文字都寫中文；選 English 時，畫面上的中文由對照表（I18N.en：i18n-ui.js、ja/i18n.js、lang-i18n.js、各語言的 i18n.js）即時換成英文。
// 學的語言（有 lang="ja"、lang="it"… 的區塊，或 class="ja"）不會動。換語言時重新載入頁面，避免中英混雜。
// 用頁面的 SET（設定 lang）；要在 SET 後面、畫面出來前載入。
const LANG = SET.lang === 'en' && typeof I18N !== 'undefined' ? 'en' : 'zh';
const I18 = LANG === 'en' ? I18N.en : null;
const HAN = /[㐀-鿿]/;
const i18nMiss = new Set();
function trText(str) {
  if (!I18 || !str || !HAN.test(str)) return null;
  const m = str.match(/^(\s*)([\s\S]*?)(\s*)$/), t = m[2];
  let out = I18.dict[t];
  if (out == null) {
    for (const [re, rp] of I18.re) { if (re.test(t)) { out = t.replace(re, typeof rp === 'function' ? (...a) => rp(...a) : rp); break; } }
  }
  if (out == null) { i18nMiss.add(t); return null; }
  return m[1] + out + m[3];
}
const L = str => trText(str) ?? str; // 給 toast、confirm 這類不經過畫面的文字用
const TR_ATTRS = ['title', 'aria-label', 'placeholder'];
// 學的語言的區塊：lang 不是 en／zh（lang="ja"、"it"…），或 class="ja"、data-noi18n、textarea
const isStudy = el => { const l = el.getAttribute('lang'); return !!l && !/^(en|zh)/i.test(l); };
function trNode(n) {
  if (n.nodeType === 3) { const v = trText(n.nodeValue); if (v != null && v !== n.nodeValue) n.nodeValue = v; return; }
  if (n.nodeType !== 1) return;
  const tag = n.tagName;
  if (tag === 'SCRIPT' || tag === 'STYLE' || tag === 'TEXTAREA' || isStudy(n) || n.classList.contains('ja') || n.hasAttribute('data-noi18n')) return;
  for (const a of TR_ATTRS) { const v0 = n.getAttribute(a); if (v0) { const v = trText(v0); if (v != null && v !== v0) n.setAttribute(a, v); } }
  for (let c = n.firstChild; c; c = c.nextSibling) trNode(c);
}
const inStudy = n => { let e = n && (n.nodeType === 1 ? n : n.parentElement); for (; e && e !== document.documentElement; e = e.parentElement) { if (e.tagName === 'TEXTAREA' || isStudy(e) || e.classList.contains('ja') || e.hasAttribute('data-noi18n')) return true; } return false; };
if (I18) {
  document.documentElement.lang = 'en';
  if (I18.title) document.title = I18.title;
  trNode(document.body);
  new MutationObserver(recs => {
    for (const r of recs) {
      if (r.type === 'childList') { for (const n of r.addedNodes) if (!inStudy(n.parentNode || n)) trNode(n); }
      else if (r.type === 'characterData') { if (!inStudy(r.target)) trNode(r.target); }
      else if (r.type === 'attributes') { const el = r.target, v0 = el.getAttribute(r.attributeName); if (v0 && !inStudy(el)) { const v = trText(v0); if (v != null && v !== v0) el.setAttribute(r.attributeName, v); } }
    }
  }).observe(document.body, { childList: true, subtree: true, characterData: true, attributes: true, attributeFilter: TR_ATTRS });
  window.__i18nMiss = i18nMiss;
}
