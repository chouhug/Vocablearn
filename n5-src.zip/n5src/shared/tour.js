// ================= 首次使用導覽（日文頁和語言頁共用） =================
// 各頁不同的地方放在 PAGE.tour：
//   key      記錄「看過導覽」的 localStorage 鍵（日文 n5:toured、語言頁 it:toured…）
//   steps()  步驟陣列 [{ t 標題, d 說明, el 要框起來的元素（選擇器或陣列）, tab 要切到的分頁, last 最後一步 }]
//            el 找不到的步驟會自動跳過（例如英文頁沒有「名」按鈕）
//   art      第一步上方的插畫（HTML）
//   extra(st)、bind(card, Tour)  步驟裡額外的內容和按鈕（日文頁用來選介面語言）
//   fresh()  還沒有這個語言的學習紀錄（有紀錄的人不會自動跳出導覽）
const Tour = {
  i: 0, ring: null, card: null, back: null, list: [],
  start(i) {
    const T = PAGE.tour;
    this.list = T.steps().filter(st => !st.el || [].concat(st.el).some(s => $(s)));
    this.i = Math.max(0, Math.min(this.list.length - 1, i || 0));
    if (!this.ring) {
      this.ring = document.createElement('div'); this.ring.className = 'tour-ring';
      this.card = document.createElement('div'); this.card.className = 'tour-card'; this.card.setAttribute('role', 'dialog'); this.card.setAttribute('aria-modal', 'true');
      this.back = document.createElement('div'); this.back.style.cssText = 'position:fixed;inset:0;z-index:69';
      document.body.append(this.back, this.ring, this.card);
      window.addEventListener('resize', () => this.place());
    }
    this.back.hidden = this.ring.hidden = this.card.hidden = false;
    this.show();
  },
  show() {
    const T = PAGE.tour, st = this.list[this.i];
    if (st.tab && UI.tab !== st.tab) showTab(st.tab);
    const dots = this.list.map((_, j) => `<i class="${j === this.i ? 'on' : ''}"></i>`).join('');
    this.card.setAttribute('aria-label', st.t);
    this.card.innerHTML = `${this.i === 0 && T.art ? T.art : ''}<h3>${esc(st.t)}</h3><p>${esc(st.d)}</p>
      ${T.extra ? T.extra(st) : ''}
      <div class="tour-dots" aria-hidden="true">${dots}</div>
      <div class="row">${st.last ? '' : '<button class="btn quiet" data-tour="skip">略過</button>'}${this.i > 0 && !st.last ? '<button class="btn quiet" data-tour="prev">上一步</button>' : ''}<button class="btn solid" data-tour="${st.last ? 'end' : 'next'}">${st.last ? '開始學習' : '下一步'}</button></div>`;
    if (T.bind) T.bind(this.card, this);
    $$('[data-tour]', this.card).forEach(b => b.onclick = () => { const a = b.dataset.tour; if (a === 'next') this.go(this.i + 1); else if (a === 'prev') this.go(this.i - 1); else this.end(); });
    this.place();
    requestAnimationFrame(() => { const f = $('[data-tour="next"],[data-tour="end"]', this.card); if (f) f.focus({ preventScroll: true }); });
  },
  go(i) { this.i = Math.max(0, Math.min(this.list.length - 1, i)); this.show(); },
  place() {
    if (!this.card || this.card.hidden) return;
    const st = this.list[this.i], vh = window.innerHeight;
    const els = st.el ? [].concat(st.el).map(s => $(s)).filter(Boolean) : [];
    this.card.style.top = this.card.style.bottom = '';
    if (!els.length) {
      this.ring.classList.add('none');
      this.card.style.top = Math.max(16, (vh - this.card.offsetHeight) / 2) + 'px';
      return;
    }
    this.ring.classList.remove('none');
    const rs = els.map(e => e.getBoundingClientRect());
    const r = { l: Math.min(...rs.map(x => x.left)), t: Math.min(...rs.map(x => x.top)), r: Math.max(...rs.map(x => x.right)), b: Math.max(...rs.map(x => x.bottom)) };
    const pad = 4;
    Object.assign(this.ring.style, { left: (r.l - pad) + 'px', top: (r.t - pad) + 'px', width: (r.r - r.l + pad * 2) + 'px', height: (r.b - r.t + pad * 2) + 'px' });
    if (r.t > vh / 2) this.card.style.bottom = (vh - r.t + 14) + 'px';
    else this.card.style.top = (r.b + 14) + 'px';
  },
  end() {
    store.set(PAGE.tour.key, 1);
    this.back.hidden = this.ring.hidden = this.card.hidden = true;
    showTab('card');
  },
  // 啟動時呼叫：沒看過導覽、也還沒有這個語言的紀錄才自動開始。
  // 第一次使用要先選語言（lang.js 的「你想學哪個語言？」），選完留在這一頁才開始
  auto() {
    if (window.AppLangs && AppLangs.welcome) return AppLangs.afterWelcome(() => this.auto());
    if (!store.get(PAGE.tour.key, 0) && PAGE.tour.fresh()) this.start(0);
  }
};
document.addEventListener('keydown', e => { if (e.key === 'Escape' && Tour.card && !Tour.card.hidden) Tour.end(); });
