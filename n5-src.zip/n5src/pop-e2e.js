// 用真的瀏覽器（手機寬度 390px）測「突然考一題」和「單選不算每日題數」：node n5src/pop-e2e.js n5work [ja it …]
// 需要 playwright 和 Chrome（GitHub Actions 沒有，所以不在 test-all.js 裡；改了 shared/pop-quiz.js 或 record() 後在本機跑）
// 會在目前的資料夾留下 shot-pop-*.png 截圖
let chromium; try { ({ chromium } = require('playwright')); } catch (e) { ({ chromium } = require('/opt/npm-tools/node_modules/playwright')); }
const http = require('http'), fs = require('fs'), path = require('path');
const ROOT = path.resolve(process.argv[2]);
const LANGS = process.argv.slice(3).length ? process.argv.slice(3) : ['ja', 'it'];
const srv = http.createServer((q, r) => { const f = path.join(ROOT, decodeURIComponent(q.url.split('?')[0])); fs.readFile(f, (e, d) => { if (e) { r.writeHead(404); return r.end(); } r.writeHead(200, { 'content-type': f.endsWith('.html') ? 'text/html; charset=utf-8' : f.endsWith('.js') ? 'text/javascript' : 'application/octet-stream' }); r.end(d); }); });
let bad = 0; const ok = (c, m) => { console.log((c ? '✓ ' : '✗ ') + m); if (!c) bad++; };
const ymd = d => d.toLocaleDateString('sv-SE');
(async () => {
  await new Promise(r => srv.listen(0, r)); const base = 'http://127.0.0.1:' + srv.address().port + '/';
  const br = await chromium.launch({ executablePath: process.env.CHROME || (fs.existsSync('/usr/bin/google-chrome') ? '/usr/bin/google-chrome' : undefined), args: ['--no-sandbox'] });
  for (const L of LANGS) {
    console.log('—— ' + L);
    const file = L === 'ja' ? 'index.html' : L + '.html', pre = L === 'ja' ? 'n5' : L, popKey = pre + ':pop';
    const ctx = await br.newContext({ viewport: { width: 390, height: 780 }, deviceScaleFactor: 2, isMobile: true, hasTouch: true });
    await ctx.route(/^https:\/\//, r => r.abort());
    await ctx.addInitScript(([l, pre]) => { if (!localStorage.getItem('langs:last')) { localStorage.setItem('langs:last', JSON.stringify(l)); localStorage.setItem('langs:v1', JSON.stringify({ active: [l], max: 2, lock: true, note: '' })); localStorage.setItem(pre + ':toured', '1'); localStorage.setItem(pre + ':ui', JSON.stringify({ tab: 'card', cardSrc: 'new' })); } }, [L, pre]);
    const pg = await ctx.newPage(); const errs = [];
    pg.on('pageerror', e => errs.push(e.message)); pg.on('console', m => { if (m.type() === 'error' && !/net::ERR|Failed to load resource/.test(m.text())) errs.push(m.text()); });
    const P = () => pg.evaluate(() => JSON.parse(localStorage.getItem('n5:progress') || '{"items":{},"days":{}}'));
    const day = async () => ((await P()).days || {})[ymd(new Date())] || 0;
    const popOpen = () => pg.evaluate(() => !!document.querySelector('.pk.pop-sheet:not([hidden])'));
    await pg.goto(base + file); await pg.waitForSelector('#tab-card [data-a="queue"]');
    // 第一次打開：沒有上次的紀錄，不會跳
    await pg.waitForTimeout(2000);
    ok(!(await popOpen()), '第一次打開不會跳出考題');
    ok((await pg.evaluate(k => JSON.parse(localStorage.getItem(k)), popKey)).last === ymd(new Date()), '記下今天打開過');
    // 字卡：列入考題 6 個字
    for (let i = 0; i < 6; i++) { await pg.click('#tab-card [data-a="queue"]'); await pg.waitForTimeout(150); }
    const queued = Object.values((await P()).items).filter(r => r.s === 'queued').length;
    ok(queued >= 6, '列入考題 ' + queued + ' 個字');
    // 單選：答一題，每日題數不變
    await pg.click('.tabbar [data-tab="mc"], nav [data-tab="mc"]');
    await pg.waitForSelector('#mcq .opt');
    const d0 = await day();
    await pg.click('#mcq .opt >> nth=0'); await pg.waitForTimeout(300);
    const items1 = (await P()).items;
    ok(Object.values(items1).some(r => r.w && 'mc' in r.w || r.mcOk || r.n > 0), '單選有記錄作答');
    ok(await day() === d0, `單選答完每日題數不變（${d0}）`);
    ok(/今日 \d+\/20/.test(await pg.textContent('#goalText')) && (await pg.textContent('#goalText')).includes(` ${d0}/`), '上方今日題數也沒變');
    // 做了一定題數：把設定改成每 10 題、計數已經 9，再答一題單選就會跳
    await pg.evaluate(k => { const s = JSON.parse(localStorage.getItem(k)); s.n = 9; localStorage.setItem(k, JSON.stringify(s)); }, popKey);
    await pg.click('.tabbar [data-tab="lib"], nav [data-tab="lib"]'); await pg.waitForSelector('#popSel', { state: 'attached' });
    await pg.evaluate(() => { const el = document.querySelector('#popSel'); el.closest('details') && (el.closest('details').open = true); el.value = '10'; el.dispatchEvent(new Event('change')); });
    ok(JSON.parse(await pg.evaluate(() => localStorage.getItem('n5:settings'))).pop === 10, '設定「突然考一題」存成每 10 題');
    await pg.click('.tabbar [data-tab="mc"], nav [data-tab="mc"]'); await pg.waitForSelector('#mcq .opt:not([disabled])');
    await pg.click('#mcq .opt:not([disabled]) >> nth=0');
    await pg.waitForSelector('.pk.pop-sheet:not([hidden]) #popq .opt', { timeout: 4000 }).catch(() => {});
    ok(await popOpen(), '做滿 10 題跳出「突然考你一題」');
    ok(/突然考你一題/.test(await pg.textContent('.pk.pop-sheet .pk-top')), '標題是「突然考你一題！」');
    ok((await pg.evaluate(k => JSON.parse(localStorage.getItem(k)), popKey)).n === 0, '計數歸零');
    await pg.screenshot({ path: `shot-pop-${L}-count.png` });
    ok(await pg.evaluate(() => [...document.querySelectorAll('.pop-sheet .opt')].every(x => { const r = x.getBoundingClientRect(); return r.left >= 0 && r.right <= innerWidth; })), '手機寬度：選項沒有超出螢幕');
    const d1 = await day();
    const before = JSON.stringify((await P()).items);
    await pg.click('.pop-sheet #popq .opt >> nth=1'); await pg.waitForTimeout(300);
    ok(JSON.stringify((await P()).items) !== before, '突擊題的作答有記錄');
    ok(await day() === d1, '突擊題不算每日題數');
    ok((await pg.textContent('.pop-sheet [data-next]')).trim() === '繼續練習', '按鈕是「繼續練習」');
    await pg.screenshot({ path: `shot-pop-${L}-answered.png` });
    await pg.click('.pop-sheet [data-next]'); await pg.waitForTimeout(400);
    ok(!(await popOpen()), '按「繼續練習」關掉');
    // 原本的單選題還在、可以繼續（鍵盤 Enter 接回原本的題目）
    await pg.keyboard.press('Enter'); await pg.waitForTimeout(300);
    ok(await pg.evaluate(() => !!document.querySelector('#mcq .opt:not([disabled])')), '關掉後回到單選，可以接著做下一題');
    // 填空：看答案（算答錯）每日題數加一
    await pg.click('.tabbar [data-tab="fill"], nav [data-tab="fill"]'); await pg.waitForTimeout(500);
    const fin = await pg.$('#tab-fill input[type="text"], #tab-fill input:not([type])');
    if (fin) {
      const d2 = await day();
      await fin.fill('zzz'); await fin.press('Enter'); await pg.waitForTimeout(300);
      const again = await pg.$('#tab-fill [data-giveup], #tab-fill .btn');
      ok(await day() >= d2 + 1 || (await pg.textContent('#tab-fill')).includes('再'), `填空作答會算每日題數（${d2} → ${await day()}）`);
    } else ok(false, '找不到填空的輸入框');
    // 隔了好幾天沒打開：把上次打開改成 5 天前，重新整理就跳「好久不見」
    await pg.evaluate(([k, d]) => { const s = JSON.parse(localStorage.getItem(k)); s.last = d; localStorage.setItem(k, JSON.stringify(s)); }, [popKey, ymd(new Date(Date.now() - 5 * 864e5))]);
    await pg.reload(); await pg.waitForSelector('.pk.pop-sheet:not([hidden]) #popq .opt', { timeout: 5000 }).catch(() => {});
    ok(await popOpen(), '5 天沒打開：一打開就跳出考題');
    const top = await pg.textContent('.pk.pop-sheet');
    ok(/好久不見/.test(top) && /5 天/.test(top), '標題「好久不見」、說明 5 天沒來');
    await pg.screenshot({ path: `shot-pop-${L}-away.png` });
    await pg.click('.pop-sheet .pk-x'); await pg.waitForTimeout(400);
    ok(!(await popOpen()), '叉叉可以關掉');
    await pg.reload(); await pg.waitForTimeout(2500);
    ok(!(await popOpen()), '同一天再打開不會再跳');
    // 關閉後不跳
    await pg.evaluate(k => { const st = JSON.parse(localStorage.getItem('n5:settings')); st.pop = 'off'; localStorage.setItem('n5:settings', JSON.stringify(st)); const s = JSON.parse(localStorage.getItem(k)); s.last = '2020-01-01'; localStorage.setItem(k, JSON.stringify(s)); }, popKey);
    await pg.reload(); await pg.waitForTimeout(2500);
    ok(!(await popOpen()), '設定關閉時不會跳');
    ok(!errs.length, '沒有錯誤訊息' + (errs.length ? '：' + errs.join(' | ') : ''));
    await ctx.close();
  }
  await br.close(); srv.close();
  console.log(bad ? `✗ ${bad} 項失敗` : '全部通過');
  process.exit(bad ? 1 : 0);
})();
