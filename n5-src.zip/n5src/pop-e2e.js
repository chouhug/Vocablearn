// 用真的瀏覽器（手機寬度 390px）測「突然考一題」和「單選不算每日題數」：node n5src/pop-e2e.js n5work [ja it …]
// 需要 playwright 和 Chrome（GitHub Actions 沒有，所以不在 test-all.js 裡；改了 shared/pop-quiz.js 或 record() 後在本機跑）
// 會在目前的資料夾留下 shot-pop-*.png 截圖
let chromium; try { ({ chromium } = require('playwright')); } catch (e) { ({ chromium } = require('/opt/npm-tools/node_modules/playwright')); }
const http = require('http'), fs = require('fs'), path = require('path');
const ROOT = path.resolve(process.argv[2]);
const LANGS = process.argv.slice(3).length ? process.argv.slice(3) : ['ja', 'it'];
const srv = http.createServer((q, r) => { const f = path.join(ROOT, decodeURIComponent(q.url.split('?')[0])); fs.readFile(f, (e, d) => { if (e) { r.writeHead(404); return r.end(); } r.writeHead(200, { 'content-type': f.endsWith('.html') ? 'text/html; charset=utf-8' : f.endsWith('.js') ? 'text/javascript' : 'application/octet-stream' }); r.end(d); }); });
let bad = 0; const ok = (c, m) => { console.log((c ? '✓ ' : '✗ ') + m); if (!c) bad++; };
const ymd = d => d.toLocaleDateString('sv-SE');
(async () => {
  await new Promise(r => srv.listen(0, r)); const base = 'http://127.0.0.1:' + srv.address().port + '/';
  const br = await chromium.launch({ executablePath: process.env.CHROME || (fs.existsSync('/usr/bin/google-chrome') ? '/usr/bin/google-chrome' : undefined), args: ['--no-sandbox'] });
  for (const L of LANGS) {
    console.log('—— ' + L);
    const file = L === 'ja' ? 'index.html' : L + '.html', pre = L === 'ja' ? 'n5' : L, popKey = pre + ':pop';
    const ctx = await br.newContext({ viewport: { width: 390, height: 780 }, deviceScaleFactor: 2, isMobile: true, hasTouch: true });
    await ctx.route(/^https:\/\//, r => r.abort());
    await ctx.addInitScript(([l, pre]) => { if (!localStorage.getItem('langs:last')) { localStorage.setItem('langs:last', JSON.stringify(l)); localStorage.setItem('langs:v1', JSON.stringify({ active: [l], max: 2, lock: true, note: '' })); localStorage.setItem(pre + ':toured', '1'); localStorage.setItem(pre + ':ui', JSON.stringify({ tab: 'card', cardSrc: 'new' })); } }, [L, pre]);
    const pg = await ctx.newPage(); const errs = [];
    pg.on('pageerror', e => errs.push(e.message)); pg.on('console', m => { if (m.type() === 'error' && !/net::ERR|Failed to load resource/.test(m.text())) errs.push(m.text()); });
    const P = () => pg.evaluate(() => JSON.parse(localStorage.getItem('n5:progress') || '{"items":{},"days":{}}'));
    const day = async () => ((await P()).days || {})[ymd(new Date())] || 0;
    const popOpen = () => pg.evaluate(() => !!document.querySelector('.pk.pop-sheet:not([hidden])'));
    await pg.goto(base + file); await pg.waitForSelector('#tab-card [data-a="queue"]');
    // 第一次打開：沒有上次的紀錄，不會跳
    await pg.waitForTimeout(2000);
    ok(!(await popOpen()), '第一次打開不會跳出考題');
    ok((await pg.evaluate(k => JSON.parse(localStorage.getItem(k)), popKey)).last === ymd(new Date()), '記下今天打開過');
    // 字卡：列入考題 6 個字
    for (let i = 0; i < 12; i++) { await pg.click('#tab-card [data-a="queue"]'); await pg.waitForTimeout(150); }
    const queued = Object.values((await P()).items).filter(r => r.s === 'queued').length;
    ok(queued >= 12, '列入考題 ' + queued + ' 個字');
    // 單選：答一題，每日題數不變
    await pg.click('.tabbar [data-tab="mc"], nav [data-tab="mc"]');
    await pg.waitForSelector('#mcq .opt');
    const d0 = await day();
    await pg.click('#mcq .opt >> nth=0'); await pg.waitForTimeout(300);
    const items1 = (await P()).items;
    ok(Object.values(items1).some(r => r.w && 'mc' in r.w || r.mcOk || r.n > 0), '單選有記錄作答');
    ok(await day() === d0, `單選答完每日題數不變（${d0}）`);
    ok(/今日 \d+\/20/.test(await pg.textContent('#goalText')) && (await pg.textContent('#goalText')).includes(` ${d0}/`), '上方今日題數也沒變');
    // 做了 10～25 題：把目標設成 10、計數已經 9，再答一題單選就會跳
    const g0 = await pg.evaluate(k => { const s = JSON.parse(localStorage.getItem(k)); const g = s.goal; s.n = 9; s.goal = 10; localStorage.setItem(k, JSON.stringify(s)); return g; }, popKey);
    ok(g0 >= 10 && g0 <= 25, `目標題數在 10～25 之間（${g0}）`);
    await pg.click('.tabbar [data-tab="lib"], nav [data-tab="lib"]'); await pg.waitForSelector('#popSel', { state: 'attached' });
    ok(await pg.evaluate(() => [...document.querySelectorAll('#popSel option')].map(o => o.value).join()) === 'on,off', '設定只有「開（每做 10～25 題）／關閉」');
    await pg.evaluate(() => { const el = document.querySelector('#popSel'); el.value = 'off'; el.dispatchEvent(new Event('change')); el.value = 'on'; el.dispatchEvent(new Event('change')); });
    ok(JSON.parse(await pg.evaluate(() => localStorage.getItem('n5:settings'))).pop === 'on', '設定存成 on');
    await pg.click('.tabbar [data-tab="mc"], nav [data-tab="mc"]'); await pg.waitForSelector('#mcq .opt:not([disabled])');
    await pg.click('#mcq .opt:not([disabled]) >> nth=0');
    await pg.waitForSelector('.pk.pop-sheet:not([hidden]) #popq .opt', { timeout: 4000 }).catch(() => {});
    ok(await popOpen(), '做滿題數跳出突擊測驗');
    ok(/突擊測驗/.test(await pg.textContent('.pk.pop-sheet .pk-top')), '標題是「突擊測驗！」');
    const st = await pg.evaluate(k => JSON.parse(localStorage.getItem(k)), popKey);
    ok(st.n === 0 && st.goal >= 10 && st.goal <= 25, '計數歸零，下一次目標 ' + st.goal + ' 題');
    ok(/第 1 題／共 3 題/.test(await pg.textContent('#popStep')), '顯示「第 1 題／共 3 題」');
    await pg.screenshot({ path: `shot-pop-${L}-q1.png` });
    ok(await pg.evaluate(() => [...document.querySelectorAll('.pop-sheet .opt')].every(x => { const r = x.getBoundingClientRect(); return r.left >= 0 && r.right <= innerWidth; })), '手機寬度：選項沒有超出螢幕');
    const d1 = await day();
    // 第 1 題：選錯（不會自動跳）→ 下一題
    await pg.click('.pop-sheet #popq .opt >> nth=1'); await pg.waitForTimeout(200);
    if (await pg.$('.pop-sheet [data-next]')) await pg.click('.pop-sheet [data-next]');
    await pg.waitForFunction(() => /第 2 題/.test(document.querySelector('#popStep').textContent));
    const q2 = await pg.textContent('#popq .prompt');
    console.log('   第 2 題：' + q2.trim().replace(/\s+/g, ' ').slice(0, 40));
    if (L === 'ja') {
      const its = (await P()).items;
      const old8 = Object.entries(its).filter(([, r]) => r.s === 'queued' || r.s === 'learned').sort((a, b) => (a[1].t || 0) - (b[1].t || 0)).slice(0, 8);
      const kanji = old8.some(([id]) => /[一-鿿々]/.test(id.split('|')[0]));
      ok(kanji ? /讀音/.test(q2) : !/讀音/.test(q2), kanji ? '日文第 2 題考漢字讀音' : '候選字沒有漢字：第 2 題改看意思選單字');
    }
    else ok(!/播放發音/.test(q2), '第 2 題是看意思選單字');
    await pg.screenshot({ path: `shot-pop-${L}-q2.png` });
    await pg.click('.pop-sheet #popq .opt >> nth=0'); await pg.waitForTimeout(200);
    if (await pg.$('.pop-sheet [data-next]') && !/第 3 題/.test(await pg.textContent('#popStep'))) await pg.click('.pop-sheet [data-next]').catch(() => {});
    await pg.waitForFunction(() => /第 3 題/.test(document.querySelector('#popStep').textContent));
    ok(await day() === d1, '兩題選擇不算每日題數');
    ok(!!(await pg.$('.pop-sheet #fillIn')), '第 3 題是填空');
    await pg.screenshot({ path: `shot-pop-${L}-q3.png` });
    await pg.fill('.pop-sheet #fillIn', 'zzz'); await pg.press('.pop-sheet #fillIn', 'Enter'); await pg.waitForTimeout(400);
    if (!/繼續練習/.test(await pg.textContent('.pop-sheet #fillGo'))) { await pg.fill('.pop-sheet #fillIn', 'zzzq'); await pg.press('.pop-sheet #fillIn', 'Enter'); await pg.waitForTimeout(400); }   // 同義字提示時再答一次
    ok(await day() === d1 + 1, `填空算每日題數（${d1} → ${await day()}）`);
    ok((await pg.textContent('.pop-sheet #fillGo')).trim() === '繼續練習', '最後一題的按鈕是「繼續練習」');
    ok(/這一組答對 \d／3 題/.test(await pg.textContent('#popStep')), '顯示這一組的成績：' + (await pg.textContent('#popStep')));
    await pg.screenshot({ path: `shot-pop-${L}-done.png` });
    await pg.click('.pop-sheet #fillGo'); await pg.waitForTimeout(500);
    ok(!(await popOpen()), '按「繼續練習」關掉');
    ok((await pg.evaluate(k => JSON.parse(localStorage.getItem(k)), popKey)).n === 0, '突擊測驗自己的題目不算進計數');
    await pg.keyboard.press('Enter'); await pg.waitForTimeout(300);
    ok(await pg.evaluate(() => !!document.querySelector('#mcq .opt:not([disabled])')), '關掉後回到單選，可以接著做下一題');
    // 填空：答一題，每日題數加一
    await pg.click('.tabbar [data-tab="fill"], nav [data-tab="fill"]'); await pg.waitForSelector('#tab-fill #fillIn');
    const d2 = await day();
    await pg.fill('#tab-fill #fillIn', 'zzz'); await pg.press('#tab-fill #fillIn', 'Enter'); await pg.waitForTimeout(300);
    ok(await day() >= d2 + 1, `填空分頁作答會算每日題數（${d2} → ${await day()}）`);
    // 隔了好幾天沒打開：把上次打開改成 5 天前，重新整理就跳「好久不見」
    await pg.evaluate(([k, d]) => { const s = JSON.parse(localStorage.getItem(k)); s.last = d; localStorage.setItem(k, JSON.stringify(s)); }, [popKey, ymd(new Date(Date.now() - 5 * 864e5))]);
    await pg.reload(); await pg.waitForSelector('.pk.pop-sheet:not([hidden]) #popq .opt', { timeout: 5000 }).catch(() => {});
    ok(await popOpen(), '5 天沒打開：一打開就跳出考題');
    const top = await pg.textContent('.pk.pop-sheet');
    ok(/好久不見！先考你一組/.test(top) && /5 天/.test(top), '標題「好久不見！先考你一組」、說明 5 天沒來');
    await pg.screenshot({ path: `shot-pop-${L}-away.png` });
    await pg.click('.pop-sheet #popq .opt >> nth=1'); await pg.waitForTimeout(200);
    if (await pg.$('.pop-sheet [data-next]')) await pg.click('.pop-sheet [data-next]');
    await pg.click('.pop-sheet #popq .opt >> nth=1'); await pg.waitForTimeout(200);
    if (await pg.$('.pop-sheet [data-next]')) await pg.click('.pop-sheet [data-next]').catch(() => {});
    await pg.waitForSelector('.pop-sheet #fillIn');
    ok(!(await pg.$('#tab-fill #fillIn')), '突擊的填空題出現時，填空分頁先清掉（id 不重複）');
    await pg.click('.pop-sheet .pk-x'); await pg.waitForTimeout(600);
    ok(!(await popOpen()), '叉叉可以關掉');
    ok(!!(await pg.$('#tab-fill #fillIn')), '關掉後填空分頁畫回來');
    await pg.reload(); await pg.waitForTimeout(2500);
    ok(!(await popOpen()), '同一天再打開不會再跳');
    // 關閉後不跳
    await pg.evaluate(k => { const st = JSON.parse(localStorage.getItem('n5:settings')); st.pop = 'off'; localStorage.setItem('n5:settings', JSON.stringify(st)); const s = JSON.parse(localStorage.getItem(k)); s.last = '2020-01-01'; localStorage.setItem(k, JSON.stringify(s)); }, popKey);
    await pg.reload(); await pg.waitForTimeout(2500);
    ok(!(await popOpen()), '設定關閉時不會跳');
    ok(!errs.length, '沒有錯誤訊息' + (errs.length ? '：' + errs.join(' | ') : ''));
    await ctx.close();
  }
  await br.close(); srv.close();
  console.log(bad ? `✗ ${bad} 項失敗` : '全部通過');
  process.exit(bad ? 1 : 0);
})();
