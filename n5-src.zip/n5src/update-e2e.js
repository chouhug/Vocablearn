// 用真的瀏覽器測「有新版時自動更新」（lang.js 最後一段）：node n5src/update-e2e.js n5work
// 需要 playwright 和 Chrome（不在 test-all.js 裡）。會在目前的資料夾留下 shot-update.png 截圖
// 做法：在 127.0.0.1 註冊 sw.js → 把伺服器上的 sw.js 換成新版本號 → 請瀏覽器檢查更新 → 新的 sw.js 接手後應該出現「有新版本」按鈕，按了重新整理
let chromium; try { ({ chromium } = require('playwright')); } catch (e) { ({ chromium } = require('/opt/npm-tools/node_modules/playwright')); }
const http = require('http'), fs = require('fs'), path = require('path');
const ROOT = path.resolve(process.argv[2]);
let swExtra = '';
const srv = http.createServer((q, r) => { const p = decodeURIComponent(q.url.split('?')[0]); const f = path.join(ROOT, p === '/' ? 'index.html' : p); fs.readFile(f, (e, d) => { if (e) { r.writeHead(404); return r.end(); } if (p === '/sw.js') d = Buffer.concat([d, Buffer.from(swExtra)]); r.writeHead(200, { 'content-type': f.endsWith('.html') ? 'text/html; charset=utf-8' : f.endsWith('.js') ? 'text/javascript' : 'application/octet-stream', 'cache-control': 'no-cache' }); r.end(d); }); });
let bad = 0; const ok = (c, m) => { console.log((c ? '✓ ' : '✗ ') + m); if (!c) bad++; };
(async () => {
  await new Promise(r => srv.listen(0, r)); const base = 'http://127.0.0.1:' + srv.address().port + '/';
  const br = await chromium.launch({ executablePath: process.env.CHROME || (fs.existsSync('/usr/bin/google-chrome') ? '/usr/bin/google-chrome' : undefined), args: ['--no-sandbox'] });
  for (const [file, width] of [['index.html', 390], ['it.html', 1280]]) {
    console.log('—— ' + file + ' ' + width + 'px');
    swExtra = '';
    const ctx = await br.newContext({ viewport: { width, height: 800 } });
    await ctx.route(/^https:\/\//, r => r.abort());
    const l = file === 'index.html' ? 'ja' : 'it', pre = l === 'ja' ? 'n5' : l;
    await ctx.addInitScript(([l, pre]) => { if (!localStorage.getItem('langs:last')) { localStorage.setItem('langs:last', JSON.stringify(l)); localStorage.setItem('langs:v1', JSON.stringify({ active: [l], max: 2, lock: true, note: '' })); localStorage.setItem(pre + ':toured', '1'); } }, [l, pre]);
    const pg = await ctx.newPage(); const errs = [];
    pg.on('pageerror', e => errs.push(e.message));
    await pg.goto(base + file); await pg.waitForTimeout(500);
    ok(await pg.evaluate(() => !!window.AppUpdate), 'lang.js 有載入更新檢查');
    // 頁面只在 https 註冊 sw.js；測試在 127.0.0.1，自己註冊
    await pg.evaluate(async () => { await navigator.serviceWorker.register('sw.js'); if (!navigator.serviceWorker.controller) await new Promise(r => navigator.serviceWorker.addEventListener('controllerchange', r, { once: true })); });
    await pg.waitForTimeout(300);
    ok(!(await pg.$('#appUpdate')), '第一次安裝 sw.js：不出現「有新版本」');
    await pg.reload(); await pg.waitForTimeout(500);
    ok(await pg.evaluate(() => !!navigator.serviceWorker.controller), '重新整理後由 sw.js 接手');
    swExtra = '\n// new version ' + Date.now();
    await pg.evaluate(() => window.AppUpdate.check());
    await pg.waitForSelector('#appUpdate', { timeout: 8000 }).catch(() => {});
    const b = await pg.$('#appUpdate');
    ok(!!b && /有新版本/.test(await b.textContent()), '網站有新版：下方出現「有新版本，點這裡更新」');
    if (b) {
      ok(await pg.evaluate(() => { const r = document.getElementById('appUpdate').getBoundingClientRect(); const nav = document.querySelector('nav, .tabs, #tabs'); return r.left >= 0 && r.right <= innerWidth && r.bottom <= innerHeight && (!nav || r.bottom <= nav.getBoundingClientRect().top); }), '按鈕在畫面內、沒有蓋到分頁列');
      await pg.screenshot({ path: `shot-update-${width}.png` });
      await pg.evaluate(() => { window.__old = 1; });
      await Promise.all([pg.waitForNavigation(), b.click()]);
      await pg.waitForTimeout(400);
      ok(await pg.evaluate(() => !window.__old && !document.getElementById('appUpdate')), '按了按鈕：重新整理成新版，按鈕消失');
    }
    ok(!errs.length, '沒有 JS 錯誤' + (errs.length ? '：' + errs.join(' | ') : ''));
    await ctx.close();
  }
  await br.close(); srv.close();
  console.log(bad ? `${bad} 項失敗` : '全部通過'); process.exit(bad ? 1 : 0);
})();
