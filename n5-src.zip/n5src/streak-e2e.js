// 用真的瀏覽器（手機寬度 360px）測「連勝」和「每日目標」：node n5src/streak-e2e.js n5work [ja it …]
// 需要 playwright 和 Chrome（不在 test-all.js 裡；改了 shared/streak.js 或 core.js 的 streakOf 後在本機跑）。會留下 shot-streak-*.png
let chromium; try { ({ chromium } = require('playwright')); } catch (e) { ({ chromium } = require('/opt/npm-tools/node_modules/playwright')); }
const http = require('http'), fs = require('fs'), path = require('path');
const ROOT = path.resolve(process.argv[2]);
const LANGS = process.argv.slice(3).length ? process.argv.slice(3) : ['ja', 'it'];
const srv = http.createServer((q, r) => { const f = path.join(ROOT, decodeURIComponent(q.url.split('?')[0])); fs.readFile(f, (e, d) => { if (e) { r.writeHead(404); return r.end(); } r.writeHead(200, { 'content-type': f.endsWith('.html') ? 'text/html; charset=utf-8' : f.endsWith('.js') ? 'text/javascript' : 'application/octet-stream' }); r.end(d); }); });
let bad = 0; const ok = (c, m) => { console.log((c ? '✓ ' : '✗ ') + m); if (!c) bad++; };
const ymd = d => d.toLocaleDateString('sv-SE');
const ago = n => ymd(new Date(Date.now() - n * 864e5));
(async () => {
  await new Promise(r => srv.listen(0, r)); const base = 'http://127.0.0.1:' + srv.address().port + '/';
  const br = await chromium.launch({ executablePath: process.env.CHROME || (fs.existsSync('/usr/bin/google-chrome') ? '/usr/bin/google-chrome' : undefined), args: ['--no-sandbox'] });
  for (const L of LANGS) for (const theme of ['light', 'dark']) {
    console.log(`—— ${L}（${theme}）`);
    const file = L === 'ja' ? 'index.html' : L + '.html', pre = L === 'ja' ? 'n5' : L;
    const ctx = await br.newContext({ viewport: { width: 360, height: 740 }, deviceScaleFactor: 2, isMobile: true, hasTouch: true });
    await ctx.route(/^https:\/\//, r => r.abort());
    // 前 6 天：3 天有練、1 天沒練（休息日）、2 天有練 → 連勝 5；突擊測驗關掉
    const days = { [ago(6)]: 7, [ago(5)]: 5, [ago(4)]: 12, [ago(3)]: 2, [ago(2)]: 6, [ago(1)]: 20 };
    await ctx.addInitScript(([l, pre, days, theme]) => { if (!localStorage.getItem('langs:last')) { localStorage.setItem('langs:last', JSON.stringify(l)); localStorage.setItem('langs:v1', JSON.stringify({ active: [l], max: 2, lock: true, note: '' })); localStorage.setItem(pre + ':toured', '1'); localStorage.setItem('n5:settings', JSON.stringify({ pop: 'off', theme })); localStorage.setItem(pre + ':ui', JSON.stringify({ tab: 'card', cardSrc: 'new' })); localStorage.setItem('n5:progress', JSON.stringify({ items: {}, days })); } }, [L, pre, days, theme]);
    const pg = await ctx.newPage(); const errs = [];
    pg.on('pageerror', e => errs.push(e.message)); pg.on('console', m => { if (m.type() === 'error' && !/net::ERR|Failed to load resource/.test(m.text())) errs.push(m.text()); });
    await pg.goto(base + file); await pg.waitForSelector('#tab-card [data-a="queue"]');
    ok((await pg.textContent('#streakBtn')).trim() === '5', '上方顯示連勝 5（中間一天是休息日）');
    ok(!(await pg.evaluate(() => document.querySelector('#streakBtn').classList.contains('lit'))), '今天還沒練：火焰是灰的');
    ok(await pg.evaluate(() => { const r = document.querySelector('#streakBtn').getBoundingClientRect(), g = document.querySelector('.goal').getBoundingClientRect(); return r.right <= g.right + 1 && r.width > 20; }), '360px 寬：火焰按鈕沒有被擠出去');
    ok(await pg.evaluate(() => document.documentElement.scrollWidth <= innerWidth), '畫面沒有橫向捲動');
    ok(await pg.evaluate(() => { const t = document.querySelector('#goalText'); return t.scrollWidth <= t.clientWidth; }), '「x/20 題」沒有被截斷');
    for (let i = 0; i < 6; i++) { await pg.click('#tab-card [data-a="queue"]'); await pg.waitForTimeout(120); }
    await pg.click('[data-tab="fill"]'); await pg.waitForSelector('#tab-fill #fillIn');
    let toastSeen = '';
    for (let i = 0; i < 5; i++) {
      await pg.click('#fillShow'); await pg.waitForTimeout(150);
      const t = await pg.evaluate(() => { const x = document.querySelector('#toast'); return x && x.classList.contains('on') ? x.textContent : ''; });
      if (t) toastSeen = t;
      await pg.click('#fillGo'); await pg.waitForSelector('#tab-fill #fillIn:not([readonly])');
    }
    ok(/連勝 6 天/.test(toastSeen), '做滿 5 題跳出「' + toastSeen + '」');
    ok((await pg.textContent('#streakBtn')).trim() === '6' && await pg.evaluate(() => document.querySelector('#streakBtn').classList.contains('lit')), '連勝變 6、火焰亮起來');
    await pg.screenshot({ path: `shot-streak-${L}-${theme}-top.png`, clip: { x: 0, y: 0, width: 360, height: 80 } });
    await pg.click('#streakBtn'); await pg.waitForSelector('.sk-cal');
    const txt = await pg.textContent('.pk');
    ok(/最長紀錄 6 天/.test(txt) && /連勝保住了/.test(txt), '說明面板：最長紀錄、今天保住了');
    ok(await pg.evaluate(() => document.querySelectorAll('.sk-cal .sk-d.done').length) === 6 && await pg.evaluate(() => document.querySelectorAll('.sk-cal .sk-d.rest').length) === 1, '日曆：6 天有練、1 天休息日');
    ok(/這週已經用過/.test(txt), '休息日這週已經用過');
    await pg.screenshot({ path: `shot-streak-${L}-${theme}-sheet.png` });
    await pg.click('.pk-x'); await pg.waitForTimeout(250);
    // 每日目標
    await pg.click('[data-tab="lib"]'); await pg.waitForSelector('#goalSel', { state: 'attached' });
    await pg.evaluate(() => { const el = document.querySelector('#goalSel'); el.value = '10'; el.dispatchEvent(new Event('change')); });
    ok(/今日 5\/10 題/.test(await pg.textContent('#goalText')), '每日目標改成 10：上方變成 5/10');
    ok(JSON.parse(await pg.evaluate(() => localStorage.getItem('n5:settings'))).goal === 10, '每日目標存進共用設定');
    // 單選不加題數、不影響連勝
    await pg.click('[data-tab="mc"]'); await pg.waitForSelector('#mcq .opt');
    await pg.click('#mcq .opt >> nth=0'); await pg.waitForTimeout(200);
    ok(/今日 5\/10 題/.test(await pg.textContent('#goalText')), '單選還是不算');
    ok(!errs.length, '沒有錯誤訊息' + (errs.length ? '：' + errs.join(' | ') : ''));
    await ctx.close();
  }
  await br.close(); srv.close();
  console.log(bad ? `✗ ${bad} 項失敗` : '全部通過');
  process.exit(bad ? 1 : 0);
})();
