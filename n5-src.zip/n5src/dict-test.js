// 測 shared/dict.js（線上查字典）：用假的 fetch，回應的格式照 2026-11 實際查到的樣子。node n5src/dict-test.js
'use strict';
const fs = require('fs'), path = require('path'), vm = require('vm');
const calls = [];
const WIK = {
  whisker: { en: [{ partOfSpeech: 'Noun', language: 'English', definitions: [{ definition: 'That part of the <a rel="mw:WikiLink" href="/wiki/beard" title="beard">beard</a> which grows upon the sides of the <a href="/wiki/face">face</a>.' }, { definition: 'A <a href="/wiki/hair">hair</a> of the beard.' }, { definition: 'c' }, { definition: 'd' }] }, { partOfSpeech: 'Verb', language: 'English', definitions: [{ definition: '' }] }] },
  Schnurrhaar: { de: [{ partOfSpeech: 'Noun', language: 'German', definitions: [{ definition: '<a href="/wiki/whisker">whisker</a> <i>(of a cat or other animal)</i>' }] }] },
  'a_lot': { en: [{ partOfSpeech: 'Adverb', language: 'English', definitions: [{ definition: 'Very much; Tom &amp; Jerry&nbsp;&lt;3 <style>.x{}</style>' }] }] },
  casa: { es: [{ partOfSpeech: 'Noun', language: 'Spanish', definitions: [{ definition: 'house' }] }], it: [{ partOfSpeech: 'Noun', language: 'Italian', definitions: [{ definition: 'home' }] }] }
};
const MM = {
  whisker: { responseData: { translatedText: '貓 鼠的鬚', match: 0.99 }, responseStatus: 200, matches: [{ segment: 'whisker', translation: '貓 鼠的鬚', quality: '0', match: 0.99 }, { segment: 'whisker', translation: '鬍鬚', quality: 70, match: 0.85 }, { segment: 'minimum whisker value', translation: '最低鬚值', quality: '0', match: 0.85 }] },
  zzqq: { responseData: { translatedText: 'zzqq' }, matches: [{ segment: 'zzqq', translation: 'zzqq', quality: 70, match: 1 }] }
};
let down = false;
const fetch = async url => {
  calls.push(url);
  if (down) throw new Error('offline');
  let m = url.match(/page\/definition\/(.+)$/);
  if (m) { const d = WIK[decodeURIComponent(m[1])]; return { ok: !!d, json: async () => d }; }
  m = url.match(/get\?q=([^&]+)&langpair=(\w+)\|zh-TW/);
  const d = MM[decodeURIComponent(m[1])] || { responseData: { translatedText: '' }, matches: [] };
  return { ok: true, json: async () => d };
};
const ctx = { fetch, console, setTimeout, clearTimeout, AbortController, encodeURIComponent, Promise, Set, Array, String, Number };
vm.createContext(ctx);
vm.runInContext(fs.readFileSync(path.join(__dirname, 'shared/dict.js'), 'utf8') + '\nthis.dictLookup = dictLookup; this.dictText = dictText;', ctx);
let n = 0, fail = 0; const ok = (c, m) => { n++; if (!c) { fail++; console.log('FAIL ' + m); } };
(async () => {
  let r = await ctx.dictLookup(' whisker ', 'en');
  ok(r.defs.length === 1 && r.defs[0].zh === '名詞' && r.defs[0].p === 'n', '詞性換成中文和分組；沒有解釋的詞性不列');
  ok(r.defs[0].defs.length === 3 && r.defs[0].defs[0] === 'That part of the beard which grows upon the sides of the face.', '解釋拿掉 HTML 標籤，每個詞性最多 3 條');
  ok(r.zh.join() === '鬍鬚,貓鼠的鬚', '中文：品質分數高的在前，別的句子的翻譯不收（' + r.zh.join() + '）');
  ok(!r.offline, '有連上');
  calls.length = 0;
  r = await ctx.dictLookup('schnurrhaar', 'de');
  ok(r.defs.length === 1 && r.defs[0].defs[0] === 'whisker (of a cat or other animal)', '小寫查不到會改試首字大寫（德文名詞）');
  ok(calls.some(u => u.endsWith('/Schnurrhaar')) && calls.some(u => u.includes('langpair=de|zh-TW')), '網址：條目名稱和語言對');
  r = await ctx.dictLookup('a lot', 'en');
  ok(r.defs[0].defs[0] === 'Very much; Tom & Jerry <3' && r.defs[0].zh === '副詞', '片語用底線查；HTML 符號還原、<style> 拿掉');
  r = await ctx.dictLookup('casa', 'it');
  ok(r.defs.length === 1 && r.defs[0].defs[0] === 'home', '同一個拼法只取這個語言的解釋');
  r = await ctx.dictLookup('casa', 'de');
  ok(r.defs.length === 0 && !r.offline, '這個語言沒有這個字 → 沒有解釋');
  r = await ctx.dictLookup('zzqq', 'en');
  ok(r.defs.length === 0 && r.zh.length === 0 && !r.offline, '查不到：沒翻成中文的不算翻譯');
  down = true;
  r = await ctx.dictLookup('whisker', 'en');
  ok(r.offline && !r.defs.length && !r.zh.length, '連不上 → offline');
  console.log(fail ? `${n} 項檢查，${fail} 項失敗` : `${n} 項檢查，0 項失敗`);
  process.exit(fail ? 1 : 0);
})();
