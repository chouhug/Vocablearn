// 用真的瀏覽器（手機寬度 390px）走一遍日文頁的「我的造句」：node n5src/sents-ja-e2e.js n5work
// 需要 playwright 和 Chrome（不在 test-all.js 裡）；會在目前的資料夾留下 shot-ja-*.png
let chromium; try { ({ chromium } = require('playwright')); } catch (e) { ({ chromium } = require('/opt/npm-tools/node_modules/playwright')); }
const http = require('http'), fs = require('fs'), path = require('path');
const ROOT = path.resolve(process.argv[2]);
const srv = http.createServer((q, r) => { const f = path.join(ROOT, decodeURIComponent(q.url.split('?')[0])); fs.readFile(f, (e, d) => { if (e) { r.writeHead(404); return r.end(); } r.writeHead(200, { 'content-type': f.endsWith('.html') ? 'text/html; charset=utf-8' : 'text/javascript' }); r.end(d); }); });
let bad = 0; const ok = (c, m) => { console.log((c ? '✓ ' : '✗ ') + m); if (!c) bad++; };
(async () => {
  await new Promise(r => srv.listen(0, r));
  const br = await chromium.launch({ executablePath: process.env.CHROME || (fs.existsSync('/usr/bin/google-chrome') ? '/usr/bin/google-chrome' : undefined), args: ['--no-sandbox'] });
  const ctx = await br.newContext({ viewport: { width: 390, height: 780 }, deviceScaleFactor: 2, isMobile: true, hasTouch: true });
  await ctx.route(/^https:\/\//, r => r.abort());
  await ctx.addInitScript(() => { if (!localStorage.getItem('langs:last')) { localStorage.setItem('langs:last', '"ja"'); localStorage.setItem('langs:v1', JSON.stringify({ active: ['ja'], max: 2, lock: true, note: '' })); localStorage.setItem('n5:toured', '1'); localStorage.setItem('n5:ui', JSON.stringify({ tab: 'lib' })); } });
  const pg = await ctx.newPage(); const errs = [];
  pg.on('pageerror', e => errs.push(e.message)); pg.on('console', m => { if (m.type() === 'error' && !/net::ERR|Failed to load resource/.test(m.text())) errs.push(m.text()); });
  await pg.goto('http://127.0.0.1:' + srv.address().port + '/index.html'); await pg.waitForSelector('#q');
  const U = async word => { const it = JSON.parse(await pg.evaluate(() => localStorage.getItem('n5:progress') || '{"items":{}}')).items; const id = Object.keys(it).find(k => k.startsWith('v:' + word + '|')); return id ? (it[id].u || []) : null; };
  const save = async t => { await pg.fill('#usIn', t); await pg.click('#usForm [type=submit]'); await pg.waitForTimeout(250); };
  // 從搜尋結果進來：動詞
  await pg.fill('#q', 'たべる'); await pg.waitForSelector('#results [data-sents]');
  await pg.click('#results [data-sents]'); await pg.waitForSelector('#usForm');
  ok((await pg.textContent('.sheet-body')).includes('食'), '搜尋結果的「造句」打開面板，上面有這個字');
  await save('昨日、りんごを食べました。');
  ok(/已存到我的造句/.test(await pg.textContent('#toast')), '用了變化形（食べました）：認得，直接存');
  await save('猫がいます。');
  ok(/沒看到/.test(await pg.textContent('#toast')), '句子裡沒有這個字：還是存，但會提醒');
  let u = await U('食べる'); ok(u && u.length === 2 && u[0].s === '昨日、りんごを食べました。', '兩句都存進這個字的紀錄');
  await pg.waitForTimeout(300); await pg.screenshot({ path: 'shot-ja-sents.png' });
  ok(await pg.evaluate(() => document.documentElement.scrollWidth <= innerWidth && [...document.querySelectorAll('#usBox textarea, #usBox button, #usBox .mysent')].every(x => { const r = x.getBoundingClientRect(); return r.left >= 0 && r.right <= innerWidth; })), '手機寬度：沒有超出螢幕');
  await pg.click('[data-usdel="1"]'); await pg.click('[data-usdel="1"]'); await pg.waitForTimeout(250);
  u = await U('食べる'); ok(u.length === 1, '刪除（按兩次）後剩一句');
  await pg.click('.pk-x'); await pg.waitForTimeout(300);
  // 清單
  await pg.fill('#q', ''); await pg.reload(); await pg.waitForSelector('#listBox');
  await pg.click('#listBox summary'); await pg.click('[data-list="sent"]');
  ok(/1 句/.test(await pg.textContent('#listBox .lrows')), '重新整理後還在；單字庫清單「我的造句」看得到');
  await pg.click('#listBox .lrows button[data-id]'); await pg.waitForSelector('.mysent');
  ok((await pg.textContent('.mysent')).includes('食べました'), '從清單點進去看得到句子');
  await pg.click('.pk-x'); await pg.waitForTimeout(300);
  // 點例句裡的字的小框
  await pg.fill('#q', 'ねこ'); await pg.waitForSelector('#results .tk');
  await pg.click('#results .tk >> nth=0'); await pg.waitForSelector('#gloss [data-sents]');
  await pg.click('#gloss [data-sents]'); await pg.waitForSelector('#usForm');
  ok(await pg.evaluate(() => document.querySelector('#gloss').hidden), '點字的小框有「造句」，打開面板後小框收起來');
  await pg.click('.pk-x'); await pg.waitForTimeout(300); await pg.fill('#q', '');
  // 字卡
  await pg.click('.tabbar [data-tab="card"]'); await pg.waitForTimeout(300);
  const cardBtn = await pg.locator('#tab-card [data-sents]').count();
  if (cardBtn) { await pg.click('#tab-card [data-sents]'); await pg.waitForSelector('#usForm'); await save('これはテストです。'); await pg.click('.pk-x'); await pg.waitForTimeout(300); }
  ok(cardBtn > 0 && /（1）/.test(await pg.textContent('#tab-card [data-sents]')), '字卡上有「用這個字造句」，存了以後顯示句數');
  await pg.screenshot({ path: 'shot-ja-card.png' });
  ok(!errs.length, '沒有 JavaScript 錯誤' + (errs.length ? '：' + errs.join(' | ') : ''));
  await br.close(); srv.close();
  console.log(bad ? bad + ' 項失敗' : '全部通過'); process.exit(bad ? 1 : 0);
})().catch(e => { console.error(String(e).slice(0, 700)); process.exit(1); });
