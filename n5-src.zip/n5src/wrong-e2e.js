// 用真的瀏覽器（手機寬度 390px）測「錯題合併」：node n5src/wrong-e2e.js n5work [ja it …]
// 字卡來源只有「錯題」「錯題複習」，選了之後詞性那格換成「全部／單選／填空」；單字庫清單也一樣。
// 需要 playwright 和 Chrome（不在 test-all.js 裡）。會在目前的資料夾留下 shot-wrong-*.png 截圖
let chromium; try { ({ chromium } = require('playwright')); } catch (e) { ({ chromium } = require('/opt/npm-tools/node_modules/playwright')); }
const http = require('http'), fs = require('fs'), path = require('path');
const ROOT = path.resolve(process.argv[2]);
const LANGS = process.argv.slice(3).length ? process.argv.slice(3) : ['ja', 'it'];
const srv = http.createServer((q, r) => { const f = path.join(ROOT, decodeURIComponent(q.url.split('?')[0])); fs.readFile(f, (e, d) => { if (e) { r.writeHead(404); return r.end(); } r.writeHead(200, { 'content-type': f.endsWith('.html') ? 'text/html; charset=utf-8' : f.endsWith('.js') ? 'text/javascript' : 'application/octet-stream' }); r.end(d); }); });
let bad = 0; const ok = (c, m) => { console.log((c ? '✓ ' : '✗ ') + m); if (!c) bad++; };
(async () => {
  await new Promise(r => srv.listen(0, r)); const base = 'http://127.0.0.1:' + srv.address().port + '/';
  const br = await chromium.launch({ executablePath: process.env.CHROME || (fs.existsSync('/usr/bin/google-chrome') ? '/usr/bin/google-chrome' : undefined), args: ['--no-sandbox'] });
  for (const L of LANGS) {
    console.log('—— ' + L);
    const file = L === 'ja' ? 'index.html' : L + '.html', pre = L === 'ja' ? 'n5' : L;
    const ctx = await br.newContext({ viewport: { width: 390, height: 844 }, deviceScaleFactor: 2, isMobile: true, hasTouch: true }); await ctx.route(/^https:\/\//, r => r.abort());
    // 舊的字卡來源「單選錯題複習」：打開後應該自動變成「錯題複習」＋單選
    await ctx.addInitScript(([l, pre]) => { if (!localStorage.getItem('langs:last')) { localStorage.setItem('langs:last', JSON.stringify(l)); localStorage.setItem('langs:v1', JSON.stringify({ active: [l], max: 2, lock: true, note: '' })); localStorage.setItem(pre + ':toured', '1'); localStorage.setItem('n5:settings', JSON.stringify({ pop: 'off', vtip: 'off' })); localStorage.setItem(pre + ':ui', JSON.stringify({ tab: 'card', cardSrc: 'new' })); localStorage.setItem(pre + ':pop', JSON.stringify({ n: 0, goal: 99, last: new Date().toLocaleDateString('sv-SE') })); } }, [L, pre]);
    const pg = await ctx.newPage(); const errs = []; pg.on('pageerror', e => errs.push(e.message));
    await pg.goto(base + file); await pg.waitForSelector('#tab-card [data-a="queue"]');
    for (let i = 0; i < 10; i++) { await pg.click('#tab-card [data-a="queue"]'); await pg.waitForTimeout(100); }
    // 10 個字：0–2 單選錯、3–4 填空錯、5 兩種都錯；6–7 單選錯題複習、8 填空錯題複習、9 兩種都在複習
    const W = [{ mc: 1 }, { mc: 1 }, { mc: 1 }, { fill: 1 }, { fill: 1 }, { mc: 1, fill: 1 }, { mc: 2 }, { mc: 2 }, { fill: 2 }, { mc: 2, fill: 2 }];
    await pg.evaluate(([W, pre]) => { const key = pre === 'n5' ? 'n5:progress' : pre + ':progress'; const raw = localStorage.getItem(key) || localStorage.getItem('n5:progress'); const k = localStorage.getItem(key) ? key : 'n5:progress'; const P = JSON.parse(raw); Object.keys(P.items).forEach((id, i) => { if (W[i]) P.items[id].w = W[i]; }); localStorage.setItem(k, JSON.stringify(P)); const ui = JSON.parse(localStorage.getItem(pre + ':ui')); ui.cardSrc = 'mcReview'; localStorage.setItem(pre + ':ui', JSON.stringify(ui)); }, [W, pre]);
    await pg.reload(); await pg.waitForSelector('#cardSrc', { state: 'attached' }); await pg.waitForTimeout(300);
    const opts = async id => pg.evaluate(id => [...document.querySelectorAll('#' + id + ' option')].map(o => o.value + '=' + o.textContent.trim()), id);
    const val = id => pg.evaluate(id => (document.getElementById(id) || {}).value, id);
    const src = await opts('cardSrc'); console.log('   字卡來源：' + src.join('｜'));
    ok(src.map(x => x.split('=')[0]).join() === 'new,queued,recent,wrong,wrongReview,learned', '字卡來源：錯題和錯題複習各一項（沒有單選／填空分開的）');
    ok(src.includes('wrong=錯題 6'), '錯題 6（單選和填空合起來，兩種都錯的字只算一次）');
    ok(await val('cardSrc') === 'wrongReview' && await val('wrongKind') === 'mc', '舊的「單選錯題複習」自動換成「錯題複習」＋單選');
    ok(!(await pg.$('#tab-card [data-possel]')), '錯題來源：詞性選單換成種類選單');
    ok((await opts('wrongKind')).join() === 'all=全部 4,mc=單選 3,fill=填空 2', '錯題複習的種類：全部 4、單選 3、填空 2');
    const setSel = async (sel, v) => { await pg.evaluate(([sel, v]) => { const el = document.querySelector(sel); el.value = v; el.dispatchEvent(new Event('change')); }, [sel, v]); await pg.waitForTimeout(250); };
    await setSel('#cardSrc', 'wrong');
    ok((await opts('wrongKind')).join() === 'all=全部 6,mc=單選 4,fill=填空 3', '錯題的種類：全部 6、單選 4、填空 3');
    await setSel('#wrongKind', 'all');
    const meta = async () => (await pg.textContent('#fcHost .qh-l .meta:not(.fc-ago)')).trim();
    ok(/共 6$/.test(await meta()), '錯題・全部：一疊 6 張（' + await meta() + '）');
    ok(/答錯/.test(await pg.textContent('#fcHost')), '卡片上標出是單選還是填空答錯');
    await setSel('#wrongKind', 'fill');
    ok(/共 3$/.test(await meta()), '錯題・填空：一疊 3 張（' + await meta() + '）');
    ok(await pg.evaluate(() => { const r = document.querySelector('#tab-card .ctl').getBoundingClientRect(); return r.right <= innerWidth + 1; }), '手機寬度：上方選單沒有超出螢幕');
    await pg.screenshot({ path: `shot-wrong-card-${L}.png` });
    // 單字庫清單
    await pg.click('.tabbar [data-tab="lib"]'); await pg.waitForSelector('#listBox'); await pg.click('#listBox summary'); await pg.waitForTimeout(200);
    const chips = await pg.evaluate(() => [...document.querySelectorAll('#listBox [data-list]')].map(b => b.dataset.list + '=' + b.textContent.trim()));
    console.log('   清單：' + chips.join('｜'));
    ok(chips.some(x => x === 'wrong=錯題6') && chips.some(x => x === 'wrongReview=錯題複習4') && !chips.some(x => /mcWrong|fillWrong|mcReview|fillReview/.test(x)), '單字庫清單：錯題 6、錯題複習 4，沒有分開的四個');
    ok(await pg.$eval('#listBox .lst-sub', e => e.hidden), '待考清單：沒有種類標籤');
    await pg.click('#listBox [data-list="wrong"]'); await pg.waitForTimeout(200);
    const subs = await pg.evaluate(() => [...document.querySelectorAll('#listBox [data-wk]')].map(b => b.dataset.wk + '=' + b.textContent.trim() + (b.getAttribute('aria-pressed') === 'true' ? '*' : '')));
    ok(subs.join() === 'all=全部6,mc=單選4,fill=填空3*', '錯題清單上方：全部／單選／填空，和字卡共用（目前填空）：' + subs.join());
    ok((await pg.$$('#listBox .lrows .lrow')).length === 3, '填空：3 個字');
    await pg.click('#listBox [data-wk="all"]'); await pg.waitForTimeout(200);
    ok((await pg.$$('#listBox .lrows .lrow')).length === 6, '全部：6 個字');
    ok(/單選・填空/.test(await pg.textContent('#listBox .lrows')), '全部：標出是哪一種的錯題');
    await pg.screenshot({ path: `shot-wrong-lib-${L}.png`, fullPage: true });
    // 在「單選」移除一個兩種都錯的字：只移除單選的，填空的還在
    await pg.click('#listBox [data-wk="mc"]'); await pg.waitForTimeout(200);
    const both = await pg.evaluate(() => { const rows = [...document.querySelectorAll('#listBox .lrows button[data-id]')]; return rows.map(b => b.dataset.id); });
    const target = await pg.evaluate(([ids]) => ids.find(id => { const it = (window.ITApp || {}).S; return true; }), [both]);
    const bothId = await pg.evaluate(pre => { const k = localStorage.getItem(pre + ':progress') ? pre + ':progress' : 'n5:progress'; const P = JSON.parse(localStorage.getItem(k)); return Object.keys(P.items).find(id => P.items[id].w && P.items[id].w.mc === 1 && P.items[id].w.fill === 1); }, pre);
    await pg.click(`#listBox .lrows button[data-id="${bothId}"]`); await pg.waitForTimeout(300);
    const w = await pg.evaluate(([pre, id]) => { const k = localStorage.getItem(pre + ':progress') ? pre + ':progress' : 'n5:progress'; return JSON.parse(localStorage.getItem(k)).items[id].w; }, [pre, bothId]);
    ok(w && !w.mc && w.fill === 1, '在「單選」移除兩種都錯的字：只移除單選，填空錯題還在');
    ok((await pg.textContent('#listBox [data-wk="mc"] .n')).trim() === '3' && (await pg.textContent('#listBox [data-list="wrong"] .n')).trim() === '6', '數字更新：單選 3、錯題還是 6');
    ok(!errs.length, '沒有 JS 錯誤' + (errs.length ? '：' + errs.join(' | ') : ''));
    await ctx.close();
  }
  await br.close(); srv.close();
  console.log(bad ? `${bad} 項失敗` : '全部通過'); process.exit(bad ? 1 : 0);
})();
